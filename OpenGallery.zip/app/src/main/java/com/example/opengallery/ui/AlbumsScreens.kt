package com.example.opengallery.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.LazyGridItemInfo
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.example.opengallery.data.AlbumEntity
import kotlinx.coroutines.delay
import kotlin.math.roundToInt
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items as listItems
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.GalleryMedia
import com.example.opengallery.data.SortOption
import com.example.opengallery.data.sortedBySetting

/** Live state of an album tile that is being dragged around the grid. */
private class AlbumDrag {
    var key by mutableStateOf<String?>(null)
    var order by mutableStateOf<List<String>?>(null)
    var pos by mutableStateOf(Offset.Zero)
    var grab by mutableStateOf(Offset.Zero)
    var size by mutableStateOf(IntSize.Zero)
    var mergeTarget by mutableStateOf<String?>(null)
    var moved by mutableStateOf(false)
    var start = Offset.Zero

    fun reset() {
        key = null
        order = null
        mergeTarget = null
        moved = false
    }
}

private fun nextGroupName(albums: List<AlbumEntity>): String {
    val re = Regex("Group (\\d+)")
    val n = albums.filter { it.isGroup }
        .mapNotNull { re.matchEntire(it.name)?.groupValues?.get(1)?.toIntOrNull() }
        .maxOrNull() ?: 0
    return "Group ${n + 1}"
}

private fun hits(o: Offset, info: LazyGridItemInfo): Boolean =
    o.x >= info.offset.x && o.x <= info.offset.x + info.size.width &&
        o.y >= info.offset.y && o.y <= info.offset.y + info.size.height

/** Middle of another album = merge into a group; its left/right side = move the dragged tile before/after it. */
private fun updateDrag(drag: AlbumDrag, byKey: Map<String, AlbumInfo>, infos: List<LazyGridItemInfo>) {
    val k = drag.key ?: return
    val pos = drag.pos
    val target = infos.firstOrNull { val key = it.key; key is String && key != k && hits(pos, it) }
    if (target == null) {
        drag.mergeTarget = null
        return
    }
    val tKey = target.key as String
    val frac = (pos.x - target.offset.x) / target.size.width
    val a = byKey[k]
    val t = byKey[tKey]
    val mergeable = a != null && t != null &&
        (a.kind == Kind.FOLDER || a.kind == Kind.CUSTOM) &&
        (t.kind == Kind.FOLDER || t.kind == Kind.CUSTOM || t.kind == Kind.GROUP)
    if (mergeable && frac >= 0.3f && frac <= 0.7f) {
        drag.mergeTarget = tKey
        return
    }
    drag.mergeTarget = null
    val current = drag.order ?: return
    val list = current.toMutableList()
    if (!list.remove(k)) return
    val idx = list.indexOf(tKey)
    if (idx < 0) return
    list.add(if (frac < 0.5f) idx else idx + 1, k)
    if (list != current) drag.order = list
}

/** The Albums tab (viewAll = false) and the "All albums" screen (viewAll = true). */
@Composable
fun AlbumsContent(vm: GalleryViewModel, nav: NavController, viewAll: Boolean, onSelecting: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val media by vm.media.collectAsState()
    val albums by vm.albums.collectAsState()
    val links by vm.links.collectAsState()
    val members by vm.members.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val essential by vm.essential.collectAsState()
    val hidden by vm.hidden.collectAsState()
    val essentialOn by vm.essentialEnabled.collectAsState()
    val albumSort by vm.albumSort.collectAsState()
    val order by vm.albumOrder.collectAsState()
    val askName by vm.askGroupName.collectAsState()
    val actions = rememberFileActions(vm::refresh)

    val model = remember(media, albums, links, members, favorites) { buildAlbums(media, albums, links, members, favorites) }
    var pick by remember { mutableStateOf<String?>(null) } // "essential" | "hide" | null
    val sel = rememberSelection<String>()
    var showSort by remember { mutableStateOf(false) }
    var chooseCreate by remember { mutableStateOf(false) }
    var createAlbum by remember { mutableStateOf(false) }
    var createGroup by remember { mutableStateOf(false) }
    var groupFromSel by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var dups by remember { mutableStateOf<List<GalleryMedia>?>(null) }
    var pendingMerge by remember { mutableStateOf<Pair<String, String>?>(null) }
    LaunchedEffect(sel.mode) { onSelecting(sel.mode) }
    BackHandler(sel.mode) { sel.clear(); pick = null }

    val visible = remember(model, hidden, pick) {
        if (pick == "hide") model.topLevel else model.topLevel.filter { it.key !in hidden }
    }
    val sorted = remember(visible, albumSort, order) {
        val s = albumSort
        if (s != null) visible.sortedBySetting(s, { it.title }, { it.latest }, { it.modified }, { it.size })
        else if (order.isEmpty()) visible
        else {
            val idx = order.withIndex().associate { it.value to it.index }
            visible.sortedBy { idx[it.key] ?: Int.MAX_VALUE }
        }
    }
    val essSet = essential ?: sorted.take(9).map { it.key }.toSet()
    val shown = if (viewAll || !essentialOn || pick != null) sorted else sorted.filter { it.key in essSet }
    val byKey = remember(shown) { shown.associateBy { it.key } }

    val gridState = rememberLazyGridState()
    // Jump to the top only when the SORT really changes, not when this screen is simply shown again
    // (coming back from an album must keep your place).
    val firstSortRun = remember { booleanArrayOf(true) }
    LaunchedEffect(albumSort) {
        if (firstSortRun[0]) { firstSortRun[0] = false; return@LaunchedEffect }
        withFrameNanos { }; gridState.scrollToItem(0)
    }
    val collapsed by remember { derivedStateOf { gridState.firstVisibleItemIndex > 0 } }

    // ---- drag & drop (hold a tile, move it, drop it) ----
    val drag = remember { AlbumDrag() }
    val latestShown by rememberUpdatedState(shown)
    val latestSorted by rememberUpdatedState(sorted)
    val latestByKey by rememberUpdatedState(byKey)
    val latestPick by rememberUpdatedState(pick)
    val latestEss by rememberUpdatedState(essSet)

    /** Create a group from [keys]; the new group takes the place of [at] in the album order. */
    fun createMerged(keys: Set<String>, name: String, at: String?) {
        vm.createGroup(name, keys) { id ->
            val gKey = "group:$id"
            vm.setEssential(latestEss + gKey)
            if (at != null) {
                val cur = latestSorted.map { it.key }.filter { it !in keys || it == at }
                vm.setAlbumOrder(cur.map { if (it == at) gKey else it })
            }
        }
    }
    val onMerge: (String, String) -> Unit = { dragged, target ->
        val t = model.byKey[target]
        if (t != null && t.kind == Kind.GROUP) {
            vm.addMembers(t.id, setOf(dragged))
        } else if (askName) {
            pendingMerge = dragged to target
        } else {
            createMerged(setOf(dragged, target), nextGroupName(albums), target)
        }
    }
    val onCommitOrder: (List<String>) -> Unit = { finalKeys ->
        val shownSet = latestShown.map { it.key }.toSet()
        val iter = finalKeys.iterator()
        val newAll = latestSorted.map { a -> if (a.key in shownSet && iter.hasNext()) iter.next() else a.key }
        vm.setAlbumOrder(newAll)
        vm.albumSort.value = null
    }
    val mergeCb by rememberUpdatedState(onMerge)
    val commitCb by rememberUpdatedState(onCommitOrder)

    LaunchedEffect(drag.key) {
        while (drag.key != null) {
            val y = drag.pos.y
            val h = gridState.layoutInfo.viewportSize.height
            if (y < 140f) gridState.scrollBy(-24f) else if (y > h - 140f) gridState.scrollBy(24f)
            delay(16)
        }
    }

    val pill: @Composable (Modifier) -> Unit = { m ->
        PillActions(m, onPlus = { chooseCreate = true }, onSearch = { nav.navigate("search/all") }) { close ->
            MenuItem("Select") { close(); pick = null; sel.start() }
            if (essentialOn) MenuItem("Select essential albums") {
                close(); pick = "essential"; sel.start(); sel.ids = essSet
            }
            MenuItem("Hide albums") { close(); pick = "hide"; sel.start(); sel.ids = hidden }
            MenuItem("Sort") { close(); showSort = true }
            MenuItem("Delete duplicates") {
                close()
                val d = vm.findDuplicates()
                if (d.isEmpty()) Toast.makeText(ctx, "No duplicates found", Toast.LENGTH_SHORT).show() else dups = d
            }
        }
    }
    val backButton: @Composable () -> Unit = {
        CircleButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", { nav.popBackStack() })
    }

    Box(Modifier.fillMaxSize()) {
        val gridItems = remember(drag.order, shown) {
            val o = drag.order
            if (o == null) shown else o.mapNotNull { byKey[it] }
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(3), state = gridState,
            userScrollEnabled = drag.key == null,
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 120.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize().pointerInput(Unit) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { o ->
                        if (latestPick == null) {
                            val hit = gridState.layoutInfo.visibleItemsInfo.firstOrNull { it.key is String && hits(o, it) }
                            if (hit != null) {
                                val k = hit.key as String
                                drag.key = k
                                drag.order = latestShown.map { it.key }
                                drag.size = hit.size
                                drag.grab = Offset(o.x - hit.offset.x, o.y - hit.offset.y)
                                drag.pos = o
                                drag.start = o
                                drag.moved = false
                                drag.mergeTarget = null
                                if (!sel.mode) sel.start(k)
                            }
                        }
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        if (drag.key != null) {
                            drag.pos = change.position
                            if (!drag.moved && (change.position - drag.start).getDistance() > 24f) drag.moved = true
                            updateDrag(drag, latestByKey, gridState.layoutInfo.visibleItemsInfo)
                        }
                    },
                    onDragEnd = {
                        val k = drag.key
                        if (k != null) {
                            val target = drag.mergeTarget
                            val ord = drag.order
                            val changed = ord != null && ord != latestShown.map { it.key }
                            if (target != null) {
                                mergeCb(k, target)
                                sel.clear()
                            } else if (changed && ord != null) {
                                commitCb(ord)
                                sel.clear()
                            } else if (drag.moved) {
                                sel.clear()
                            }
                        }
                        drag.reset()
                    },
                    onDragCancel = { drag.reset() }
                )
            }
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                LargeTitleHeader(
                    if (viewAll) "All albums" else "Albums",
                    leading = if (viewAll) backButton else null
                ) { pill(Modifier) }
            }
            if (!viewAll && essentialOn && pick == null) item(span = { GridItemSpan(maxLineSpan) }) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Essential albums", Modifier.weight(1f), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text("View all", color = Accent, fontSize = 15.sp, modifier = Modifier.clickable { nav.navigate("allalbums") })
                }
            }
            items(gridItems, key = { it.key }) { a ->
                if (a.key == drag.key) {
                    // empty slot showing where the lifted tile will land
                    Box(Modifier.animateItem().aspectRatio(0.86f).clip(RoundedCornerShape(20.dp)).background(Color(0xFF141414)))
                } else {
                    AlbumTile(
                        a, a.key in sel.ids, sel.mode,
                        onClick = {
                            if (sel.mode) sel.toggle(a.key)
                            else if (a.kind == Kind.GROUP) nav.navigate("group/${a.id}")
                            else nav.navigate(albumRoute(a.key))
                        },
                        highlight = a.key == drag.mergeTarget,
                        modifier = Modifier.animateItem()
                    )
                }
            }
        }

        // the lifted tile follows the finger
        val dk = drag.key
        val dragged = if (dk != null) byKey[dk] else null
        if (dragged != null) {
            val density = LocalDensity.current
            Box(
                Modifier
                    .offset { IntOffset((drag.pos.x - drag.grab.x).roundToInt(), (drag.pos.y - drag.grab.y).roundToInt()) }
                    .size(with(density) { drag.size.width.toDp() }, with(density) { drag.size.height.toDp() })
                    .graphicsLayer { scaleX = 1.06f; scaleY = 1.06f; shadowElevation = 30f }
            ) {
                AlbumTile(dragged, false, false, onClick = {}, modifier = Modifier.fillMaxSize(), highlight = true)
            }
        }

        if (sel.mode) {
            val allKeys = shown.map { it.key }.toSet()
            val all = allKeys.isNotEmpty() && sel.ids.containsAll(allKeys)
            SelectionTop(
                sel.ids.size, all,
                onToggleAll = { sel.ids = if (all) emptySet() else allKeys },
                onCancel = { sel.clear(); pick = null }, modifier = Modifier.align(Alignment.TopCenter)
            )
            ActionPill(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 16.dp)) {
                when (pick) {
                    "essential" -> PillAction(Icons.Filled.Check, "Done") { vm.setEssential(sel.ids); sel.clear(); pick = null }
                    "hide" -> PillAction(Icons.Filled.Check, "Done") { vm.setHidden(sel.ids); sel.clear(); pick = null }
                    else -> {
                        val has = sel.ids.isNotEmpty()
                        PillAction(Icons.Filled.CreateNewFolder, "Group", has) { groupFromSel = true }
                        val hasGroup = sel.ids.any { model.byKey[it]?.kind == Kind.GROUP }
                        if (hasGroup) PillAction(Icons.Filled.CallSplit, "Ungroup") {
                            sel.ids.mapNotNull { model.byKey[it] }.filter { it.kind == Kind.GROUP }
                                .forEach { vm.deleteAlbum(it.id, true) }
                            sel.clear()
                        }
                        PillAction(Icons.Filled.VisibilityOff, "Hide", has) { vm.setHidden(hidden + sel.ids); sel.clear() }
                        PillAction(Icons.Filled.Delete, "Delete", has) { confirmDelete = true }
                    }
                }
            }
        } else if (collapsed) {
            Row(
                Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (viewAll) backButton() else Spacer(Modifier.height(1.dp))
                pill(Modifier)
            }
        }
    }

    if (chooseCreate) ChooseCreateDialog(
        onDismiss = { chooseCreate = false },
        onAlbum = { chooseCreate = false; createAlbum = true },
        onGroup = { chooseCreate = false; createGroup = true }
    )
    if (createAlbum) NameDialog("Create album", "Album", "Create", { createAlbum = false }) { n ->
        createAlbum = false
        vm.createAlbum(n) { id -> nav.navigate("additems/$id") }
    }
    if (createGroup) NameDialog("Create group", nextGroupName(albums), "Create", { createGroup = false }) { n ->
        createGroup = false
        vm.createGroup(n, emptySet()) { id -> nav.navigate("group/$id") }
    }
    if (groupFromSel) NameDialog("Create group", nextGroupName(albums), "Create", { groupFromSel = false }) { n ->
        groupFromSel = false
        val keys = sel.ids.filter { model.byKey[it]?.kind == Kind.FOLDER || model.byKey[it]?.kind == Kind.CUSTOM }.toSet()
        createMerged(keys, n, null)
        sel.clear()
    }
    pendingMerge?.let { pm ->
        NameDialog("Create group", nextGroupName(albums), "Create", { pendingMerge = null }) { n ->
            pendingMerge = null
            createMerged(setOf(pm.first, pm.second), n, pm.second)
        }
    }
    if (confirmDelete) ConfirmDialog(
        "Delete albums", "Delete ${sel.ids.size} selected album(s)? Your pictures and videos are not deleted. " +
            "Folder albums can't be deleted here.", "Delete", { confirmDelete = false }
    ) {
        sel.ids.mapNotNull { model.byKey[it] }
            .filter { it.kind == Kind.CUSTOM || it.kind == Kind.GROUP }
            .forEach { vm.deleteAlbum(it.id, it.kind == Kind.GROUP) }
        confirmDelete = false
        sel.clear()
    }
    if (showSort) SortDialog(albumSort ?: SortOption.CREATED_DESC, null, { showSort = false }) { s, _ ->
        vm.albumSort.value = s; showSort = false
    }
    dups?.let { d ->
        ConfirmDialog(
            "Delete duplicates", "Found ${d.size} duplicate file(s). Move them to trash?", "Move to trash",
            { dups = null }
        ) { actions.trash(d); dups = null }
    }
}

@Composable
fun AllAlbumsScreen(vm: GalleryViewModel, nav: NavController) {
    AlbumsContent(vm, nav, viewAll = true) { }
}

/** A group: shows the albums inside it. */
@Composable
fun GroupScreen(vm: GalleryViewModel, nav: NavController, groupId: Long) {
    val media by vm.media.collectAsState()
    val albums by vm.albums.collectAsState()
    val links by vm.links.collectAsState()
    val members by vm.members.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val model = remember(media, albums, links, members, favorites) { buildAlbums(media, albums, links, members, favorites) }
    val sel = rememberSelection<String>()
    var addDialog by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var delete by remember { mutableStateOf(false) }
    BackHandler(sel.mode) { sel.clear() }

    val group = albums.firstOrNull { it.id == groupId }
    if (group == null) {
        LaunchedEffect(Unit) { nav.popBackStack() }
        return
    }
    val infos = members.filter { it.groupId == groupId }.mapNotNull { model.byKey[it.albumKey] }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text(group.name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                    Text("${infos.size} albums", color = Color(0xCCFFFFFF), fontSize = 13.sp)
                }
                if (!sel.mode) PillActions { close ->
                    MenuItem("Select") { close(); sel.start() }
                    MenuItem("Add albums") { close(); addDialog = true }
                    MenuItem("Rename") { close(); rename = true }
                    MenuItem("Delete group") { close(); delete = true }
                }
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 120.dp, top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(infos, key = { it.key }) { a ->
                    AlbumTile(
                        a, a.key in sel.ids, sel.mode,
                        onClick = { if (sel.mode) sel.toggle(a.key) else nav.navigate(albumRoute(a.key)) },
                        onLong = { if (sel.mode) sel.toggle(a.key) else sel.start(a.key) }
                    )
                }
            }
        }
        if (sel.mode) {
            SelectionTop(
                sel.ids.size, infos.isNotEmpty() && sel.ids.size == infos.size,
                onToggleAll = { sel.ids = if (sel.ids.size == infos.size) emptySet() else infos.map { it.key }.toSet() },
                onCancel = { sel.clear() }, modifier = Modifier.align(Alignment.TopCenter)
            )
            ActionPill(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 16.dp)) {
                PillAction(Icons.Filled.Delete, "Remove from group", sel.ids.isNotEmpty()) {
                    vm.removeMembers(groupId, sel.ids); sel.clear()
                }
            }
        }
    }

    if (addDialog) {
        var chosen by remember { mutableStateOf(setOf<String>()) }
        val candidates = model.topLevel.filter { it.kind == Kind.FOLDER || it.kind == Kind.CUSTOM }
        AlertDialog(
            onDismissRequest = { addDialog = false }, containerColor = CardBg,
            title = { Text("Add albums") },
            text = {
                LazyColumn {
                    listItems(candidates, key = { it.key }) { a ->
                        Row(
                            Modifier.fillMaxWidth().clickable { chosen = if (a.key in chosen) chosen - a.key else chosen + a.key },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(checked = a.key in chosen, onCheckedChange = { chosen = if (it) chosen + a.key else chosen - a.key })
                            Text("${a.title} (${a.count})")
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { vm.addMembers(groupId, chosen); addDialog = false }) { Text("Add") } },
            dismissButton = { TextButton(onClick = { addDialog = false }) { Text("Cancel") } }
        )
    }
    if (rename) NameDialog("Rename group", group.name, "Rename", { rename = false }) { n ->
        vm.renameAlbum(groupId, n); rename = false
    }
    if (delete) ConfirmDialog(
        "Delete group", "The albums inside are kept; only the group is removed.", "Delete", { delete = false }
    ) { delete = false; vm.deleteAlbum(groupId, true) }
}
