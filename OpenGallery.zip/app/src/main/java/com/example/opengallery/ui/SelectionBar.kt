package com.example.opengallery.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.DropdownMenu
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.GalleryMedia

/** Bottom pill shown while selecting pictures/videos: Share | Add to album | Delete | More. */
@Composable
fun BoxScope.MediaSelectionBar(
    vm: GalleryViewModel,
    actions: FileActions,
    items: List<GalleryMedia>,
    onDone: () -> Unit,
    extra: @Composable ColumnScope.(close: () -> Unit) -> Unit = {}
) {
    var more by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf<String?>(null) }
    val favs by vm.favorites.collectAsState()
    val enabled = items.isNotEmpty()
    val ctx = androidx.compose.ui.platform.LocalContext.current
    ActionPill(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 16.dp)) {
        PillAction(Icons.Filled.Share, "Share", enabled) { actions.share(items) }
        PillAction(Icons.Filled.Delete, "Delete", enabled) { actions.trash(items, onDone) }
        Box {
            PillAction(Icons.Filled.MoreVert, "More", enabled) { more = true }
            DropdownMenu(
                expanded = more, onDismissRequest = { more = false },
                modifier = Modifier.background(CardBg, RoundedCornerShape(20.dp))
            ) {
                val allFav = items.isNotEmpty() && items.all { it.id in favs }
                MenuItem("Add to favorites") {
                    more = false
                    val toAdd = items.filter { it.id !in favs }
                    if (toAdd.isEmpty()) {
                        Toast.makeText(ctx, "All the selected items are already in favorites.", Toast.LENGTH_SHORT).show()
                    } else {
                        vm.toggleFavorite(toAdd.map { it.id }, true)
                        onDone()
                    }
                }
                if (allFav) MenuItem("Remove from favorites") {
                    more = false
                    vm.toggleFavorite(items.map { it.id }, false)
                    onDone()
                }
                MenuItem("Copy to album") { more = false; dlg = "copy" }
                MenuItem("Move to album") { more = false; dlg = "move" }
                this.extra { more = false }
            }
        }
    }
    when (dlg) {
        "album" -> AlbumPickDialog(vm, onDismiss = { dlg = null }) { id ->
            vm.addToAlbum(id, items); dlg = null; onDone()
        }
        "copy" -> AlbumMovePicker(vm, actions, items, move = false, onDismiss = { dlg = null }, onDone = onDone)
        "move" -> AlbumMovePicker(vm, actions, items, move = true, onDismiss = { dlg = null }, onDone = onDone)
    }
}
