package com.example.opengallery.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.MediaStore.MediaColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class GalleryMedia(
    val id: Long,
    val uri: Uri,
    val isVideo: Boolean,
    val name: String,
    val size: Long,
    val dateTaken: Long,      // "date created"
    val dateModified: Long,
    val duration: Long,
    val width: Int,
    val height: Int,
    val bucketId: Long,
    val bucketName: String,
    val relativePath: String
)

/** Same options as Samsung Gallery's "Sort by" dialog, plus size. */
enum class SortOption(val label: String) {
    CREATED_ASC("Date created (ascending)"),
    CREATED_DESC("Date created (descending)"),
    MODIFIED_ASC("Date modified (ascending)"),
    MODIFIED_DESC("Date modified (descending)"),
    NAME_AZ("Name (A to Z)"),
    NAME_ZA("Name (Z to A)"),
    SIZE_ASC("Size (smallest first)"),
    SIZE_DESC("Size (largest first)")
}

fun <T> List<T>.sortedBySetting(
    opt: SortOption,
    name: (T) -> String,
    created: (T) -> Long,
    modified: (T) -> Long,
    size: (T) -> Long
): List<T> = when (opt) {
    SortOption.CREATED_ASC -> sortedBy(created)
    SortOption.CREATED_DESC -> sortedByDescending(created)
    SortOption.MODIFIED_ASC -> sortedBy(modified)
    SortOption.MODIFIED_DESC -> sortedByDescending(modified)
    SortOption.NAME_AZ -> sortedBy { name(it).lowercase() }
    SortOption.NAME_ZA -> sortedByDescending { name(it).lowercase() }
    SortOption.SIZE_ASC -> sortedBy(size)
    SortOption.SIZE_DESC -> sortedByDescending(size)
}

fun List<GalleryMedia>.sortedByOption(opt: SortOption): List<GalleryMedia> =
    sortedBySetting(opt, { it.name }, { it.dateTaken }, { it.dateModified }, { it.size })

class MediaRepo(private val context: Context) {
    suspend fun load(): List<GalleryMedia> = query(trashed = false)
    suspend fun loadTrash(): List<GalleryMedia> = query(trashed = true)

    private suspend fun query(trashed: Boolean): List<GalleryMedia> = withContext(Dispatchers.IO) {
        val out = mutableListOf<GalleryMedia>()
        val type = MediaStore.Files.FileColumns.MEDIA_TYPE
        val projection = arrayOf(
            MediaColumns._ID, type, MediaColumns.DISPLAY_NAME, MediaColumns.SIZE,
            MediaColumns.DATE_ADDED, MediaColumns.DATE_MODIFIED, MediaColumns.DATE_TAKEN,
            MediaColumns.DURATION, MediaColumns.WIDTH, MediaColumns.HEIGHT,
            MediaColumns.BUCKET_ID, MediaColumns.BUCKET_DISPLAY_NAME, MediaColumns.RELATIVE_PATH
        )
        val args = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, "$type IN (?, ?)")
            putStringArray(
                ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS,
                arrayOf(
                    MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
                    MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString()
                )
            )
            putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, if (trashed) MediaStore.MATCH_ONLY else MediaStore.MATCH_EXCLUDE)
        }
        context.contentResolver.query(MediaStore.Files.getContentUri("external"), projection, args, null)?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaColumns._ID)
            val iType = c.getColumnIndexOrThrow(type)
            val iName = c.getColumnIndexOrThrow(MediaColumns.DISPLAY_NAME)
            val iSize = c.getColumnIndexOrThrow(MediaColumns.SIZE)
            val iAdded = c.getColumnIndexOrThrow(MediaColumns.DATE_ADDED)
            val iMod = c.getColumnIndexOrThrow(MediaColumns.DATE_MODIFIED)
            val iTaken = c.getColumnIndexOrThrow(MediaColumns.DATE_TAKEN)
            val iDur = c.getColumnIndexOrThrow(MediaColumns.DURATION)
            val iW = c.getColumnIndexOrThrow(MediaColumns.WIDTH)
            val iH = c.getColumnIndexOrThrow(MediaColumns.HEIGHT)
            val iBid = c.getColumnIndexOrThrow(MediaColumns.BUCKET_ID)
            val iBname = c.getColumnIndexOrThrow(MediaColumns.BUCKET_DISPLAY_NAME)
            val iRel = c.getColumnIndexOrThrow(MediaColumns.RELATIVE_PATH)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val video = c.getInt(iType) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                val taken = c.getLong(iTaken).takeIf { it > 0 } ?: (c.getLong(iAdded) * 1000)
                out += GalleryMedia(
                    id = id,
                    uri = ContentUris.withAppendedId(base, id),
                    isVideo = video,
                    name = c.getString(iName) ?: "Unknown",
                    size = c.getLong(iSize),
                    dateTaken = taken,
                    dateModified = c.getLong(iMod) * 1000,
                    duration = c.getLong(iDur),
                    width = c.getInt(iW),
                    height = c.getInt(iH),
                    bucketId = c.getLong(iBid),
                    bucketName = c.getString(iBname) ?: "Other",
                    relativePath = c.getString(iRel) ?: ""
                )
            }
        }
        out
    }
}
