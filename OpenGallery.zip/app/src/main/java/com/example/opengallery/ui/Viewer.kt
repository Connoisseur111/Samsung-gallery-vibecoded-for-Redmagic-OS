@file:OptIn(UnstableApi::class, ExperimentalFoundationApi::class)

package com.example.opengallery.ui

import android.content.Intent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.GalleryMedia
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ViewerScreen(vm: GalleryViewModel, nav: NavController, startIndex: Int, slideshow: Boolean) {
    val list = vm.viewerList
    val actions = rememberFileActions(vm::refresh)
    val favs by vm.favorites.collectAsState()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var showUi by remember { mutableStateOf(true) }
    var dialog by remember { mutableStateOf<String?>(null) }
    if (list.isEmpty()) {
        LaunchedEffect(Unit) { nav.popBackStack() }
        return
    }
    val pager = rememberPagerState(startIndex.coerceIn(0, list.lastIndex)) { list.size }
    var zoomed by remember { mutableStateOf(false) }
    var dragY by remember { mutableFloatStateOf(0f) }
    val current = list[pager.currentPage.coerceIn(0, list.lastIndex)]
    if (slideshow) LaunchedEffect(Unit) {
        while (pager.currentPage < list.lastIndex) {
            delay(3000)
            pager.animateScrollToPage(pager.currentPage + 1)
        }
        nav.popBackStack()
    }

    Box(
        Modifier.fillMaxSize()
            .background(Color.Black.copy(alpha = (1f - dragY / 900f).coerceIn(0f, 1f)))
            .pointerInput(zoomed) {
                if (zoomed) return@pointerInput
                // Slide a finger down to close the picture / video.
                detectVerticalDragGestures(
                    onDragStart = { },
                    onDragEnd = {
                        if (dragY > 260f) nav.popBackStack()
                        else scope.launch { animate(dragY, 0f, animationSpec = spring()) { v, _ -> dragY = v } }
                    },
                    onDragCancel = {
                        scope.launch { animate(dragY, 0f, animationSpec = spring()) { v, _ -> dragY = v } }
                    },
                    onVerticalDrag = { change, dy ->
                        if (dragY > 0f || dy > 0f) { change.consume(); dragY = (dragY + dy).coerceAtLeast(0f) }
                    }
                )
            }
    ) {
        HorizontalPager(
            pager,
            Modifier.fillMaxSize().graphicsLayer {
                val f = (1f - (dragY / 1600f)).coerceIn(0.6f, 1f)
                translationY = dragY; scaleX = f; scaleY = f
            }
        ) { page ->
            val m = list[page]
            if (m.isVideo) VideoPage(m, pager.currentPage == page, showUi)
            else ZoomImage(m, pager.currentPage == page, { zoomed = it }) { showUi = !showUi }
        }
        if (showUi && dragY == 0f) {
            Row(
                Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                CircleButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", { nav.popBackStack() })
                PillActions { close ->
                    MenuItem("Details") { close(); dialog = "details" }
                    if (current.isVideo) MenuItem("Open in video player") {
                        close()
                        val i = Intent(Intent.ACTION_VIEW).setDataAndType(current.uri, "video/*")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        runCatching { ctx.startActivity(i) }
                    } else MenuItem("Set as wallpaper") {
                        close()
                        val i = Intent(Intent.ACTION_ATTACH_DATA).setDataAndType(current.uri, "image/*")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        runCatching { ctx.startActivity(Intent.createChooser(i, "Set as")) }
                    }
                    MenuItem("Copy to album") { close(); dialog = "copy" }
                    MenuItem("Move to album") { close(); dialog = "move" }
                }
            }
            Column(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Filmstrip(list, pager.currentPage) { i -> scope.launch { pager.scrollToPage(i) } }
                Spacer(Modifier.height(10.dp))
                ActionPill {
                    PillAction(if (current.id in favs) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null) {
                        vm.toggleFavorite(listOf(current.id), current.id !in favs)
                    }
                    PillAction(Icons.Filled.Edit, null) {
                        nav.navigate(if (current.isVideo) "editor/${current.id}" else "photoeditor/${current.id}")
                    }
                    PillAction(Icons.Filled.Share, null) { actions.share(listOf(current)) }
                    PillAction(Icons.Filled.Delete, null) { actions.trash(listOf(current)) { nav.popBackStack() } }
                }
            }
        }
    }

    when (dialog) {
        "details" -> DetailsDialog(current) { dialog = null }
        "copy" -> AlbumMovePicker(vm, actions, listOf(current), move = false, onDismiss = { dialog = null }, onDone = { dialog = null })
        "move" -> AlbumMovePicker(vm, actions, listOf(current), move = true, onDismiss = { dialog = null }, onDone = { dialog = null; nav.popBackStack() })
    }
}

/** Small thumbnail strip above the action bar; the current item is slightly bigger. */
@Composable
private fun Filmstrip(list: List<GalleryMedia>, current: Int, onPick: (Int) -> Unit) {
    val state = rememberLazyListState()
    LaunchedEffect(current) { state.animateScrollToItem((current - 4).coerceAtLeast(0)) }
    LazyRow(
        state = state, modifier = Modifier.height(42.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        contentPadding = PaddingValues(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        itemsIndexed(list) { i, m ->
            MediaImage(
                m,
                Modifier.height(if (i == current) 42.dp else 34.dp).width(if (i == current) 32.dp else 25.dp)
                    .clip(RoundedCornerShape(5.dp)).clickable { onPick(i) }
            )
        }
    }
}

@Composable
private fun ZoomImage(m: GalleryMedia, active: Boolean, onZoom: (Boolean) -> Unit, onTap: () -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val state = rememberTransformableState { zoom, pan, _ ->
        scale = (scale * zoom).coerceIn(1f, 6f)
        offset = if (scale == 1f) Offset.Zero else offset + pan
    }
    LaunchedEffect(scale > 1f, active) { if (active) onZoom(scale > 1f) }
    val appCtx = LocalContext.current.applicationContext
    // This loader can decode animated GIFs, so they play in the viewer.
    val gifLoader = remember(appCtx) {
        coil.ImageLoader.Builder(appCtx).components { add(coil.decode.ImageDecoderDecoder.Factory()) }.build()
    }
    AsyncImage(
        model = m.uri, imageLoader = gifLoader, contentDescription = m.name, contentScale = ContentScale.Fit,
        modifier = Modifier.fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = { scale = if (scale > 1f) 1f else 2.5f; offset = Offset.Zero }
                )
            }
            .transformable(state, canPan = { scale > 1f })
            .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y)
    )
}

@Composable
private fun VideoPage(m: GalleryMedia, active: Boolean, showUi: Boolean) {
    val ctx = LocalContext.current
    val player = remember(m.id) {
        ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(m.uri)); prepare() }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(m.duration.coerceAtLeast(1L)) }
    var playing by remember { mutableStateOf(false) }
    var muted by remember { mutableStateOf(false) }
    LaunchedEffect(active) { if (!active) player.pause() }
    LaunchedEffect(player) {
        while (true) {
            pos = player.currentPosition
            if (player.duration > 0) dur = player.duration
            playing = player.isPlaying
            delay(100)
        }
    }
    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = { c -> PlayerView(c).also { v -> v.useController = false; v.player = player } },
            modifier = Modifier.fillMaxSize()
        )
        if (showUi) Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 150.dp)) {
            Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 10.dp)) {
                Row(
                    Modifier.align(Alignment.Center).clip(RoundedCornerShape(24.dp)).background(PillBg)
                        .clickable {
                            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
                            if (player.isPlaying) player.pause() else player.play()
                        }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text("${fmtClock(pos)} / ${fmtClock(dur)}", color = Color.White, fontSize = 14.sp)
                }
                CircleButton(
                    if (muted) Icons.Filled.VolumeOff else Icons.Filled.VolumeUp, "Volume",
                    { muted = !muted; player.volume = if (muted) 0f else 1f },
                    Modifier.align(Alignment.CenterEnd)
                )
            }
            VideoScrubber(m, dur, pos) { player.seekTo(it) }
        }
    }
}
