@file:OptIn(UnstableApi::class, ExperimentalFoundationApi::class)

package com.example.opengallery.ui

import android.content.Intent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitVerticalTouchSlopOrCancellation
import androidx.compose.foundation.gestures.drag
import androidx.compose.animation.core.tween
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.border
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.GalleryMedia
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ViewerScreen(vm: GalleryViewModel, nav: NavController, startIndex: Int, slideshow: Boolean) {
    val list = vm.viewerList
    val actions = rememberFileActions(vm::refresh)
    val favs by vm.favorites.collectAsState()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var showUi by remember { mutableStateOf(true) }
    var dialog by remember { mutableStateOf<String?>(null) }
    if (list.isEmpty()) {
        LaunchedEffect(Unit) { nav.popBackStack() }
        return
    }
    val pager = rememberPagerState(startIndex.coerceIn(0, list.lastIndex)) { list.size }
    // Make the viewer's window cover the whole screen, including behind the navigation bar (no gap at the bottom).
    val hostView = androidx.compose.ui.platform.LocalView.current
    androidx.compose.runtime.SideEffect {
        val w = (hostView.parent as? androidx.compose.ui.window.DialogWindowProvider)?.window
        if (w != null) {
            w.setLayout(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT)
            w.setGravity(android.view.Gravity.FILL)
            val lp = w.attributes
            lp.width = android.view.ViewGroup.LayoutParams.MATCH_PARENT
            lp.height = android.view.ViewGroup.LayoutParams.MATCH_PARENT
            lp.flags = lp.flags or android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
            w.attributes = lp
            androidx.core.view.WindowCompat.setDecorFitsSystemWindows(w, false)
            w.addFlags(android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
            w.setDimAmount(0f)
            w.navigationBarColor = android.graphics.Color.TRANSPARENT
            w.statusBarColor = android.graphics.Color.TRANSPARENT
            if (android.os.Build.VERSION.SDK_INT >= 29) w.isNavigationBarContrastEnforced = false
        }
    }
    var zoomed by remember { mutableStateOf(false) }
    // Hide the viewer the instant "back" is pressed; the heavy clean-up happens after it is already gone.
    var closing by remember { mutableStateOf(false) }
    var closeCtl by remember { mutableStateOf<VideoCtl?>(null) }
    val closeViewer: () -> Unit = {
        if (!closing) {
            closing = true
            closeCtl?.player?.pause()
            nav.popBackStack()
        }
    }
    androidx.activity.compose.BackHandler(enabled = !closing) { closeViewer() }
    var vctl by remember { mutableStateOf<VideoCtl?>(null) }
    var stripExpanded by remember { mutableStateOf(false) }
    var stripTouch by remember { mutableLongStateOf(0L) }
    var shot by remember { mutableStateOf<Shot?>(null) }
    var dragY by remember { mutableFloatStateOf(0f) }
    var dragX by remember { mutableFloatStateOf(0f) }
    val dragging by remember { androidx.compose.runtime.derivedStateOf { dragX != 0f || dragY != 0f } }
    val current = list[pager.currentPage.coerceIn(0, list.lastIndex)]
    val ctl = vctl?.takeIf { it.media.id == current.id }
    closeCtl = ctl
    // The frame strip shrinks back to the thumbnails a few seconds after you stop touching it.
    LaunchedEffect(stripExpanded, stripTouch) { if (stripExpanded) { delay(3500); stripExpanded = false } }
    val capture: (VideoCtl) -> Unit = { c ->
        val posMs = c.pos
        scope.launch {
            val res = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching {
                    val r = android.media.MediaMetadataRetriever()
                    r.setDataSource(ctx, c.media.uri)
                    val bmp = r.getFrameAtTime(posMs * 1000, android.media.MediaMetadataRetriever.OPTION_CLOSEST)
                    r.release()
                    if (bmp == null) null else saveShot(ctx, bmp)?.let { id -> id to bmp }
                }.getOrNull()
            }
            if (res != null) {
                vm.refresh()
                shot = Shot(res.first, res.second.asImageBitmap(), c.media.id, posMs)
            } else {
                android.widget.Toast.makeText(ctx, "Couldn't capture this frame", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }
    if (slideshow) LaunchedEffect(Unit) {
        while (pager.currentPage < list.lastIndex) {
            delay(3000)
            pager.animateScrollToPage(pager.currentPage + 1)
        }
        nav.popBackStack()
    }

    Box(
        Modifier.fillMaxSize().graphicsLayer { alpha = if (closing) 0f else 1f }
            // The page behind (the album / search results) shows through as the picture is dragged away.
            .drawBehind {
                val dist = kotlin.math.hypot(dragX, dragY)
                drawRect(Color.Black.copy(alpha = (1f - dist / 700f).coerceIn(0f, 1f)))
            }
            .pointerInput(zoomed) {
                if (zoomed) return@pointerInput
                // Slide a finger down: the picture shrinks and follows your finger anywhere on screen.
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val slop = awaitVerticalTouchSlopOrCancellation(down.id) { change, over ->
                        if (over > 0f) change.consume()
                    } ?: return@awaitEachGesture
                    val tracker = VelocityTracker()
                    tracker.addPosition(slop.uptimeMillis, slop.position)
                    val ok = drag(slop.id) { change ->
                        val d = change.positionChange()
                        dragX += d.x; dragY += d.y
                        tracker.addPosition(change.uptimeMillis, change.position)
                        change.consume()
                    }
                    val v = tracker.calculateVelocity()
                    val dist = kotlin.math.hypot(dragX, dragY)
                    if (ok && (dist > 260f || v.y > 1800f) && dragY > 0f) {
                        scope.launch {
                            val sx = dragX; val sy = dragY
                            animate(0f, 1f, animationSpec = tween(160)) { t, _ ->
                                dragX = sx * (1f + t); dragY = sy + 400f * t
                            }
                            closeViewer()
                        }
                    } else {
                        scope.launch {
                            val sx = dragX; val sy = dragY
                            animate(1f, 0f, animationSpec = spring(stiffness = 500f)) { t, _ -> dragX = sx * t; dragY = sy * t }
                        }
                    }
                }
            }
    ) {
        HorizontalPager(
            pager,
            Modifier.fillMaxSize().graphicsLayer {
                val dist = kotlin.math.hypot(dragX, dragY)
                val f = (1f - dist / 1400f).coerceIn(0.5f, 1f)
                translationX = dragX; translationY = dragY; scaleX = f; scaleY = f
            }
        ) { page ->
            val m = list[page]
            if (m.isVideo) VideoPage(
                m, pager.currentPage == page, vm.resumeVideo,
                onResumed = { vm.resumeVideo = null }, onCtl = { vctl = it }, onTap = { showUi = !showUi }
            )
            else ZoomImage(m, pager.currentPage == page, { zoomed = it }) { showUi = !showUi }
        }
        if (showUi && !dragging) {
            Row(
                Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                CircleButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", { closeViewer() })
                PillActions { close ->
                    MenuItem("Details") { close(); dialog = "details" }
                    if (current.isVideo) MenuItem("Open in video player") {
                        close()
                        val i = Intent(Intent.ACTION_VIEW).setDataAndType(current.uri, "video/*")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        runCatching { ctx.startActivity(i) }
                    } else MenuItem("Set as wallpaper") {
                        close()
                        val i = Intent(Intent.ACTION_ATTACH_DATA).setDataAndType(current.uri, "image/*")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        runCatching { ctx.startActivity(Intent.createChooser(i, "Set as")) }
                    }
                    MenuItem("Copy to album") { close(); dialog = "copy" }
                    MenuItem("Move to album") { close(); dialog = "move" }
                }
            }
            Column(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 78.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (ctl != null) {
                    VideoControlRow(ctl) { capture(ctl) }
                    Spacer(Modifier.height(8.dp))
                    if (stripExpanded) VideoScrubber(ctl.media, ctl.dur, ctl.pos) { t ->
                        stripTouch = System.currentTimeMillis(); ctl.player.seekTo(t)
                    } else Filmstrip(list, pager.currentPage, { i -> scope.launch { pager.scrollToPage(i) } }) {
                        stripExpanded = true; stripTouch = System.currentTimeMillis()
                    }
                } else Filmstrip(list, pager.currentPage, { i -> scope.launch { pager.scrollToPage(i) } })
                Spacer(Modifier.height(10.dp))
                ActionPill {
                    PillAction(if (current.id in favs) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null) {
                        vm.toggleFavorite(listOf(current.id), current.id !in favs)
                    }
                    PillAction(Icons.Filled.Edit, null) {
                        // The viewer is a dialog destination, so close it first, then open the editor.
                        val route = if (current.isVideo) "editor/${current.id}" else "photoeditor/${current.id}"
                        nav.popBackStack()
                        nav.navigate(route)
                    }
                    PillAction(Icons.Filled.Share, null) { actions.share(listOf(current)) }
                    PillAction(Icons.Filled.Delete, null) { actions.trash(listOf(current)) { nav.popBackStack() } }
                }
            }
        }
    }

    // Samsung-style screenshot preview: pops in, stays about 3 seconds, then fades away.
    var shotShown by remember { mutableStateOf<Shot?>(null) }
    var shotVisible by remember { mutableStateOf(false) }
    LaunchedEffect(shot) {
        val s0 = shot
        if (s0 != null) {
            shotShown = s0; shotVisible = true
            delay(3000)
            shotVisible = false
            delay(400)
            if (shotShown === s0) shotShown = null
            if (shot === s0) shot = null
        }
    }
    shotShown?.let { sh ->
        Box(Modifier.fillMaxSize()) {
            androidx.compose.animation.AnimatedVisibility(
                visible = shotVisible,
                modifier = Modifier.align(Alignment.BottomStart).padding(start = 16.dp, bottom = 250.dp),
                enter = androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(180)) +
                    androidx.compose.animation.scaleIn(
                        initialScale = 0.5f, transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 1f),
                        animationSpec = androidx.compose.animation.core.spring(dampingRatio = 0.6f, stiffness = 380f)
                    ) + androidx.compose.animation.slideInVertically(androidx.compose.animation.core.tween(220)) { it / 3 },
                exit = androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(350)) +
                    androidx.compose.animation.scaleOut(
                        targetScale = 0.85f, transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 1f),
                        animationSpec = androidx.compose.animation.core.tween(350)
                    )
            ) {
                val ratio = (sh.bitmap.width.toFloat() / sh.bitmap.height.toFloat()).coerceIn(0.5f, 2f)
                androidx.compose.foundation.Image(
                    bitmap = sh.bitmap, contentDescription = "Screenshot",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.width(110.dp).aspectRatio(ratio).clip(RoundedCornerShape(8.dp))
                        .clickable {
                            val s2 = sh; shot = null; shotVisible = false
                            scope.launch {
                                var tries = 0
                                while (vm.media.value.none { it.id == s2.id } && tries < 40) { delay(100); tries++ }
                                vm.resumeVideo = s2.videoId to s2.posMs
                                vm.pendingReturn = "viewer/${pager.currentPage}/0"
                                nav.popBackStack()
                                nav.navigate("photoeditor/${s2.id}")
                            }
                        }
                )
            }
        }
    }

    when (dialog) {
        "details" -> DetailsDialog(current) { dialog = null }
        "copy" -> AlbumMovePicker(vm, actions, listOf(current), move = false, onDismiss = { dialog = null }, onDone = { dialog = null })
        "move" -> AlbumMovePicker(vm, actions, listOf(current), move = true, onDismiss = { dialog = null }, onDone = { dialog = null; nav.popBackStack() })
    }
}

/** Small thumbnail strip above the action bar; the current item is slightly bigger. */
@Composable
private fun Filmstrip(list: List<GalleryMedia>, current: Int, onPick: (Int) -> Unit, onCurrent: () -> Unit = {}) {
    val state = rememberLazyListState()
    androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxWidth().height(72.dp)) {
        // Half-screen padding on both sides lets the current item sit exactly in the middle.
        val side = (maxWidth / 2 - 26.dp).coerceAtLeast(0.dp)
        LaunchedEffect(current) { state.animateScrollToItem(current) }
        LazyRow(
            state = state,
            modifier = Modifier.fillMaxSize().pointerInput(current) { detectTapGestures { onCurrent() } },
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            contentPadding = PaddingValues(horizontal = side),
            verticalAlignment = Alignment.CenterVertically
        ) {
            itemsIndexed(list) { i, m ->
                val cur = i == current
                Box(
                    Modifier.height(if (cur) 68.dp else 54.dp).width(if (cur) 52.dp else 40.dp)
                        .clip(RoundedCornerShape(7.dp)).clickable { if (cur) onCurrent() else onPick(i) }
                ) {
                    MediaImage(m, Modifier.fillMaxSize())
                    if (m.isVideo) androidx.compose.material3.Icon(
                        Icons.Filled.PlayArrow, null, tint = Color.White,
                        modifier = Modifier.align(Alignment.BottomStart).size(14.dp).padding(1.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ZoomImage(m: GalleryMedia, active: Boolean, onZoom: (Boolean) -> Unit, onTap: () -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val state = rememberTransformableState { zoom, pan, _ ->
        scale = (scale * zoom).coerceIn(1f, 6f)
        offset = if (scale == 1f) Offset.Zero else offset + pan
    }
    LaunchedEffect(scale > 1f, active) { if (active) onZoom(scale > 1f) }
    val appCtx = LocalContext.current.applicationContext
    // This loader can decode animated GIFs, so they play in the viewer.
    val gifLoader = remember(appCtx) {
        coil.ImageLoader.Builder(appCtx).components { add(coil.decode.ImageDecoderDecoder.Factory()) }.build()
    }
    AsyncImage(
        model = m.uri, imageLoader = gifLoader, contentDescription = m.name, contentScale = ContentScale.Fit,
        modifier = Modifier.fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = { scale = if (scale > 1f) 1f else 2.5f; offset = Offset.Zero }
                )
            }
            .transformable(state, canPan = { scale > 1f })
            .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y)
    )
}

/** What the viewer needs from the video that is on screen (progress, player). */
private class VideoCtl(val player: ExoPlayer, val media: GalleryMedia) {
    var pos by mutableLongStateOf(0L)
    var dur by mutableLongStateOf(media.duration.coerceAtLeast(1L))
    var playing by mutableStateOf(false)
}

private class Shot(val id: Long, val bitmap: androidx.compose.ui.graphics.ImageBitmap, val videoId: Long, val posMs: Long)

/** Saves a captured video frame to Pictures/Screenshots and returns its MediaStore id. */
private fun saveShot(ctx: android.content.Context, bmp: android.graphics.Bitmap): Long? {
    val res = ctx.contentResolver
    val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
    val v = android.content.ContentValues().apply {
        put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, "Screenshot_${stamp}_Gallery.jpg")
        put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Screenshots/")
        put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1)
    }
    val uri = res.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return null
    res.openOutputStream(uri)?.use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 95, it) } ?: return null
    v.clear(); v.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0)
    res.update(uri, v, null, null)
    return android.content.ContentUris.parseId(uri)
}

/** After editing a screenshot taken from a video: leave the editor and go back to that video. */
fun exitEditor(vm: GalleryViewModel, nav: NavController) {
    nav.popBackStack()
    vm.pendingReturn?.let { vm.pendingReturn = null; nav.navigate(it) }
}

/** [capture]  [ > 00:06 / 00:27 ]  [volume] */
@Composable
private fun VideoControlRow(ctl: VideoCtl, onCapture: () -> Unit) {
    var muted by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        CircleButton(Icons.Filled.CropFree, "Capture frame", onCapture, Modifier.align(Alignment.CenterStart))
        Row(
            Modifier.align(Alignment.Center).clip(RoundedCornerShape(24.dp)).background(PillBg)
                .clickable {
                    val p = ctl.player
                    if (p.playbackState == Player.STATE_ENDED) p.seekTo(0)
                    if (p.isPlaying) p.pause() else p.play()
                }
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(if (ctl.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = Color.White)
            Spacer(Modifier.width(8.dp))
            Text("${fmtClock(ctl.pos)} / ${fmtClock(ctl.dur)}", color = Color.White, fontSize = 14.sp)
        }
        CircleButton(
            if (muted) Icons.Filled.VolumeOff else Icons.Filled.VolumeUp, "Volume",
            { muted = !muted; ctl.player.volume = if (muted) 0f else 1f },
            Modifier.align(Alignment.CenterEnd)
        )
    }
}

@Composable
private fun VideoPage(
    m: GalleryMedia, active: Boolean, resume: Pair<Long, Long>?,
    onResumed: () -> Unit, onCtl: (VideoCtl) -> Unit, onTap: () -> Unit
) {
    val ctx = LocalContext.current
    // The player is built a moment after the page appears (and only for the page on screen), so switching
    // between files doesn't stutter; a still frame is shown until the first video frame is ready.
    var player by remember(m.id) { mutableStateOf<ExoPlayer?>(null) }
    LaunchedEffect(m.id, active) {
        if (active && player == null) {
            delay(150)
            player = ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(m.uri)); prepare() }
        }
    }
    DisposableEffect(m.id) {
        onDispose {
            val p = player
            if (p != null) {
                p.pause()
                // Releasing blocks for a moment: do it after the screen has already closed / changed.
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ p.release() }, 400)
            }
        }
    }
    val pl = player
    val ctl = remember(pl) { pl?.let { VideoCtl(it, m) } }
    LaunchedEffect(active, ctl) { if (active && ctl != null) onCtl(ctl) }
    LaunchedEffect(active, pl) { if (!active) pl?.pause() }
    LaunchedEffect(pl) {
        if (pl == null || ctl == null) return@LaunchedEffect
        if (resume != null && resume.first == m.id) {
            pl.seekTo(resume.second); pl.pause(); onResumed()
        }
        while (true) {
            ctl.pos = pl.currentPosition
            if (pl.duration > 0) ctl.dur = pl.duration
            ctl.playing = pl.isPlaying
            delay(100)
        }
    }
    Box(Modifier.fillMaxSize()) {
        val ratio = if (m.width > 0 && m.height > 0) m.width.toFloat() / m.height else 16f / 9f
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            MediaImage(m, Modifier.aspectRatio(ratio))
        }
        if (pl != null) AndroidView(
            factory = { c ->
                PlayerView(c).also { v ->
                    v.useController = false
                    v.setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                    v.player = pl
                }
            },
            update = { v -> if (v.player !== pl) v.player = pl },
            onRelease = { v -> v.player = null },
            modifier = Modifier.fillMaxSize()
        )
        Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { onTap() } })
    }
}
