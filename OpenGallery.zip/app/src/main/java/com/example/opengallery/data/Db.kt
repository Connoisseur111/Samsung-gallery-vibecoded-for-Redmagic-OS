package com.example.opengallery.data

import android.content.Context
import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

/** A virtual, in-app album (isGroup = false) or a group of albums (isGroup = true). */
@Entity(
    tableName = "albums",
    foreignKeys = [ForeignKey(
        entity = AlbumEntity::class, parentColumns = ["id"],
        childColumns = ["parentId"], onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("parentId")]
)
data class AlbumEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val parentId: Long? = null, // legacy, unused
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "0") val isGroup: Boolean = false
)

/** Links a MediaStore item to an album (the file itself is never moved or copied). */
@Entity(
    tableName = "album_items",
    primaryKeys = ["albumId", "mediaId"],
    foreignKeys = [ForeignKey(
        entity = AlbumEntity::class, parentColumns = ["id"],
        childColumns = ["albumId"], onDelete = ForeignKey.CASCADE
    )]
)
data class AlbumItemEntity(
    val albumId: Long,
    val mediaId: Long,
    val addedAt: Long = System.currentTimeMillis()
)

/** An album (by key, e.g. "folder:123" or "album:4") that lives inside a group. */
@Entity(
    tableName = "group_members",
    primaryKeys = ["groupId", "albumKey"],
    foreignKeys = [ForeignKey(
        entity = AlbumEntity::class, parentColumns = ["id"],
        childColumns = ["groupId"], onDelete = ForeignKey.CASCADE
    )]
)
data class GroupMemberEntity(val groupId: Long, val albumKey: String)

@Entity(tableName = "favorites")
data class FavoriteEntity(@PrimaryKey val mediaId: Long)

@Dao
interface AlbumDao {
    @Query("SELECT * FROM albums") fun allAlbums(): Flow<List<AlbumEntity>>
    @Query("SELECT * FROM album_items") fun allLinks(): Flow<List<AlbumItemEntity>>
    @Query("SELECT * FROM group_members") fun allMembers(): Flow<List<GroupMemberEntity>>
    @Query("SELECT mediaId FROM favorites") fun allFavorites(): Flow<List<Long>>

    @Insert suspend fun insert(album: AlbumEntity): Long

    @Query("UPDATE albums SET name = :name WHERE id = :id")
    suspend fun rename(id: Long, name: String)

    @Query("DELETE FROM albums WHERE id = :id")
    suspend fun delete(id: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addItems(items: List<AlbumItemEntity>)

    @Query("DELETE FROM album_items WHERE albumId = :albumId AND mediaId IN (:ids)")
    suspend fun removeItems(albumId: Long, ids: List<Long>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addMembers(members: List<GroupMemberEntity>)

    @Query("DELETE FROM group_members WHERE groupId = :groupId AND albumKey = :key")
    suspend fun removeMember(groupId: Long, key: String)

    @Query("DELETE FROM group_members WHERE albumKey = :key")
    suspend fun removeMemberKey(key: String)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addFavorites(items: List<FavoriteEntity>)

    @Query("DELETE FROM favorites WHERE mediaId IN (:ids)")
    suspend fun removeFavorites(ids: List<Long>)
}

private val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE albums ADD COLUMN isGroup INTEGER NOT NULL DEFAULT 0")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS group_members (groupId INTEGER NOT NULL, albumKey TEXT NOT NULL, " +
                "PRIMARY KEY(groupId, albumKey), " +
                "FOREIGN KEY(groupId) REFERENCES albums(id) ON UPDATE NO ACTION ON DELETE CASCADE)"
        )
        db.execSQL("CREATE TABLE IF NOT EXISTS favorites (mediaId INTEGER NOT NULL, PRIMARY KEY(mediaId))")
    }
}

@Database(
    entities = [AlbumEntity::class, AlbumItemEntity::class, GroupMemberEntity::class, FavoriteEntity::class],
    version = 2, exportSchema = false
)
abstract class GalleryDb : RoomDatabase() {
    abstract fun albumDao(): AlbumDao

    companion object {
        @Volatile private var inst: GalleryDb? = null
        fun get(c: Context): GalleryDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, GalleryDb::class.java, "gallery.db")
                .addMigrations(MIGRATION_1_2)
                .build().also { inst = it }
        }
    }
}
