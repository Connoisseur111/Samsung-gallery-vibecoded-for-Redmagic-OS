package com.example.opengallery.ui

import com.example.opengallery.data.AlbumEntity
import com.example.opengallery.data.AlbumItemEntity
import com.example.opengallery.data.GalleryMedia
import com.example.opengallery.data.GroupMemberEntity

enum class Kind { RECENT, FAVORITES, FOLDER, CUSTOM, GROUP }

data class AlbumInfo(
    val key: String,
    val title: String,
    val count: Int,
    val cover: GalleryMedia?,
    val kind: Kind,
    val id: Long,
    val latest: Long,
    val modified: Long,
    val size: Long,
    val covers: List<GalleryMedia>
)

data class AlbumsModel(val topLevel: List<AlbumInfo>, val byKey: Map<String, AlbumInfo>)

fun mediaForKey(
    key: String,
    media: List<GalleryMedia>,
    links: List<AlbumItemEntity>,
    favorites: Set<Long>
): List<GalleryMedia> = when {
    key == "recent" -> media
    key == "favorites" -> media.filter { it.id in favorites }
    key == "videos" -> media.filter { it.isVideo }
    key.startsWith("folder:") -> {
        val id = key.removePrefix("folder:").toLongOrNull()
        media.filter { it.bucketId == id }
    }
    key.startsWith("album:") -> {
        val id = key.removePrefix("album:").toLongOrNull()
        val ids = links.filter { it.albumId == id }.map { it.mediaId }.toSet()
        media.filter { it.id in ids }
    }
    else -> emptyList()
}

fun titleForKey(key: String, albums: List<AlbumEntity>, base: List<GalleryMedia>): String = when {
    key == "recent" -> "Recent"
    key == "favorites" -> "Favorites"
    key == "videos" -> "Videos"
    key.startsWith("album:") -> {
        val id = key.removePrefix("album:").toLongOrNull()
        albums.firstOrNull { it.id == id }?.name ?: "Album"
    }
    else -> base.firstOrNull()?.bucketName ?: "Album"
}

fun buildAlbums(
    media: List<GalleryMedia>,
    albums: List<AlbumEntity>,
    links: List<AlbumItemEntity>,
    members: List<GroupMemberEntity>,
    favorites: Set<Long>
): AlbumsModel {
    fun info(key: String, title: String, kind: Kind, id: Long, list: List<GalleryMedia>, created: Long = 0L): AlbumInfo {
        val sorted = list.sortedByDescending { it.dateTaken }
        return AlbumInfo(
            key = key, title = title, count = list.size, cover = sorted.firstOrNull(), kind = kind, id = id,
            latest = sorted.firstOrNull()?.dateTaken ?: created,
            modified = list.maxOfOrNull { it.dateModified } ?: created,
            size = list.sumOf { it.size },
            covers = sorted.take(3)
        )
    }

    val byId = media.associateBy { it.id }
    val folders = media.groupBy { it.bucketId }
        .map { (id, l) -> info("folder:$id", l.first().bucketName, Kind.FOLDER, id, l) }
    val customs = albums.filter { !it.isGroup }.map { a ->
        val l = links.filter { it.albumId == a.id }.mapNotNull { byId[it.mediaId] }
        info("album:${a.id}", a.name, Kind.CUSTOM, a.id, l, a.createdAt)
    }
    val leaves = folders + customs
    val leafByKey = leaves.associateBy { it.key }
    val groups = albums.filter { it.isGroup }.map { g ->
        val keys = members.filter { it.groupId == g.id }.map { it.albumKey }
        val ms = keys.mapNotNull { leafByKey[it] }
        AlbumInfo(
            key = "group:${g.id}", title = g.name, count = ms.size, cover = ms.firstOrNull()?.cover,
            kind = Kind.GROUP, id = g.id,
            latest = ms.maxOfOrNull { it.latest } ?: g.createdAt,
            modified = ms.maxOfOrNull { it.modified } ?: g.createdAt,
            size = ms.sumOf { it.size },
            covers = ms.mapNotNull { it.cover }.take(3)
        )
    }
    val grouped = members.map { it.albumKey }.toSet()
    val recent = info("recent", "Recent", Kind.RECENT, 0L, media)
    val fav = if (favorites.isEmpty()) null
    else info("favorites", "Favorites", Kind.FAVORITES, 0L, media.filter { it.id in favorites })
    val orderedFolders = folders.filter { it.key !in grouped }.sortedWith(
        compareByDescending<AlbumInfo> { it.title == "Camera" }
            .thenByDescending { it.title == "Screenshots" }
            .thenByDescending { it.count }
    )
    val top = listOfNotNull(recent, fav) + groups + customs.filter { it.key !in grouped } + orderedFolders
    val all = (top + leaves + groups).associateBy { it.key }
    return AlbumsModel(top, all)
}
