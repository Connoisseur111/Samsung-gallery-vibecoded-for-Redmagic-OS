package com.example.opengallery

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.dialog
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import com.example.opengallery.ui.AddItemsScreen
import com.example.opengallery.ui.AlbumScreen
import com.example.opengallery.ui.AllAlbumsScreen
import com.example.opengallery.ui.GalleryTheme
import com.example.opengallery.ui.GroupScreen
import com.example.opengallery.ui.MainScreen
import com.example.opengallery.ui.PhotoEditorScreen
import com.example.opengallery.ui.SearchScreen
import com.example.opengallery.ui.SettingsScreen
import com.example.opengallery.ui.TrashScreen
import com.example.opengallery.ui.VideoEditorScreen
import com.example.opengallery.ui.ViewerScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GalleryTheme {
                Box(Modifier.fillMaxSize().background(Color.Black)) { PermissionGate { GalleryApp() } }
            }
        }
    }
}

@Composable
private fun PermissionGate(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val perms = arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    var granted by remember {
        mutableStateOf(perms.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED })
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        granted = r.values.all { it }
    }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(perms) }
    if (granted) content() else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Button(onClick = { launcher.launch(perms) }, modifier = Modifier.padding(24.dp)) {
            Text("Allow access to photos and videos")
        }
    }
}

@Composable
fun GalleryApp() {
    val vm: GalleryViewModel = viewModel()
    val nav = rememberNavController()
    LaunchedEffect(Unit) { vm.refresh() }
    val longArg = listOf(navArgument("id") { type = NavType.LongType })
    val strArg = listOf(navArgument("key") { type = NavType.StringType })
    val favIds by vm.favorites.collectAsState()
    val backEntry by nav.currentBackStackEntryAsState()
    val viewerOpen = backEntry?.destination?.route?.startsWith("viewer") == true
    androidx.compose.runtime.CompositionLocalProvider(com.example.opengallery.ui.LocalFavorites provides favIds) {
    // Short fades: the default is a 700 ms cross-fade, which made backing out of an album feel delayed.
    NavHost(
        nav, startDestination = "main",
        enterTransition = { androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(120)) },
        exitTransition = { androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(90)) },
        popEnterTransition = { androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(120)) },
        popExitTransition = { androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(90)) }
    ) {
        composable("main") { MainScreen(vm, nav) }
        composable("allalbums") { AllAlbumsScreen(vm, nav) }
        composable("group/{id}", longArg) { GroupScreen(vm, nav, it.arguments!!.getLong("id")) }
        composable("album/{key}", strArg) { AlbumScreen(vm, nav, Uri.decode(it.arguments!!.getString("key")!!)) }
        composable("additems/{id}", longArg) { AddItemsScreen(vm, nav, it.arguments!!.getLong("id")) }
        // A dialog destination keeps the previous screen on display behind the viewer (see-through while dragging).
        dialog(
            "viewer/{index}/{slideshow}",
            listOf(navArgument("index") { type = NavType.IntType }, navArgument("slideshow") { type = NavType.IntType }),
            dialogProperties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false, decorFitsSystemWindows = false
            )
        ) { ViewerScreen(vm, nav, it.arguments!!.getInt("index"), it.arguments!!.getInt("slideshow") == 1) }
        composable("editor/{id}", longArg) { VideoEditorScreen(vm, nav, it.arguments!!.getLong("id")) }
        composable("photoeditor/{id}", longArg) { PhotoEditorScreen(vm, nav, it.arguments!!.getLong("id")) }
        composable("search/{key}", strArg) { SearchScreen(vm, nav, Uri.decode(it.arguments!!.getString("key")!!)) }
        composable("trash") { TrashScreen(vm, nav) }
        composable("settings") { SettingsScreen(vm, nav) }
    }
    // The viewer is a floating window that stops a few pixels short of the bottom edge: keep that sliver black.
    if (viewerOpen) androidx.compose.foundation.layout.Box(
        Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter
    ) {
        // Tall on purpose: the viewer window is drawn above this, so a taller strip can never hide viewer content,
        // but it always covers the gap whatever its height is on this phone (nav buttons vs gesture bar).
        Box(Modifier.fillMaxWidth().height(120.dp).background(Color.Black))
    }
    }
}
