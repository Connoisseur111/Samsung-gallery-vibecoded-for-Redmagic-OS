@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.opengallery.ui

import android.app.Activity
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.AppSettings
import com.example.opengallery.data.GalleryMedia
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Real file operations through MediaStore.
 *  - trash / restore / deleteForever: Android shows its own confirmation dialog
 *  - move: changes the folder on disk (Android asks for write access first)
 *  - copy: writes a duplicate into the target folder
 * A target containing '/' is an existing folder path (e.g. "DCIM/Camera/"); anything else is a new folder name.
 */
class FileActions(
    private val ctx: Context,
    private val scope: CoroutineScope,
    private val onChanged: () -> Unit,
    private val request: (PendingIntent, (Boolean) -> Unit) -> Unit
) {
    private fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    private fun targetPath(m: GalleryMedia, target: String): String =
        if ('/' in target) target else (if (m.isVideo) "Movies/" else "Pictures/") + target + "/"

    fun share(items: List<GalleryMedia>) {
        if (items.isEmpty()) return
        val intent = if (items.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = ctx.contentResolver.getType(items[0].uri) ?: if (items[0].isVideo) "video/*" else "image/*"
                putExtra(Intent.EXTRA_STREAM, items[0].uri)
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "*/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(items.map { it.uri }))
            }
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        runCatching { ctx.startActivity(Intent.createChooser(intent, "Share")) }
    }

    /** True when the user turned the confirmation off AND allowed "Media management" in system settings. */
    private fun direct(): Boolean = !AppSettings.askBeforeDelete && MediaStore.canManageMedia(ctx)

    private fun directMove(): Boolean = !AppSettings.askBeforeMove && MediaStore.canManageMedia(ctx)

    private fun runDirect(
        items: List<GalleryMedia>, done: (Int) -> Unit,
        onProgress: (Int) -> Unit = {}, isCancelled: () -> Boolean = { false },
        op: (GalleryMedia) -> Boolean
    ) {
        scope.launch {
            val n = withContext(Dispatchers.IO) {
                var ok = 0
                for ((i, m) in items.withIndex()) {
                    if (isCancelled()) break
                    if (runCatching { op(m) }.getOrDefault(false)) ok++
                    onProgress(i + 1)
                }
                ok
            }
            done(n)
        }
    }

    private fun setTrashed(m: GalleryMedia, trashed: Boolean): Boolean {
        val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_TRASHED, if (trashed) 1 else 0) }
        return ctx.contentResolver.update(m.uri, v, null, null) > 0
    }

    fun trash(items: List<GalleryMedia>, onDone: () -> Unit = {}) {
        if (items.isEmpty()) return
        val prompt = {
            val pi = MediaStore.createTrashRequest(ctx.contentResolver, items.map { it.uri }, true)
            request(pi) { ok ->
                if (ok) { toast("Moved ${items.size} item(s) to trash"); onChanged(); onDone() }
            }
        }
        if (direct()) runDirect(items, { n ->
            if (n > 0) { toast("Moved $n item(s) to trash"); onChanged(); onDone() } else prompt()
        }) { m -> setTrashed(m, true) }
        else prompt()
    }

    fun restore(items: List<GalleryMedia>, onDone: () -> Unit = {}) {
        if (items.isEmpty()) return
        val prompt = {
            val pi = MediaStore.createTrashRequest(ctx.contentResolver, items.map { it.uri }, false)
            request(pi) { ok -> if (ok) { toast("Restored ${items.size} item(s)"); onChanged(); onDone() } }
        }
        if (direct()) runDirect(items, { n ->
            if (n > 0) { toast("Restored $n item(s)"); onChanged(); onDone() } else prompt()
        }) { m -> setTrashed(m, false) }
        else prompt()
    }

    fun deleteForever(items: List<GalleryMedia>, onDone: () -> Unit = {}) {
        if (items.isEmpty()) return
        val prompt = {
            val pi = MediaStore.createDeleteRequest(ctx.contentResolver, items.map { it.uri })
            request(pi) { ok -> if (ok) { toast("Deleted ${items.size} item(s)"); onChanged(); onDone() } }
        }
        if (direct()) runDirect(items, { n ->
            if (n > 0) { toast("Deleted $n item(s)"); onChanged(); onDone() } else prompt()
        }) { m -> ctx.contentResolver.delete(m.uri, null, null) > 0 }
        else prompt()
    }

    private fun moveOp(m: GalleryMedia, target: String): Boolean {
        val v = ContentValues().apply { put(MediaStore.MediaColumns.RELATIVE_PATH, targetPath(m, target)) }
        return ctx.contentResolver.update(m.uri, v, null, null) > 0
    }

    fun move(
        items: List<GalleryMedia>, target: String, onDone: () -> Unit = {},
        onProgress: (Int) -> Unit = {}, isCancelled: () -> Boolean = { false }
    ) {
        if (items.isEmpty()) return
        val finish = { n: Int ->
            toast(if (n == items.size) "Move completed." else "Moved $n of ${items.size}")
            onChanged(); onDone()
        }
        if (directMove()) {
            runDirect(items, finish, onProgress, isCancelled) { m -> moveOp(m, target) }
            return
        }
        val pi = MediaStore.createWriteRequest(ctx.contentResolver, items.map { it.uri })
        request(pi) { ok ->
            if (ok) runDirect(items, finish, onProgress, isCancelled) { m -> moveOp(m, target) }
            else onDone()
        }
    }

    fun copy(
        items: List<GalleryMedia>, target: String, onDone: () -> Unit = {},
        onProgress: (Int) -> Unit = {}, isCancelled: () -> Boolean = { false }
    ) {
        scope.launch {
            val n = withContext(Dispatchers.IO) {
                var done = 0
                items.count { m ->
                    if (isCancelled()) return@count false
                    val r = runCatching {
                        val res = ctx.contentResolver
                        val v = ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, m.name)
                            put(MediaStore.MediaColumns.MIME_TYPE, res.getType(m.uri) ?: if (m.isVideo) "video/mp4" else "image/jpeg")
                            put(MediaStore.MediaColumns.RELATIVE_PATH, targetPath(m, target))
                            put(MediaStore.MediaColumns.IS_PENDING, 1)
                        }
                        val base = if (m.isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                        val dst = res.insert(base, v)!!
                        res.openInputStream(m.uri)!!.use { i -> res.openOutputStream(dst)!!.use { o -> i.copyTo(o) } }
                        v.clear(); v.put(MediaStore.MediaColumns.IS_PENDING, 0)
                        res.update(dst, v, null, null)
                        true
                    }.getOrDefault(false)
                    done++; onProgress(done)
                    r
                }
            }
            toast(if (n == items.size) "Copy completed." else "Copied $n of ${items.size}")
            onChanged(); onDone()
        }
    }
}

@Composable
fun rememberFileActions(onChanged: () -> Unit): FileActions {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pending by remember { mutableStateOf<((Boolean) -> Unit)?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        val cb = pending
        pending = null
        cb?.invoke(r.resultCode == Activity.RESULT_OK)
    }
    return remember {
        FileActions(ctx, scope, onChanged) { pi, cb ->
            pending = cb
            launcher.launch(IntentSenderRequest.Builder(pi).build())
        }
    }
}

@Composable
fun FolderPickerDialog(vm: GalleryViewModel, title: String, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val media by vm.media.collectAsState()
    val folders = remember(media) { media.map { it.relativePath }.filter { it.isNotBlank() }.distinct().sorted() }
    var newName by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = CardBg, shape = RoundedCornerShape(28.dp),
        title = { Text(title) },
        text = {
            Column {
                LazyColumn(Modifier.heightIn(max = 240.dp)) {
                    items(folders, key = { it }) { p ->
                        ListItem(
                            headlineContent = { Text(p.trimEnd('/')) },
                            leadingContent = { Icon(Icons.Filled.Folder, null) },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            modifier = Modifier.clickable { onPick(p) }
                        )
                    }
                }
                OutlinedTextField(newName, { newName = it }, singleLine = true, label = { Text("Or new folder name") })
            }
        },
        confirmButton = {
            TextButton(enabled = newName.isNotBlank(), onClick = { onPick(newName.trim().replace('/', '_')) }) { Text("Use new folder") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
