package com.example.opengallery

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.opengallery.data.AlbumEntity
import com.example.opengallery.data.AlbumItemEntity
import com.example.opengallery.data.FavoriteEntity
import com.example.opengallery.data.GalleryDb
import com.example.opengallery.data.GalleryMedia
import com.example.opengallery.data.GroupMemberEntity
import com.example.opengallery.data.MediaRepo
import com.example.opengallery.data.AppSettings
import com.example.opengallery.data.Prefs
import com.example.opengallery.data.SortOption
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GalleryViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = MediaRepo(app)
    private val dao = GalleryDb.get(app).albumDao()
    private val prefs = Prefs(app)

    val media = MutableStateFlow<List<GalleryMedia>>(emptyList())
    val trash = MutableStateFlow<List<GalleryMedia>>(emptyList())

    val albums: StateFlow<List<AlbumEntity>> =
        dao.allAlbums().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val links: StateFlow<List<AlbumItemEntity>> =
        dao.allLinks().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val members: StateFlow<List<GroupMemberEntity>> =
        dao.allMembers().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val favorites: StateFlow<Set<Long>> =
        dao.allFavorites().map { it.toSet() }.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    // View settings
    val sort = MutableStateFlow(SortOption.CREATED_DESC)
    val groupByDate = MutableStateFlow(false)
    val albumSort = MutableStateFlow<SortOption?>(null)
    val essential = MutableStateFlow<Set<String>?>(prefs.getSet("essential"))
    val hidden = MutableStateFlow(prefs.getSet("hidden") ?: emptySet())
    val essentialEnabled = MutableStateFlow(prefs.getBool("essential_enabled", true))
    val askBeforeDelete = MutableStateFlow(prefs.getBool("ask_delete", true))
    val askGroupName = MutableStateFlow(prefs.getBool("ask_group_name", false))
    val albumOrder = MutableStateFlow((prefs.getString("album_order") ?: "").split(",").filter { it.isNotBlank() })

    val askBeforeMove = MutableStateFlow(prefs.getBool("ask_move", true))

    init { AppSettings.askBeforeDelete = askBeforeDelete.value; AppSettings.askBeforeMove = askBeforeMove.value }

    /** The list the full-screen viewer pages through (set right before navigating to it). */
    var viewerList: List<GalleryMedia> = emptyList()

    fun refresh() { viewModelScope.launch { media.value = repo.load() } }
    fun refreshTrash() { viewModelScope.launch { trash.value = repo.loadTrash() } }

    fun setEssential(keys: Set<String>) { essential.value = keys; prefs.putSet("essential", keys) }
    fun setHidden(keys: Set<String>) { hidden.value = keys; prefs.putSet("hidden", keys) }
    fun setEssentialEnabled(on: Boolean) { essentialEnabled.value = on; prefs.putBool("essential_enabled", on) }
    fun setAskBeforeDelete(on: Boolean) {
        askBeforeDelete.value = on
        prefs.putBool("ask_delete", on)
        AppSettings.askBeforeDelete = on
    }
    fun setAskBeforeMove(on: Boolean) {
        askBeforeMove.value = on
        prefs.putBool("ask_move", on)
        AppSettings.askBeforeMove = on
    }
    fun setAskGroupName(on: Boolean) { askGroupName.value = on; prefs.putBool("ask_group_name", on) }
    fun setAlbumOrder(keys: List<String>) { albumOrder.value = keys; prefs.putString("album_order", keys.joinToString(",")) }

    fun createAlbum(name: String, onCreated: (Long) -> Unit = {}) {
        viewModelScope.launch { onCreated(dao.insert(AlbumEntity(name = name))) }
    }

    fun createGroup(name: String, keys: Set<String>, onCreated: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = dao.insert(AlbumEntity(name = name, isGroup = true))
            if (keys.isNotEmpty()) dao.addMembers(keys.map { GroupMemberEntity(id, it) })
            onCreated(id)
        }
    }

    fun renameAlbum(id: Long, name: String) { viewModelScope.launch { dao.rename(id, name) } }

    fun deleteAlbum(id: Long, isGroup: Boolean) {
        viewModelScope.launch {
            if (!isGroup) dao.removeMemberKey("album:$id")
            dao.delete(id) // cascades to album items / group members
        }
    }

    fun addMembers(groupId: Long, keys: Set<String>) {
        viewModelScope.launch { dao.addMembers(keys.map { GroupMemberEntity(groupId, it) }) }
    }

    fun removeMembers(groupId: Long, keys: Set<String>) {
        viewModelScope.launch { keys.forEach { dao.removeMember(groupId, it) } }
    }

    fun addToAlbum(albumId: Long, items: List<GalleryMedia>) {
        viewModelScope.launch {
            dao.addItems(items.map { AlbumItemEntity(albumId, it.id) })
            Toast.makeText(getApplication<Application>(), "Added ${items.size} item(s)", Toast.LENGTH_SHORT).show()
        }
    }

    fun removeFromAlbum(albumId: Long, ids: List<Long>) {
        viewModelScope.launch { dao.removeItems(albumId, ids) }
    }

    fun toggleFavorite(ids: List<Long>, add: Boolean) {
        viewModelScope.launch {
            if (add) dao.addFavorites(ids.map { FavoriteEntity(it) }) else dao.removeFavorites(ids)
        }
    }

    /** Files that look identical (same size, date, resolution); returns every copy except the first. */
    fun findDuplicates(): List<GalleryMedia> =
        media.value
            .groupBy { listOf(it.size, it.dateTaken, it.width, it.height, it.isVideo) }
            .values.filter { it.size > 1 }
            .flatMap { g -> g.sortedBy { it.id }.drop(1) }
}
