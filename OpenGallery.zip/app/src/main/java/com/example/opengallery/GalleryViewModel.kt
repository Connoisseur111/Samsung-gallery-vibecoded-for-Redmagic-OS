package com.example.opengallery

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.opengallery.data.AlbumEntity
import com.example.opengallery.data.AlbumItemEntity
import com.example.opengallery.data.FavoriteEntity
import com.example.opengallery.data.GalleryDb
import com.example.opengallery.data.GalleryMedia
import com.example.opengallery.data.GroupMemberEntity
import com.example.opengallery.data.MediaRepo
import com.example.opengallery.data.AppSettings
import com.example.opengallery.data.Prefs
import com.example.opengallery.data.SortOption
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GalleryViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = MediaRepo(app)
    private val dao = GalleryDb.get(app).albumDao()
    private val prefs = Prefs(app)

    private val allMedia = MutableStateFlow<List<GalleryMedia>>(emptyList())
    val trash = MutableStateFlow<List<GalleryMedia>>(emptyList())

    val albums: StateFlow<List<AlbumEntity>> =
        dao.allAlbums().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val links: StateFlow<List<AlbumItemEntity>> =
        dao.allLinks().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val members: StateFlow<List<GroupMemberEntity>> =
        dao.allMembers().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val favorites: StateFlow<Set<Long>> =
        dao.allFavorites().map { it.toSet() }.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    // ---- Private albums: hidden from every list while locked; shown after PIN / fingerprint ----
    val privateKeys = MutableStateFlow(prefs.getSet("private") ?: emptySet())
    val privateUnlocked = MutableStateFlow(false)
    val media: StateFlow<List<GalleryMedia>> =
        kotlinx.coroutines.flow.combine(allMedia, privateKeys, privateUnlocked, links) { all, keys, open, lk ->
            if (open || keys.isEmpty()) all else {
                val folders = keys.filter { it.startsWith("folder:") }.mapNotNull { it.removePrefix("folder:").toLongOrNull() }.toSet()
                val customs = keys.filter { it.startsWith("album:") }.mapNotNull { it.removePrefix("album:").toLongOrNull() }.toSet()
                val inCustom = lk.filter { it.albumId in customs }.map { it.mediaId }.toSet()
                all.filter { it.bucketId !in folders && it.id !in inCustom }
            }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun setPrivateKeys(keys: Set<String>) { privateKeys.value = keys; prefs.putSet("private", keys) }
    fun unlockPrivate() { privateUnlocked.value = true; failedPins = 0 }
    fun lockPrivate() { privateUnlocked.value = false }
    fun hasPin(): Boolean = prefs.getString("pin_hash") != null
    private fun hashPin(pin: String, salt: String): String =
        java.security.MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }
    fun setPin(pin: String) {
        val salt = java.util.UUID.randomUUID().toString()
        prefs.putString("pin_salt", salt); prefs.putString("pin_hash", hashPin(pin, salt))
    }
    private var failedPins = 0
    private var pinBlockedUntil = 0L
    fun pinLockSecondsLeft(): Int = ((pinBlockedUntil - System.currentTimeMillis()) / 1000).toInt().coerceAtLeast(0)
    fun checkPin(pin: String): Boolean {
        if (pinLockSecondsLeft() > 0) return false
        val ok = hashPin(pin, prefs.getString("pin_salt") ?: "") == prefs.getString("pin_hash")
        if (ok) failedPins = 0 else if (++failedPins >= 5) { failedPins = 0; pinBlockedUntil = System.currentTimeMillis() + 30_000 }
        return ok
    }

    // View settings
    val sort = MutableStateFlow(
        prefs.getString("sort_global")?.let { n -> runCatching { SortOption.valueOf(n) }.getOrNull() } ?: SortOption.CREATED_DESC
    )
    /** Sort order chosen separately for individual albums (album key -> option). */
    val albumSorts = MutableStateFlow(
        (prefs.getString("album_sorts") ?: "").split(",").filter { "=" in it }.mapNotNull { e ->
            val k = e.substringBefore("="); val v = runCatching { SortOption.valueOf(e.substringAfter("=")) }.getOrNull()
            if (v == null) null else k to v
        }.toMap()
    )
    val askSortScope = MutableStateFlow(prefs.getBool("ask_sort_scope", false))
    fun setAskSortScope(on: Boolean) { askSortScope.value = on; prefs.putBool("ask_sort_scope", on) }
    private fun saveAlbumSorts() { prefs.putString("album_sorts", albumSorts.value.entries.joinToString(",") { it.key + "=" + it.value.name }) }
    /** This album only. */
    fun setAlbumSortFor(key: String, opt: SortOption) { albumSorts.value = albumSorts.value + (key to opt); saveAlbumSorts() }
    /** Every album (and the Pictures tab): becomes the default and clears the per-album choices. */
    fun setSortForAll(opt: SortOption) {
        sort.value = opt; prefs.putString("sort_global", opt.name)
        albumSorts.value = emptyMap(); saveAlbumSorts()
    }
    val groupByDate = MutableStateFlow(false)
    val albumSort = MutableStateFlow<SortOption?>(null)
    val essential = MutableStateFlow<Set<String>?>(prefs.getSet("essential"))
    val hidden = MutableStateFlow(prefs.getSet("hidden") ?: emptySet())
    val essentialEnabled = MutableStateFlow(prefs.getBool("essential_enabled", true))
    val askBeforeDelete = MutableStateFlow(prefs.getBool("ask_delete", true))
    val askGroupName = MutableStateFlow(prefs.getBool("ask_group_name", false))
    val albumOrder = MutableStateFlow((prefs.getString("album_order") ?: "").split(",").filter { it.isNotBlank() })

    val askBeforeMove = MutableStateFlow(prefs.getBool("ask_move", true))

    init { AppSettings.askBeforeDelete = askBeforeDelete.value; AppSettings.askBeforeMove = askBeforeMove.value }

    /** The list the full-screen viewer pages through (set right before navigating to it). */
    var viewerList: List<GalleryMedia> = emptyList()

    /** After editing a live screenshot, go back to this viewer route and resume this video (id, position ms). */
    var pendingReturn: String? = null
    var resumeVideo: Pair<Long, Long>? = null

    fun refresh() { viewModelScope.launch { allMedia.value = repo.load() } }

    // New downloads / photos / deletions made by other apps show up by themselves (no need to restart the gallery).
    private var autoRefresh: kotlinx.coroutines.Job? = null
    private val mediaObserver = object : android.database.ContentObserver(android.os.Handler(android.os.Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            autoRefresh?.cancel()
            autoRefresh = viewModelScope.launch {
                kotlinx.coroutines.delay(600)   // wait for a burst of changes (e.g. a download finishing) to settle
                allMedia.value = repo.load()
            }
        }
    }
    init {
        val cr = app.contentResolver
        cr.registerContentObserver(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, mediaObserver)
        cr.registerContentObserver(android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, mediaObserver)
    }
    override fun onCleared() {
        getApplication<Application>().contentResolver.unregisterContentObserver(mediaObserver)
        super.onCleared()
    }
    fun refreshTrash() { viewModelScope.launch { trash.value = repo.loadTrash() } }

    fun setEssential(keys: Set<String>) { essential.value = keys; prefs.putSet("essential", keys) }
    fun setHidden(keys: Set<String>) { hidden.value = keys; prefs.putSet("hidden", keys) }
    fun setEssentialEnabled(on: Boolean) { essentialEnabled.value = on; prefs.putBool("essential_enabled", on) }
    fun setAskBeforeDelete(on: Boolean) {
        askBeforeDelete.value = on
        prefs.putBool("ask_delete", on)
        AppSettings.askBeforeDelete = on
    }
    fun setAskBeforeMove(on: Boolean) {
        askBeforeMove.value = on
        prefs.putBool("ask_move", on)
        AppSettings.askBeforeMove = on
    }
    fun setAskGroupName(on: Boolean) { askGroupName.value = on; prefs.putBool("ask_group_name", on) }
    fun setAlbumOrder(keys: List<String>) { albumOrder.value = keys; prefs.putString("album_order", keys.joinToString(",")) }

    fun createAlbum(name: String, onCreated: (Long) -> Unit = {}) {
        viewModelScope.launch { onCreated(dao.insert(AlbumEntity(name = name))) }
    }

    fun createGroup(name: String, keys: Set<String>, onCreated: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = dao.insert(AlbumEntity(name = name, isGroup = true))
            if (keys.isNotEmpty()) dao.addMembers(keys.map { GroupMemberEntity(id, it) })
            onCreated(id)
        }
    }

    fun renameAlbum(id: Long, name: String) { viewModelScope.launch { dao.rename(id, name) } }

    fun deleteAlbum(id: Long, isGroup: Boolean) {
        viewModelScope.launch {
            if (!isGroup) dao.removeMemberKey("album:$id")
            dao.delete(id) // cascades to album items / group members
        }
    }

    fun addMembers(groupId: Long, keys: Set<String>) {
        viewModelScope.launch { dao.addMembers(keys.map { GroupMemberEntity(groupId, it) }) }
    }

    fun removeMembers(groupId: Long, keys: Set<String>) {
        viewModelScope.launch { keys.forEach { dao.removeMember(groupId, it) } }
    }

    fun addToAlbum(albumId: Long, items: List<GalleryMedia>) {
        viewModelScope.launch {
            dao.addItems(items.map { AlbumItemEntity(albumId, it.id) })
            Toast.makeText(getApplication<Application>(), "Added ${items.size} item(s)", Toast.LENGTH_SHORT).show()
        }
    }

    fun removeFromAlbum(albumId: Long, ids: List<Long>) {
        viewModelScope.launch { dao.removeItems(albumId, ids) }
    }

    fun toggleFavorite(ids: List<Long>, add: Boolean) {
        viewModelScope.launch {
            if (add) dao.addFavorites(ids.map { FavoriteEntity(it) }) else dao.removeFavorites(ids)
        }
    }

    /** Files that look identical (same size, date, resolution); returns every copy except the first. */
    fun findDuplicates(): List<GalleryMedia> =
        media.value
            .groupBy { listOf(it.size, it.dateTaken, it.width, it.height, it.isVideo) }
            .values.filter { it.size > 1 }
            .flatMap { g -> g.sortedBy { it.id }.drop(1) }
}
