@file:OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)

package com.example.opengallery.ui

import android.content.ContentValues
import android.content.Context
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Crop as CropIcon
import androidx.compose.material.icons.filled.InvertColors
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Tonality
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.Crop
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import androidx.navigation.NavController
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.GalleryMedia
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

private data class VState(
    val start: Long,
    val end: Long,
    val rot: Int = 0,
    val flipH: Boolean = false,
    val flipV: Boolean = false,
    val crop: CropRect = CropRect(),
    val look: Look = Look.ORIGINAL,
    val brightness: Int = 0,
    val contrast: Int = 0,
    val saturation: Int = 0
)

private fun effectsFor(s: VState, applyCrop: Boolean): List<Effect> {
    val list = mutableListOf<Effect>()
    if (s.rot != 0 || s.flipH || s.flipV) {
        list.add(
            ScaleAndRotateTransformation.Builder()
                .setScale(if (s.flipH) -1f else 1f, if (s.flipV) -1f else 1f)
                .setRotationDegrees(-s.rot.toFloat()) // media3 rotates counter-clockwise
                .build()
        )
    }
    if (applyCrop && !s.crop.isFull) {
        list.add(Crop(-1f + 2f * s.crop.l, 1f - 2f * s.crop.r, -1f + 2f * s.crop.b, 1f - 2f * s.crop.t))
    }
    if (s.look == Look.MONO) list.add(RgbFilter.createGrayscaleFilter())
    var sat = s.saturation.toFloat()
    if (s.look == Look.VIVID) sat += 40f
    if (sat != 0f) list.add(HslAdjustment.Builder().adjustSaturation(sat.coerceIn(-100f, 100f)).build())
    if (s.brightness != 0) list.add(Brightness(s.brightness / 100f))
    if (s.contrast != 0) list.add(Contrast(s.contrast / 100f))
    return list
}

private suspend fun saveVideo(ctx: Context, file: File, baseName: String): Boolean = withContext(Dispatchers.IO) {
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, "${baseName.substringBeforeLast('.')}_edit_${System.currentTimeMillis()}.mp4")
        put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
        put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/OpenGallery")
        put(MediaStore.MediaColumns.IS_PENDING, 1)
    }
    val res = ctx.contentResolver
    val uri = res.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
    res.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
    values.clear()
    values.put(MediaStore.MediaColumns.IS_PENDING, 0)
    res.update(uri, values, null, null)
    file.delete()
    true
}

@Composable
fun VideoEditorScreen(vm: GalleryViewModel, nav: NavController, mediaId: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val m = vm.media.value.firstOrNull { it.id == mediaId }
    if (m == null || !m.isVideo) {
        LaunchedEffect(Unit) { nav.popBackStack() }
        return
    }
    val durMs = m.duration.coerceAtLeast(1000L)

    var cur by remember { mutableStateOf(VState(0L, durMs)) }
    var hist by remember { mutableStateOf(listOf(VState(0L, durMs))) }
    var hi by remember { mutableIntStateOf(0) }
    var tool by remember { mutableIntStateOf(0) } // 0 trim, 1 crop, 2 filters, 3 tune
    var pos by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var transformerRef by remember { mutableStateOf<Transformer?>(null) }
    var confirmExit by remember { mutableStateOf(false) }

    val player = remember {
        ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(m.uri)); prepare() }
    }
    DisposableEffect(player) { onDispose { player.release() } }

    fun commit(s: VState) {
        cur = s
        hist = hist.take(hi + 1) + s
        hi = hist.size - 1
    }

    val edited = hi > 0
    BackHandler(edited && !exporting) { confirmExit = true }

    // Live preview of crop / rotate / filters / tune (crop is applied after leaving the crop tool).
    LaunchedEffect(cur.rot, cur.flipH, cur.flipV, cur.crop, cur.look, cur.brightness, cur.contrast, cur.saturation, tool) {
        player.setVideoEffects(effectsFor(cur, tool != 1))
    }
    // Keep playback inside the trimmed range.
    LaunchedEffect(cur.start, cur.end) {
        while (true) {
            delay(100)
            pos = player.currentPosition
            playing = player.isPlaying
            if (pos >= cur.end) {
                player.pause()
                player.seekTo(cur.start)
            } else if (pos < cur.start) {
                player.seekTo(cur.start)
            }
        }
    }
    LaunchedEffect(exporting) {
        val holder = ProgressHolder()
        while (exporting) {
            val t = transformerRef
            if (t != null && t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) progress = holder.progress
            delay(300)
        }
    }

    fun export() {
        exporting = true
        progress = 0
        player.pause()
        val out = File(ctx.cacheDir, "edit_${System.currentTimeMillis()}.mp4")
        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(cur.start).setEndPositionMs(cur.end).build()
        val item = EditedMediaItem.Builder(
            MediaItem.Builder().setUri(m.uri).setClippingConfiguration(clip).build()
        ).setEffects(Effects(emptyList(), effectsFor(cur, true))).build()
        val transformer = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    scope.launch {
                        val ok = saveVideo(ctx, out, m.name)
                        exporting = false
                        transformerRef = null
                        vm.refresh()
                        Toast.makeText(ctx, if (ok) "Saved to Movies/OpenGallery" else "Save failed", Toast.LENGTH_LONG).show()
                        if (ok) nav.popBackStack()
                    }
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    exporting = false
                    transformerRef = null
                    Toast.makeText(ctx, "Export failed: ${exportException.errorCodeName}", Toast.LENGTH_LONG).show()
                }
            }).build()
        transformerRef = transformer
        transformer.start(item, out.absolutePath)
    }

    // Shape of the frame being edited (width/height swap on 90/270 degree rotation).
    val vw = if (m.width > 0) m.width.toFloat() else 16f
    val vh = if (m.height > 0) m.height.toFloat() else 9f
    val aspect = if (cur.rot % 180 != 0) vh / vw else vw / vh

    Column(Modifier.fillMaxSize().background(Color.Black).navigationBarsPadding()) {
        EditTopBar(
            canUndo = hi > 0, canRedo = hi < hist.size - 1,
            onUndo = { if (hi > 0) { hi -= 1; cur = hist[hi] } },
            onRedo = { if (hi < hist.size - 1) { hi += 1; cur = hist[hi] } },
            onRevert = { cur = VState(0L, durMs); hist = listOf(VState(0L, durMs)); hi = 0 },
            onSave = { export() }, saveEnabled = !exporting
        )
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val fitW = minOf(maxWidth.value, maxHeight.value * aspect)
            val fitH = fitW / aspect
            AndroidView(
                factory = { c -> PlayerView(c).also { v -> v.useController = false; v.player = player } },
                modifier = Modifier.fillMaxSize()
            )
            if (tool == 1) Box(Modifier.align(Alignment.Center).size(fitW.dp, fitH.dp)) {
                CropOverlay(
                    cur.crop, onChange = { r -> cur = cur.copy(crop = r) }, onCommit = { commit(cur) },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        // play / pause + time
        Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            Row(
                Modifier.clip(RoundedCornerShape(24.dp)).background(Color(0xFF2B2B2B))
                    .clickable {
                        if (player.isPlaying) player.pause()
                        else {
                            if (pos >= cur.end - 50) player.seekTo(cur.start)
                            player.play()
                        }
                    }
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = Color.White)
                Spacer(Modifier.width(8.dp))
                Text(
                    "${fmtClock((pos - cur.start).coerceAtLeast(0L))} / ${fmtClock(cur.end - cur.start)}",
                    color = Color.White, fontSize = 14.sp
                )
            }
        }
        // timeline / panel for the current tool
        Box(Modifier.fillMaxWidth().height(130.dp), contentAlignment = Alignment.Center) {
            when (tool) {
                0 -> TrimBar(
                    m, durMs, cur.start, cur.end, pos,
                    onTrim = { s, e -> cur = cur.copy(start = s, end = e) },
                    onTrimDone = { commit(cur) },
                    onSeek = { player.seekTo(it) }
                )
                1 -> CropToolsRow(
                    onFlipH = { commit(cur.copy(flipH = !cur.flipH, crop = CropRect())) },
                    onRotate = { commit(cur.copy(rot = (cur.rot + 90) % 360, crop = CropRect())) },
                    onFlipV = { commit(cur.copy(flipV = !cur.flipV, crop = CropRect())) },
                    onRatio = { r -> commit(cur.copy(crop = rectForRatio(r, aspect))) }
                )
                2 -> FilterStrip(listOf(Look.ORIGINAL, Look.MONO, Look.VIVID), cur.look, null) { l ->
                    commit(cur.copy(look = l))
                }
                else -> TunePanel(
                    names = listOf("Brightness", "Contrast", "Saturation"),
                    icons = listOf(Icons.Filled.Brightness6, Icons.Filled.Tonality, Icons.Filled.InvertColors),
                    values = listOf(cur.brightness, cur.contrast, cur.saturation),
                    onChange = { i, v ->
                        cur = when (i) {
                            0 -> cur.copy(brightness = v)
                            1 -> cur.copy(contrast = v)
                            else -> cur.copy(saturation = v)
                        }
                    },
                    onCommit = { commit(cur) }
                )
            }
        }
        ToolDock(
            listOf(Icons.Filled.ContentCut, Icons.Filled.CropIcon, Icons.Filled.Palette, Icons.Filled.Tune), tool
        ) { tool = it }
    }

    if (exporting) AlertDialog(
        onDismissRequest = {}, containerColor = CardBg,
        title = { Text("Saving video…") },
        text = {
            Column {
                LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Text("$progress%")
            }
        },
        confirmButton = {
            TextButton(onClick = { transformerRef?.cancel(); transformerRef = null; exporting = false }) { Text("Cancel") }
        }
    )
    if (confirmExit) AlertDialog(
        onDismissRequest = { confirmExit = false }, containerColor = CardBg,
        title = { Text("Save your changes or discard them?") },
        confirmButton = { TextButton(onClick = { confirmExit = false; export() }) { Text("Save copy") } },
        dismissButton = {
            Column {
                TextButton(onClick = { confirmExit = false; nav.popBackStack() }) { Text("Discard") }
                TextButton(onClick = { confirmExit = false }) { Text("Cancel") }
            }
        }
    )
}

/** Filmstrip with draggable start/end handles (trim) and a playhead. */
@Composable
private fun TrimBar(
    m: GalleryMedia, dur: Long, start: Long, end: Long, pos: Long,
    onTrim: (Long, Long) -> Unit, onTrimDone: () -> Unit, onSeek: (Long) -> Unit
) {
    val s by rememberUpdatedState(start)
    val e by rememberUpdatedState(end)
    var active by remember { mutableIntStateOf(0) } // 1 = start handle, 2 = end handle, 3 = seek
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        Box(Modifier.fillMaxWidth().height(26.dp)) {
            if (active == 1 || active == 2) {
                Text(
                    fmtClockMs(if (active == 1) start else end), color = Color.White, fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
        }
        Box(
            Modifier.fillMaxWidth().height(56.dp).pointerInput(dur) {
                detectDragGestures(
                    onDragStart = { o ->
                        val w = size.width.toFloat()
                        val xs = s.toFloat() / dur * w
                        val xe = e.toFloat() / dur * w
                        val th = 36.dp.toPx()
                        active = when {
                            abs(o.x - xs) < th -> 1
                            abs(o.x - xe) < th -> 2
                            else -> 3
                        }
                        if (active == 3) onSeek((o.x / w * dur).toLong().coerceIn(s, e))
                    },
                    onDragEnd = { active = 0; onTrimDone() },
                    onDragCancel = { active = 0; onTrimDone() },
                    onDrag = { pc, _ ->
                        pc.consume()
                        val w = size.width.toFloat()
                        val t = (pc.position.x.coerceIn(0f, w) / w * dur).toLong()
                        when (active) {
                            1 -> onTrim(t.coerceIn(0L, maxOf(0L, e - 500L)), e)
                            2 -> onTrim(s, t.coerceIn(minOf(dur, s + 500L), dur))
                            3 -> onSeek(t.coerceIn(s, e))
                        }
                    }
                )
            }
        ) {
            VideoFrames(m, dur, Modifier.fillMaxSize().clip(RoundedCornerShape(6.dp)))
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val sf = (start.toFloat() / dur).coerceIn(0f, 1f)
                val ef = (end.toFloat() / dur).coerceIn(0f, 1f)
                val pf = (pos.toFloat() / dur).coerceIn(0f, 1f)
                val dim = Color(0xAA000000)
                Box(Modifier.width(maxWidth * sf).fillMaxHeight().background(dim))
                Box(Modifier.offset(x = maxWidth * ef).width(maxWidth * (1f - ef)).fillMaxHeight().background(dim))
                Box(
                    Modifier.offset(x = maxWidth * sf).width(maxWidth * (ef - sf)).fillMaxHeight()
                        .border(3.dp, Color.White, RoundedCornerShape(6.dp))
                )
                Box(Modifier.offset(x = maxWidth * pf).width(2.dp).fillMaxHeight().background(Color.White))
            }
        }
    }
}
