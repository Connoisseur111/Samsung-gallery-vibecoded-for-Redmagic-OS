@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.example.opengallery.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.GalleryMedia
import com.example.opengallery.data.SortOption

// ---------- buttons & pills ----------

@Composable
fun CircleButton(icon: ImageVector, desc: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier.size(44.dp).clip(CircleShape).background(OverlayBg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, desc, tint = Color.White) }
}

/** The dark rounded pill with search / more (and optionally +) in the top-right corner. */
@Composable
fun PillActions(
    modifier: Modifier = Modifier,
    onPlus: (() -> Unit)? = null,
    onSearch: (() -> Unit)? = null,
    menu: @Composable ColumnScope.(close: () -> Unit) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Row(
        modifier.clip(RoundedCornerShape(22.dp)).background(OverlayBg).height(44.dp).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onPlus != null) Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onPlus), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Add, "Create", tint = Color.White)
        }
        if (onSearch != null) Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onSearch), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Search, "Search", tint = Color.White)
        }
        Box {
            Box(Modifier.size(40.dp).clip(CircleShape).clickable { open = true }, contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.MoreVert, "More", tint = Color.White)
            }
            DropdownMenu(
                expanded = open, onDismissRequest = { open = false },
                modifier = Modifier.background(CardBg, RoundedCornerShape(20.dp))
            ) { this.menu { open = false } }
        }
    }
}

@Composable
fun MenuItem(text: String, onClick: () -> Unit) {
    DropdownMenuItem(text = { Text(text, fontSize = 16.sp, color = Color.White) }, onClick = onClick)
}

@Composable
fun ActionPill(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    Row(
        modifier.clip(RoundedCornerShape(36.dp)).background(PillBg).padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically, content = content
    )
}

@Composable
fun PillAction(icon: ImageVector, label: String?, enabled: Boolean = true, tint: Color = Color.White, onClick: () -> Unit) {
    val c = if (enabled) tint else Color(0x66FFFFFF)
    Column(
        Modifier.clip(RoundedCornerShape(20.dp)).clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = c)
        if (label != null) Text(label, fontSize = 11.sp, color = c)
    }
}

/** "○ 9" on the left and "Cancel" on the right, shown while selecting. */
@Composable
fun SelectionTop(count: Int, allSelected: Boolean, onToggleAll: () -> Unit, onCancel: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            Modifier.clip(RoundedCornerShape(22.dp)).background(OverlayBg).clickable(onClick = onToggleAll)
                .height(44.dp).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SelectCircle(allSelected, Modifier)
            Spacer(Modifier.width(8.dp))
            Text("$count", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }
        Box(
            Modifier.clip(RoundedCornerShape(22.dp)).background(OverlayBg).clickable(onClick = onCancel)
                .height(44.dp).padding(horizontal = 18.dp),
            contentAlignment = Alignment.Center
        ) { Text("Cancel", color = Color.White, fontSize = 16.sp) }
    }
}

@Composable
fun SelectCircle(selected: Boolean, modifier: Modifier) {
    Box(
        modifier.size(24.dp).clip(CircleShape).background(if (selected) Accent else Color(0x66000000))
            .border(1.5.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center
    ) { if (selected) Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
}

// ---------- media cells & album tiles ----------

@Composable
fun MediaImage(m: GalleryMedia, modifier: Modifier = Modifier, fade: Boolean = true, poster: Boolean = false, strip: Boolean = false,
               scale: androidx.compose.ui.layout.ContentScale = ContentScale.Crop) {
    val ctx = LocalContext.current
    val req = remember(m.id, fade, poster, strip) {
        ImageRequest.Builder(ctx).data(m.uri)
            .decoderFactory(VideoFrameDecoder.Factory()).crossfade(fade)
            .apply {
                when {
                    // Small and cached: the strip loads fast and never goes blank while you slide it.
                    strip -> memoryCacheKey("strip-${m.uri}").size(coil.size.Size(160, 160))
                    // The big video picture shows the strip's thumbnail instantly while the sharp frame loads.
                    poster -> memoryCacheKey("poster-${m.uri}")
                        // The strip thumbnail (already in memory) is shown at once, so the big view is never black
                        // while the sharper frame is still being decoded.
                        .placeholderMemoryCacheKey("strip-${m.uri}").size(coil.size.Size(900, 900))
                    else -> memoryCacheKey("thumb-${m.uri}")
                }
            }.build()
    }
    AsyncImage(model = req, contentDescription = m.name, modifier = modifier, contentScale = scale)
}

/** Ids of favorite items, provided once at the app root so every thumbnail can show its heart. */
val LocalFavorites = androidx.compose.runtime.compositionLocalOf<Set<Long>> { emptySet() }

@Composable
fun MediaCell(m: GalleryMedia, selected: Boolean, selecting: Boolean, onClick: () -> Unit, onLong: () -> Unit, modifier: Modifier) {
    val isFav = m.id in LocalFavorites.current
    val isGif = !m.isVideo && m.name.endsWith(".gif", ignoreCase = true)
    Box(modifier.combinedClickable(onClick = onClick, onLongClick = onLong)) {
        MediaImage(m, Modifier.fillMaxSize())
        if (m.isVideo) Row(
            Modifier.align(Alignment.BottomStart).padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.size(14.dp))
            Text(fmtDuration(m.duration), color = Color.White, fontSize = 11.sp)
        }
        if (isGif) Text(
            "GIF", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.BottomStart).padding(5.dp)
                .clip(RoundedCornerShape(8.dp)).background(Color(0x99333333)).padding(horizontal = 6.dp, vertical = 2.dp)
        )
        if (isFav) Icon(
            Icons.Filled.Favorite, "Favorite", tint = Color(0xFFF2685F),
            modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(24.dp)
        )
        if (selected) Box(Modifier.fillMaxSize().background(Color(0x333E91FF)))
        if (selecting) SelectCircle(selected, Modifier.align(Alignment.TopStart).padding(5.dp))
    }
}

@Composable
fun AlbumTile(
    info: AlbumInfo, selected: Boolean, selecting: Boolean,
    onClick: () -> Unit, onLong: (() -> Unit)? = null, modifier: Modifier = Modifier,
    highlight: Boolean = false
) {
    val stacked = info.kind == Kind.RECENT || info.kind == Kind.GROUP
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier.aspectRatio(0.86f).scale(if (highlight) 1.05f else 1f)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
    ) {
        if (stacked) {
            Box(Modifier.fillMaxSize().padding(horizontal = 12.dp).clip(shape).background(Color(0xFF3A3A3A)))
            Box(Modifier.fillMaxSize().padding(horizontal = 6.dp).padding(top = 5.dp).clip(shape).background(Color(0xFF4A4A4A)))
        }
        Box(
            Modifier.fillMaxSize().padding(top = if (stacked) 10.dp else 0.dp).clip(shape)
                .background(Color(0xFF1E1E1E)).border(if (selected || highlight) 2.dp else 0.dp, if (selected || highlight) Accent else Color.Transparent, shape)
        ) {
            val cover = info.cover
            if (cover != null) MediaImage(cover, Modifier.fillMaxSize())
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Transparent, Color(0x99000000)), startY = 120f)
                )
            )
            Column(
                Modifier.align(Alignment.BottomCenter).padding(horizontal = 6.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(info.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text("${info.count}", color = Color(0xCCFFFFFF), fontSize = 11.sp)
            }
        }
        if (selecting) SelectCircle(selected, Modifier.align(Alignment.TopStart).padding(8.dp).padding(top = if (stacked) 10.dp else 0.dp))
    }
}

/** Blurred cover + centered title, used as the first item of an album screen. */
@Composable
fun AlbumHeader(title: String, subtitle: String, cover: GalleryMedia?) {
    Box(Modifier.fillMaxWidth().height(300.dp)) {
        if (cover != null) MediaImage(cover, Modifier.fillMaxSize().blur(18.dp))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x66000000), Color.Black))))
        Column(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Color.White, fontSize = 15.sp)
        }
    }
}

// ---------- video filmstrip (scrubber) ----------

@Composable
fun VideoFrames(m: GalleryMedia, durMs: Long, modifier: Modifier = Modifier, count: Int = 10) {
    val ctx = LocalContext.current
    Row(modifier) {
        for (i in 0 until count) {
            val req = remember(m.id, durMs, i) {
                ImageRequest.Builder(ctx).data(m.uri).videoFrameMillis(durMs * i / count)
                    .decoderFactory(VideoFrameDecoder.Factory()).build()
            }
            AsyncImage(
                model = req, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
        }
    }
}

@Composable
fun VideoScrubber(m: GalleryMedia, dur: Long, pos: Long, onTapEnd: () -> Unit = {}, onSeek: (Long) -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 12.dp).clip(RoundedCornerShape(8.dp))
            .pointerInput(dur) { detectTapGestures { o -> onSeek((o.x / size.width * dur).toLong()); onTapEnd() } }
            .pointerInput(dur) {
                detectHorizontalDragGestures { change, _ ->
                    onSeek((change.position.x.coerceIn(0f, size.width.toFloat()) / size.width * dur).toLong())
                }
            }
    ) {
        VideoFrames(m, dur, Modifier.fillMaxSize())
        val frac = (pos.toFloat() / dur).coerceIn(0f, 1f)
        BoxWithConstraints(Modifier.fillMaxSize()) {
            Box(Modifier.offset(x = maxWidth * frac).width(2.dp).fillMaxHeight().background(Color.White))
        }
    }
}

// ---------- dialogs ----------

private val dialogShape = RoundedCornerShape(28.dp)

@Composable
fun SortDialog(current: SortOption, grouped: Boolean?, onDismiss: () -> Unit, onDone: (SortOption, Boolean) -> Unit) {
    var sel by remember { mutableStateOf(current) }
    var grp by remember { mutableStateOf(grouped ?: false) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = CardBg, shape = dialogShape,
        title = { Text("Sort by", fontSize = 18.sp) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                SortOption.entries.forEach { o ->
                    Row(Modifier.fillMaxWidth().clickable { sel = o }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = sel == o, onClick = { sel = o })
                        Text(o.label, fontSize = 16.sp)
                    }
                }
                if (grouped != null) {
                    HorizontalDivider(Modifier.padding(vertical = 6.dp))
                    Row(Modifier.fillMaxWidth().padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Group by date", Modifier.weight(1f), fontSize = 16.sp)
                        Switch(checked = grp, onCheckedChange = { grp = it })
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onDone(sel, grp) }) { Text("Done") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/** Samsung-style dialog: title, underlined text field with the text pre-selected, Cancel | OK. */
@Composable
fun NameDialog(title: String, initial: String, okLabel: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var tf by remember { mutableStateOf(TextFieldValue(initial, TextRange(0, initial.length))) }
    val focus = remember { FocusRequester() }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = CardBg, shape = dialogShape,
        title = { Text(title, fontSize = 18.sp) },
        text = {
            LaunchedEffect(Unit) { focus.requestFocus() }
            TextField(
                value = tf, onValueChange = { tf = it }, singleLine = true,
                modifier = Modifier.fillMaxWidth().focusRequester(focus),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Accent, unfocusedIndicatorColor = Color.Gray
                )
            )
        },
        confirmButton = { TextButton(enabled = tf.text.isNotBlank(), onClick = { onOk(tf.text.trim()) }) { Text(okLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun ConfirmDialog(title: String, text: String, okLabel: String, onDismiss: () -> Unit, onOk: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = CardBg, shape = dialogShape,
        title = { Text(title, fontSize = 18.sp) }, text = { Text(text) },
        confirmButton = { TextButton(onClick = onOk) { Text(okLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun ChooseCreateDialog(onDismiss: () -> Unit, onAlbum: () -> Unit, onGroup: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = CardBg, shape = dialogShape,
        title = { Text("Choose what to create", fontSize = 18.sp) },
        text = {
            Column {
                ListItem(
                    headlineContent = { Text("Album", fontSize = 16.sp) },
                    supportingContent = { Text("Create a new album and add pictures and videos manually.") },
                    leadingContent = { Icon(Icons.Filled.CreateNewFolder, null) },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    modifier = Modifier.clickable(onClick = onAlbum)
                )
                ListItem(
                    headlineContent = { Text("Group", fontSize = 16.sp) },
                    supportingContent = { Text("Create a group of related albums.") },
                    leadingContent = { Icon(Icons.Filled.Add, null) },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    modifier = Modifier.clickable(onClick = onGroup)
                )
            }
        },
        confirmButton = {}
    )
}

@Composable
fun DetailsDialog(m: GalleryMedia, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = CardBg, shape = dialogShape,
        title = { Text("Details", fontSize = 18.sp) },
        text = {
            Column {
                Text(m.name, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(fmtDateFull(m.dateTaken))
                Text(m.relativePath.ifBlank { "Unknown location" })
                Text(fmtSize(m.size))
                if (m.width > 0) Text("${m.width} × ${m.height}")
                if (m.isVideo) Text(fmtDuration(m.duration))
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

/** Pick one of your own albums (or create a new one). */
@Composable
fun AlbumPickDialog(vm: GalleryViewModel, onDismiss: () -> Unit, onPick: (Long) -> Unit) {
    val albums by vm.albums.collectAsState()
    var creating by remember { mutableStateOf(false) }
    val mine = albums.filter { !it.isGroup }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = CardBg, shape = dialogShape,
        title = { Text("Add to album", fontSize = 18.sp) },
        text = {
            LazyColumn {
                item {
                    ListItem(
                        headlineContent = { Text("Create album", color = Accent) },
                        leadingContent = { Icon(Icons.Filled.Add, null, tint = Accent) },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        modifier = Modifier.clickable { creating = true }
                    )
                }
                items(mine, key = { it.id }) { a ->
                    ListItem(
                        headlineContent = { Text(a.name) },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        modifier = Modifier.clickable { onPick(a.id) }
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
    if (creating) NameDialog("Create album", "Album", "Create", { creating = false }) { name ->
        creating = false
        vm.createAlbum(name) { id -> onPick(id) }
    }
}
