plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.example.opengallery"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.opengallery"
        minSdk = 33          // Android 13+ (RedMagic 10 Pro ships Android 15)
        targetSdk = 35
        // Goes up by itself with every GitHub build, so each new APK can be installed over the previous one.
        versionCode = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionName = "0.52"
    }
    // ONE fixed signing key for every build (debug and release). Same key = a new APK installs over the old one
    // and keeps your data. Keep opengallery.jks safe: lose it and you must uninstall before updating.
    signingConfigs {
        create("gallery") {
            storeFile = file("opengallery.jks")
            storePassword = "opengallery"
            keyAlias = "opengallery"
            keyPassword = "opengallery"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("gallery") }
        getByName("release") {
            signingConfig = signingConfigs.getByName("gallery")
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.navigation:navigation-compose:2.8.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.5")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.5")

    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("androidx.media3:media3-transformer:1.4.1")
    implementation("androidx.media3:media3-effect:1.4.1")
    implementation("androidx.media3:media3-common:1.4.1")

    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("io.coil-kt:coil-video:2.7.0")
    implementation("io.coil-kt:coil-gif:2.7.0")
}
