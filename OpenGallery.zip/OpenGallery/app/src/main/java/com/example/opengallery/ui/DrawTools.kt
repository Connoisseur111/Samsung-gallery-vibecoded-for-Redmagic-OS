package com.example.opengallery.ui

import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.min

/** One brush stroke. Points are fractions (0..1) of the picture, so it looks the same at any size. */
data class InkStroke(
    val pts: List<Offset>,
    val color: Int,          // ARGB, fully opaque; transparency is [opacity]
    val size: Float,         // fraction of the picture's shorter side
    val opacity: Float,      // 0..1
    val eraser: Boolean
)

/** Draws strokes on a canvas of [w] x [h] pixels. The eraser only rubs out drawings, never the picture. */
fun drawInk(canvas: android.graphics.Canvas, w: Float, h: Float, strokes: List<InkStroke>) {
    if (strokes.isEmpty()) return
    val layer = canvas.saveLayer(0f, 0f, w, h, null)
    val side = min(w, h)
    strokes.forEach { st ->
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
            strokeWidth = (st.size * side).coerceAtLeast(1f)
            if (st.eraser) { color = 0; xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
            else { color = st.color or (0xFF shl 24); alpha = (st.opacity.coerceIn(0f, 1f) * 255).toInt() }
        }
        val pts = st.pts
        if (pts.size == 1) {
            canvas.drawPoint(pts[0].x * w, pts[0].y * h, p)
        } else if (pts.size > 1) {
            val path = android.graphics.Path()
            path.moveTo(pts[0].x * w, pts[0].y * h)
            for (i in 1 until pts.size) {
                val a = pts[i - 1]; val b = pts[i]
                path.quadTo(a.x * w, a.y * h, (a.x + b.x) / 2f * w, (a.y + b.y) / 2f * h)
            }
            path.lineTo(pts.last().x * w, pts.last().y * h)
            canvas.drawPath(path, p)
        }
    }
    canvas.restoreToCount(layer)
}

/** Transparent layer that shows the strokes over the picture and records new ones with your finger. */
@Composable
fun InkLayer(
    strokes: List<InkStroke>, live: InkStroke?, enabled: Boolean,
    onStart: (Offset) -> Unit, onMove: (Offset) -> Unit, onEnd: () -> Unit, modifier: Modifier = Modifier
) {
    val onStartL by androidx.compose.runtime.rememberUpdatedState(onStart)
    val onMoveL by androidx.compose.runtime.rememberUpdatedState(onMove)
    val onEndL by androidx.compose.runtime.rememberUpdatedState(onEnd)
    Canvas(
        modifier.pointerInput(enabled) {
            if (!enabled) return@pointerInput
            fun n(o: Offset) = Offset((o.x / size.width).coerceIn(0f, 1f), (o.y / size.height).coerceIn(0f, 1f))
            // finger down = start immediately (no waiting for a drag slop), so short strokes and dots work
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                down.consume()
                onStartL(n(down.position))
                do {
                    val ev = awaitPointerEvent()
                    ev.changes.forEach { c -> if (c.position != c.previousPosition) { onMoveL(n(c.position)); c.consume() } }
                } while (ev.changes.any { it.pressed })
                onEndL()
            }
        }
    ) {
        drawIntoCanvas { c -> drawInk(c.nativeCanvas, size.width, size.height, if (live != null) strokes + live else strokes) }
    }
}

/** Brush panel: Pen / Marker / Eraser, colour (wheel), size and opacity. */
@Composable
fun DrawPanel(
    mode: Int, onMode: (Int) -> Unit, color: Color, onColorClick: () -> Unit,
    size: Float, onSize: (Float) -> Unit, opacity: Float, onOpacity: (Float) -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.Center) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf("Pen", "Marker", "Eraser").forEachIndexed { i, label ->
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(if (i == mode) Color.White else Color(0xFF2E2E2E))
                        .clickable { onMode(i) }.padding(horizontal = 16.dp, vertical = 8.dp)
                ) { Text(label, color = if (i == mode) Color.Black else Color.White, fontSize = 14.sp) }
            }
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(color)
                    .border(2.dp, Color.White, CircleShape).clickable { onColorClick() }
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Size", color = Color.White, fontSize = 13.sp, modifier = Modifier.width(64.dp))
            Slider(size, onSize, valueRange = 1f..100f, modifier = Modifier.height(32.dp))
        }
        if (mode != 2) Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Opacity", color = Color.White, fontSize = 13.sp, modifier = Modifier.width(64.dp))
            Slider(opacity, onOpacity, valueRange = 0.1f..1f, modifier = Modifier.height(32.dp))
        }
    }
}

/** A real colour wheel (tap or drag: colour and strength) plus a brightness slider. */
@Composable
fun ColorWheelDialog(initial: Color, onPick: (Color) -> Unit, onDismiss: () -> Unit) {
    val hsv = remember {
        val a = FloatArray(3); android.graphics.Color.colorToHSV(initial.toArgb(), a); a
    }
    var hue by remember { mutableFloatStateOf(hsv[0]) }
    var sat by remember { mutableFloatStateOf(hsv[1]) }
    var value by remember { mutableFloatStateOf(if (hsv[2] < 0.05f) 1f else hsv[2]) }
    val current = Color.hsv(hue, sat, value)
    fun setFrom(o: Offset, size: androidx.compose.ui.unit.IntSize) {
        val r = min(size.width, size.height) / 2f
        val dx = o.x - size.width / 2f; val dy = o.y - size.height / 2f
        hue = ((Math.toDegrees(atan2(dy, dx).toDouble()).toFloat() % 360f) + 360f) % 360f
        sat = (hypot(dx, dy) / r).coerceIn(0f, 1f)
        onPick(Color.hsv(hue, sat, value))
    }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = CardBg,
        title = { Text("Color", color = Color.White) },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Canvas(
                    Modifier.size(240.dp)
                        .pointerInput(Unit) { detectTapGestures { setFrom(it, size) } }
                        .pointerInput(Unit) { detectDragGestures { ch, _ -> ch.consume(); setFrom(ch.position, size) } }
                ) {
                    val r = size.minDimension / 2f
                    drawCircle(Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)), r)
                    drawCircle(Brush.radialGradient(listOf(Color.White, Color.Transparent), radius = r), r)
                    drawCircle(Color.Black.copy(alpha = 1f - value), r)
                    val ang = Math.toRadians(hue.toDouble())
                    val p = Offset(
                        center.x + (kotlin.math.cos(ang) * sat * r).toFloat(),
                        center.y + (kotlin.math.sin(ang) * sat * r).toFloat()
                    )
                    drawCircle(Color.White, 11f, p, style = androidx.compose.ui.graphics.drawscope.Stroke(3f))
                    drawCircle(current, 8f, p)
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Light", color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.width(50.dp))
                    Slider(value, { value = it; onPick(Color.hsv(hue, sat, it)) }, valueRange = 0f..1f)
                }
                Box(Modifier.fillMaxWidth().height(28.dp).clip(RoundedCornerShape(10.dp)).background(current))
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )
}
