package com.example.opengallery.ui

import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.CancellationSignal
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.height
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.example.opengallery.GalleryViewModel

/** True only when this phone has a fingerprint sensor with a fingerprint set up. */
fun fingerprintAvailable(ctx: android.content.Context): Boolean = runCatching {
    ctx.getSystemService(BiometricManager::class.java)
        .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
}.getOrDefault(false)

private fun askFingerprint(ctx: android.content.Context, onOk: () -> Unit) {
    runCatching {
        val prompt = BiometricPrompt.Builder(ctx)
            .setTitle("Private albums")
            .setSubtitle("Use your fingerprint")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .setNegativeButton("Use PIN", ctx.mainExecutor) { _, _ -> }
            .build()
        prompt.authenticate(CancellationSignal(), ctx.mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) { onOk() }
        })
    }
}

/**
 * Asks for the fingerprint (when the phone has one) or the PIN. The first time, it asks you to create a PIN.
 * [newPin] = true lets you choose a new PIN instead (used by "Change PIN", after you already proved who you are).
 */
@Composable
fun PrivateAuthDialog(vm: GalleryViewModel, newPin: Boolean = false, onSuccess: () -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    val setup = newPin || !vm.hasPin()
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val bio = remember { !setup && fingerprintAvailable(ctx) }

    fun done() { vm.unlockPrivate(); onSuccess() }
    fun tryPin() {
        if (setup) {
            when {
                pin.length < 4 -> error = "Use at least 4 digits"
                pin != pin2 -> error = "The two PINs don't match"
                else -> { vm.setPin(pin); done() }
            }
        } else {
            val left = vm.pinLockSecondsLeft()
            if (left > 0) { error = "Too many tries. Wait $left s"; return }
            if (vm.checkPin(pin)) done() else { error = "Wrong PIN"; pin = "" }
        }
    }

    LaunchedEffect(Unit) { if (bio) askFingerprint(ctx) { done() } }

    val field = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
    AlertDialog(
        onDismissRequest = onCancel, containerColor = CardBg,
        title = { Text(if (setup) (if (newPin) "New PIN" else "Create a PIN") else "Private albums", color = Color.White) },
        text = {
            androidx.compose.foundation.layout.Column {
                Text(
                    if (setup) "This PIN protects your private albums." else "Enter your PIN" + if (bio) " or use your fingerprint." else ".",
                    color = Color.LightGray
                )
                androidx.compose.foundation.layout.Spacer(androidx.compose.ui.Modifier.height(10.dp))
                OutlinedTextField(
                    pin, { if (it.length <= 8 && it.all(Char::isDigit)) { pin = it; error = null } },
                    singleLine = true, label = { Text(if (setup) "PIN (4-8 digits)" else "PIN") },
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = field
                )
                if (setup) {
                    androidx.compose.foundation.layout.Spacer(androidx.compose.ui.Modifier.height(8.dp))
                    OutlinedTextField(
                        pin2, { if (it.length <= 8 && it.all(Char::isDigit)) { pin2 = it; error = null } },
                        singleLine = true, label = { Text("Repeat PIN") },
                        visualTransformation = PasswordVisualTransformation(), keyboardOptions = field
                    )
                }
                error?.let { Text(it, color = Color(0xFFFF6B6B)) }
            }
        },
        confirmButton = { TextButton(onClick = { tryPin() }) { Text(if (setup) "Save PIN" else "Unlock") } },
        dismissButton = {
            androidx.compose.foundation.layout.Row {
                if (bio) TextButton(onClick = { askFingerprint(ctx) { done() } }) { Text("Fingerprint") }
                TextButton(onClick = onCancel) { Text("Cancel") }
            }
        }
    )
}
