package com.example.opengallery.ui

import android.app.Activity
import android.content.ContextWrapper
import android.view.WindowInsets
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

class BarInsets(val left: Dp, val top: Dp, val right: Dp, val bottom: Dp)

/**
 * Size of the status bar, navigation bar and camera cut-out, read from the app's main window.
 * Pop-up windows (the viewer, the details screen) are not told these sizes, which is why their
 * buttons ended up underneath the navigation bar.
 */
@Composable
fun activityBarInsets(): BarInsets {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    var a: android.content.Context? = ctx
    while (a is ContextWrapper && a !is Activity) a = a.baseContext
    val i = (a as? Activity)?.window?.decorView?.rootWindowInsets
        ?.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
    if (i == null) return BarInsets(0.dp, 0.dp, 0.dp, 0.dp)
    return with(density) { BarInsets(i.left.toDp(), i.top.toDp(), i.right.toDp(), i.bottom.toDp()) }
}
