@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.example.opengallery.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import coil.request.ImageRequest
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.AlbumEntity
import com.example.opengallery.data.GalleryMedia
import com.example.opengallery.data.SortOption

fun fmt(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

@Composable
fun SortMenu(current: SortOption, onPick: (SortOption) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.AutoMirrored.Filled.Sort, "Sort") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            SortOption.entries.forEach { o ->
                DropdownMenuItem(
                    text = { Text(o.label) },
                    leadingIcon = { if (o == current) Icon(Icons.Default.Check, null) },
                    onClick = { onPick(o); open = false }
                )
            }
        }
    }
}

@Composable
fun MediaImage(m: GalleryMedia, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val req = remember(m.id) {
        ImageRequest.Builder(ctx).data(m.uri)
            .decoderFactory(VideoFrameDecoder.Factory()).crossfade(true).build()
    }
    AsyncImage(model = req, contentDescription = m.name, modifier = modifier, contentScale = ContentScale.Crop)
}

@Composable
fun Thumb(m: GalleryMedia, selected: Boolean, selecting: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    Box(
        Modifier.padding(2.dp).aspectRatio(1f)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
    ) {
        MediaImage(m, Modifier.fillMaxSize())
        if (m.isVideo) Row(
            Modifier.align(Alignment.BottomEnd).padding(4.dp)
                .background(Color(0x99000000), RoundedCornerShape(6.dp)).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(14.dp))
            Text(fmt(m.duration), color = Color.White, style = MaterialTheme.typography.labelSmall)
        }
        if (selected) Box(Modifier.fillMaxSize().background(Color(0x4400AAFF)))
        if (selecting) Icon(
            if (selected) Icons.Default.CheckCircle else Icons.Outlined.RadioButtonUnchecked, null,
            tint = Color.White, modifier = Modifier.align(Alignment.TopStart).padding(4.dp)
        )
    }
}

@Composable
fun AlbumTile(name: String, onClick: () -> Unit, onLong: () -> Unit) {
    Column(
        Modifier.padding(4.dp).aspectRatio(1f).clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.secondaryContainer)
            .combinedClickable(onClick = onClick, onLongClick = onLong).padding(8.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.PhotoAlbum, null, modifier = Modifier.size(40.dp))
        Text(name, maxLines = 2, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun NamePromptDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, singleLine = true, label = { Text("Name") }) },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { onOk(text.trim()) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/** Browse the album tree and pick a location (used for "add to album" and "move album"). */
@Composable
fun AlbumPickerDialog(
    vm: GalleryViewModel, title: String, allowRoot: Boolean, hideId: Long? = null,
    onDismiss: () -> Unit, onPick: (Long) -> Unit
) {
    val stack = remember { mutableStateListOf<AlbumEntity>() }
    val current = stack.lastOrNull()
    val kids by remember(current?.id) { vm.children(current?.id ?: 0L) }.collectAsState(emptyList())
    var creating by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text(current?.name ?: "Top level", style = MaterialTheme.typography.titleSmall)
                if (current != null) TextButton(onClick = { stack.removeAt(stack.lastIndex) }) { Text("↑ Up") }
                LazyColumn(Modifier.heightIn(max = 280.dp)) {
                    items(kids.filter { it.id != hideId }, key = { it.id }) { a ->
                        ListItem(
                            headlineContent = { Text(a.name) },
                            leadingContent = { Icon(Icons.Default.Folder, null) },
                            modifier = Modifier.clickable { stack.add(a) }
                        )
                    }
                }
                TextButton(onClick = { creating = true }) { Text("+ New album here") }
            }
        },
        confirmButton = {
            TextButton(enabled = allowRoot || current != null, onClick = { onPick(current?.id ?: 0L) }) {
                Text("Choose here")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
    if (creating) NamePromptDialog("New album", "", { creating = false }) {
        vm.createAlbum(it, current?.id ?: 0L); creating = false
    }
}
