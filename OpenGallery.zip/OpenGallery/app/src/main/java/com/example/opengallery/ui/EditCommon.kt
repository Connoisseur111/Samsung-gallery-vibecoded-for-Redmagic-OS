package com.example.opengallery.ui

import android.graphics.ColorMatrix
import androidx.compose.foundation.Canvas
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.roundToInt

enum class Look(val label: String) {
    ORIGINAL("Original"), MONO("Monotone"), BLANC("Blanc"), SEPIA("Sepia"),
    VIVID("Vivid"), WARM("Warm"), COOL("Cool"), NOIR("Noir")
}

fun lookMatrix(l: Look): ColorMatrix? = when (l) {
    Look.ORIGINAL -> null
    Look.MONO -> ColorMatrix().apply { setSaturation(0f) }
    Look.BLANC -> ColorMatrix(floatArrayOf(
        1f, 0f, 0f, 0f, 35f,
        0f, 1f, 0f, 0f, 35f,
        0f, 0f, 1f, 0f, 35f,
        0f, 0f, 0f, 1f, 0f))
    Look.SEPIA -> ColorMatrix(floatArrayOf(
        0.393f, 0.769f, 0.189f, 0f, 0f,
        0.349f, 0.686f, 0.168f, 0f, 0f,
        0.272f, 0.534f, 0.131f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f))
    Look.VIVID -> ColorMatrix().apply { setSaturation(1.5f) }
    Look.WARM -> ColorMatrix(floatArrayOf(
        1.1f, 0f, 0f, 0f, 0f,
        0f, 1f, 0f, 0f, 0f,
        0f, 0f, 0.9f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f))
    Look.COOL -> ColorMatrix(floatArrayOf(
        0.9f, 0f, 0f, 0f, 0f,
        0f, 1f, 0f, 0f, 0f,
        0f, 0f, 1.1f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f))
    Look.NOIR -> ColorMatrix().apply {
        setSaturation(0f)
        postConcat(ColorMatrix(floatArrayOf(
            1.4f, 0f, 0f, 0f, -50f,
            0f, 1.4f, 0f, 0f, -50f,
            0f, 0f, 1.4f, 0f, -50f,
            0f, 0f, 0f, 1f, 0f)))
    }
}

/** Fractions (0..1) trimmed from each side of the image. */
data class CropRect(val l: Float = 0f, val t: Float = 0f, val r: Float = 0f, val b: Float = 0f) {
    val isFull: Boolean get() = l == 0f && t == 0f && r == 0f && b == 0f
}

fun rectForRatio(ratio: Float?, imageAspect: Float): CropRect {
    if (ratio == null) return CropRect()
    return if (ratio > imageAspect) {
        val hf = imageAspect / ratio
        CropRect(t = (1f - hf) / 2f, b = (1f - hf) / 2f)
    } else {
        val wf = ratio / imageAspect
        CropRect(l = (1f - wf) / 2f, r = (1f - wf) / 2f)
    }
}

/** Draggable crop frame with rule-of-thirds grid; drag an edge/corner to resize or the inside to move. */
@Composable
fun CropOverlay(rect: CropRect, onChange: (CropRect) -> Unit, onCommit: () -> Unit, modifier: Modifier = Modifier) {
    val cur by rememberUpdatedState(rect)
    val changeCb by rememberUpdatedState(onChange)
    val commitCb by rememberUpdatedState(onCommit)
    var mask by remember { mutableIntStateOf(0) }
    Canvas(
        modifier.pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { o ->
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    val th = 40.dp.toPx()
                    val c = cur
                    val xl = c.l * w
                    val xr = (1f - c.r) * w
                    val yt = c.t * h
                    val yb = (1f - c.b) * h
                    var m = 0
                    if (o.y >= yt - th && o.y <= yb + th) {
                        if (abs(o.x - xl) < th) m = m or 1
                        if (abs(o.x - xr) < th) m = m or 4
                    }
                    if (o.x >= xl - th && o.x <= xr + th) {
                        if (abs(o.y - yt) < th) m = m or 2
                        if (abs(o.y - yb) < th) m = m or 8
                    }
                    if (m == 0 && o.x >= xl && o.x <= xr && o.y >= yt && o.y <= yb) m = 16
                    mask = m
                },
                onDragEnd = { commitCb() },
                onDragCancel = { commitCb() },
                onDrag = { pc, amount ->
                    pc.consume()
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    val c = cur
                    val dx = amount.x / w
                    val dy = amount.y / h
                    val minSize = 0.12f
                    var l = c.l
                    var t = c.t
                    var r = c.r
                    var b = c.b
                    val m = mask
                    if (m == 16) {
                        val wd = 1f - l - r
                        val ht = 1f - t - b
                        l = (l + dx).coerceIn(0f, 1f - wd)
                        r = 1f - wd - l
                        t = (t + dy).coerceIn(0f, 1f - ht)
                        b = 1f - ht - t
                    } else {
                        if ((m and 1) != 0) l = (l + dx).coerceIn(0f, 1f - r - minSize)
                        if ((m and 4) != 0) r = (r - dx).coerceIn(0f, 1f - l - minSize)
                        if ((m and 2) != 0) t = (t + dy).coerceIn(0f, 1f - b - minSize)
                        if ((m and 8) != 0) b = (b - dy).coerceIn(0f, 1f - t - minSize)
                    }
                    changeCb(CropRect(l, t, r, b))
                }
            )
        }
    ) {
        val w = size.width
        val h = size.height
        val l = rect.l * w
        val t = rect.t * h
        val r = (1f - rect.r) * w
        val b = (1f - rect.b) * h
        val dim = Color(0x88000000)
        drawRect(dim, Offset(0f, 0f), Size(w, t))
        drawRect(dim, Offset(0f, b), Size(w, h - b))
        drawRect(dim, Offset(0f, t), Size(l, b - t))
        drawRect(dim, Offset(r, t), Size(w - r, b - t))
        drawRect(Color.White, Offset(l, t), Size(r - l, b - t), style = Stroke(width = 2.dp.toPx()))
        val grid = Color(0x88FFFFFF)
        for (i in 1..2) {
            val x = l + (r - l) * i / 3f
            drawLine(grid, Offset(x, t), Offset(x, b), strokeWidth = 1.dp.toPx())
            val y = t + (b - t) * i / 3f
            drawLine(grid, Offset(l, y), Offset(r, y), strokeWidth = 1.dp.toPx())
        }
        listOf(Offset(l, t), Offset(r, t), Offset(l, b), Offset(r, b)).forEach {
            drawCircle(Color.White, 5.dp.toPx(), it)
        }
    }
}

/** Flip / rotate / aspect-ratio / flip row shown under the crop frame. */
@Composable
fun CropToolsRow(onFlipH: () -> Unit, onRotate: () -> Unit, onFlipV: () -> Unit, onRatio: (Float?) -> Unit) {
    var showRatios by remember { mutableStateOf(false) }
    val ratios: List<Pair<String, Float?>> = listOf(
        "Free" to null, "1:1" to 1f, "4:3" to 4f / 3f, "3:4" to 3f / 4f, "16:9" to 16f / 9f, "9:16" to 9f / 16f
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.clip(RoundedCornerShape(24.dp)).background(Color(0x55FFFFFF))) {
            IconButton(onClick = onFlipH) { Icon(Icons.Filled.Flip, "Flip horizontally", tint = Color.White) }
            IconButton(onClick = onRotate) { Icon(Icons.Filled.RotateRight, "Rotate", tint = Color.White) }
            IconButton(onClick = { showRatios = !showRatios }) { Icon(Icons.Filled.AspectRatio, "Aspect ratio", tint = Color.White) }
            IconButton(onClick = onFlipV) { Icon(Icons.Filled.Flip, "Flip vertically", tint = Color.White, modifier = Modifier.rotate(90f)) }
        }
        if (showRatios) Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            ratios.forEach { (name, r) -> TextButton(onClick = { onRatio(r) }) { Text(name, color = Color.White) } }
        }
    }
}

@Composable
fun EditTopBar(
    canUndo: Boolean, canRedo: Boolean, onUndo: () -> Unit, onRedo: () -> Unit,
    onRevert: () -> Unit, onSave: () -> Unit, saveEnabled: Boolean = true,
    onSaveCopy: () -> Unit = {}, onSizeFormat: (() -> Unit)? = null
) {
    val dim = Color(0x66FFFFFF)
    var menu by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onUndo, enabled = canUndo) {
            Icon(Icons.AutoMirrored.Filled.Undo, "Undo", tint = if (canUndo) Color.White else dim)
        }
        IconButton(onClick = onRedo, enabled = canRedo) {
            Icon(Icons.AutoMirrored.Filled.Redo, "Redo", tint = if (canRedo) Color.White else dim)
        }
        Spacer(Modifier.weight(1f))
        TextButton(onClick = onRevert, enabled = canUndo) {
            Text("Revert", color = if (canUndo) Color.White else dim, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        // "Save" replaces the original file (like Samsung); "Save copy" is in the menu.
        TextButton(onClick = onSave, enabled = saveEnabled) {
            Text("Save", color = if (saveEnabled) Color.White else dim, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, "More", tint = Color.White)
            }
            androidx.compose.material3.DropdownMenu(
                expanded = menu, onDismissRequest = { menu = false }, containerColor = CardBg
            ) {
                androidx.compose.material3.DropdownMenuItem(
                    text = { Text("Save copy", color = if (saveEnabled) Color.White else dim) },
                    enabled = saveEnabled, onClick = { menu = false; onSaveCopy() }
                )
                if (onSizeFormat != null) androidx.compose.material3.DropdownMenuItem(
                    text = { Text("Size and format", color = Color.White) },
                    onClick = { menu = false; onSizeFormat() }
                )
            }
        }
    }
}

/**
 * Asks for permission to change the ORIGINAL file (system "Allow Gallery to modify this?" prompt),
 * unless "Media management" is already allowed. [run] is called once changing it is allowed.
 */
@Composable
fun rememberWriteGate(uri: android.net.Uri): (() -> Unit) -> Unit {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var pending by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<(() -> Unit)?>(null) }
    val launcher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartIntentSenderForResult()
    ) { r ->
        val p = pending; pending = null
        if (r.resultCode == android.app.Activity.RESULT_OK) p?.invoke()
    }
    return { run ->
        if (android.provider.MediaStore.canManageMedia(ctx)) run()
        else {
            pending = run
            val pi = android.provider.MediaStore.createWriteRequest(ctx.contentResolver, listOf(uri))
            launcher.launch(androidx.activity.result.IntentSenderRequest.Builder(pi).build())
        }
    }
}

/** After a file was replaced, drop cached thumbnails/pictures so the new version is shown. */
fun clearImageCaches(ctx: android.content.Context) {
    runCatching { coil.Coil.imageLoader(ctx).memoryCache?.clear() }
    clearSharedViewerLoader()
}

@Composable
fun ToolDock(icons: List<ImageVector>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        icons.forEachIndexed { i, ic ->
            IconButton(onClick = { onSelect(i) }) {
                Icon(ic, null, tint = if (i == selected) Yellow else Color.White)
            }
        }
    }
}

/** Row of round tool buttons (the selected one shows its value) with a slider underneath. */
@Composable
fun TunePanel(
    names: List<String>, icons: List<ImageVector>, values: List<Int>,
    onChange: (Int, Int) -> Unit, onCommit: () -> Unit
) {
    var idx by remember { mutableIntStateOf(0) }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(names[idx], color = Color.White, fontSize = 13.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(horizontal = 16.dp)) {
            itemsIndexed(names) { i, n ->
                Box(
                    Modifier.size(52.dp).clip(CircleShape)
                        .background(if (i == idx) Color.White else Color(0xFF2E2E2E)).clickable { idx = i },
                    contentAlignment = Alignment.Center
                ) {
                    if (i == idx) Text("${values[i]}", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    else Icon(icons[i], n, tint = Color.White)
                }
            }
        }
        Slider(
            value = values[idx].toFloat(),
            onValueChange = { onChange(idx, it.roundToInt()) },
            onValueChangeFinished = onCommit,
            valueRange = -100f..100f,
            colors = SliderDefaults.colors(
                thumbColor = Yellow, activeTrackColor = Yellow, inactiveTrackColor = Color(0x44FFFFFF)
            ),
            modifier = Modifier.padding(horizontal = 24.dp)
        )
    }
}

@Composable
fun FilterStrip(looks: List<Look>, selected: Look, thumb: ImageBitmap?, onPick: (Look) -> Unit) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(horizontal = 16.dp)
    ) {
        items(looks) { l ->
            val shape = RoundedCornerShape(10.dp)
            Column(Modifier.clickable { onPick(l) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(64.dp).clip(shape)
                        .background(Color(0xFF3A3A3A))
                        .border(if (l == selected) 2.dp else 0.dp, Color.White, shape)
                ) {
                    if (thumb != null) {
                        val m = lookMatrix(l)
                        Image(
                            thumb, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
                            colorFilter = if (m == null) null
                            else ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix(m.array))
                        )
                    }
                }
                Text(l.label, color = Color.White, fontSize = 11.sp)
            }
        }
    }
}
