package com.example.opengallery

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.opengallery.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val ctx = LocalContext.current
            val scheme = if (isSystemInDarkTheme()) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize()) { PermissionGate { GalleryApp() } }
            }
        }
    }
}

@Composable
private fun PermissionGate(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val perms = arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    var granted by remember {
        mutableStateOf(perms.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED })
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        granted = r.values.all { it }
    }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(perms) }
    if (granted) content() else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Button(onClick = { launcher.launch(perms) }, modifier = Modifier.padding(24.dp)) {
            Text("Allow access to photos and videos")
        }
    }
}

@Composable
fun GalleryApp() {
    val vm: GalleryViewModel = viewModel()
    val nav = rememberNavController()
    LaunchedEffect(Unit) { vm.refresh() }
    val longArg = listOf(navArgument("id") { type = NavType.LongType })
    NavHost(nav, startDestination = "home") {
        composable("home") { HomeScreen(vm, nav) }
        composable("folder/{id}", longArg) { FolderScreen(vm, nav, it.arguments!!.getLong("id")) }
        composable("album/{id}", longArg) { AlbumScreen(vm, nav, it.arguments!!.getLong("id")) }
        composable("viewer/{index}", listOf(navArgument("index") { type = NavType.IntType })) {
            ViewerScreen(vm, nav, it.arguments!!.getInt("index"))
        }
        composable("editor/{id}", longArg) { EditorScreen(vm, nav, it.arguments!!.getLong("id")) }
        composable("photoeditor/{id}", longArg) { PhotoEditorScreen(vm, nav, it.arguments!!.getLong("id")) }
    }
}
