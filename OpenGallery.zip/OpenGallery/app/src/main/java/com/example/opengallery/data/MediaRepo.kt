package com.example.opengallery.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.provider.MediaStore.MediaColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class GalleryMedia(
    val id: Long,
    val uri: Uri,
    val isVideo: Boolean,
    val name: String,
    val size: Long,
    val dateTaken: Long,
    val duration: Long,
    val bucketId: Long,
    val bucketName: String,
    val relativePath: String
)

enum class SortOption(val label: String) {
    NEWEST("Newest first"),
    OLDEST("Oldest first"),
    NAME_AZ("Name A–Z"),
    NAME_ZA("Name Z–A"),
    SIZE_LARGE("Size: largest"),
    SIZE_SMALL("Size: smallest")
}

/** One sorting helper used for folders, albums, photos and videos. */
fun <T> List<T>.sortedBySetting(
    opt: SortOption,
    name: (T) -> String,
    date: (T) -> Long,
    size: (T) -> Long
): List<T> = when (opt) {
    SortOption.NEWEST -> sortedByDescending(date)
    SortOption.OLDEST -> sortedBy(date)
    SortOption.NAME_AZ -> sortedBy { name(it).lowercase() }
    SortOption.NAME_ZA -> sortedByDescending { name(it).lowercase() }
    SortOption.SIZE_LARGE -> sortedByDescending(size)
    SortOption.SIZE_SMALL -> sortedBy(size)
}

class MediaRepo(private val context: Context) {
    suspend fun load(): List<GalleryMedia> = withContext(Dispatchers.IO) {
        val out = mutableListOf<GalleryMedia>()
        val type = MediaStore.Files.FileColumns.MEDIA_TYPE
        val projection = arrayOf(
            MediaColumns._ID, type, MediaColumns.DISPLAY_NAME, MediaColumns.SIZE, MediaColumns.DATE_ADDED, MediaColumns.DATE_TAKEN,
            MediaColumns.DURATION, MediaColumns.BUCKET_ID, MediaColumns.BUCKET_DISPLAY_NAME, MediaColumns.RELATIVE_PATH
        )
        val selection = "$type IN (?, ?)"
        val args = arrayOf(
            MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
            MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString()
        )
        context.contentResolver.query(
            MediaStore.Files.getContentUri("external"), projection, selection, args, null
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaColumns._ID)
            val iType = c.getColumnIndexOrThrow(type)
            val iName = c.getColumnIndexOrThrow(MediaColumns.DISPLAY_NAME)
            val iSize = c.getColumnIndexOrThrow(MediaColumns.SIZE)
            val iAdded = c.getColumnIndexOrThrow(MediaColumns.DATE_ADDED)
            val iTaken = c.getColumnIndexOrThrow(MediaColumns.DATE_TAKEN)
            val iDur = c.getColumnIndexOrThrow(MediaColumns.DURATION)
            val iBid = c.getColumnIndexOrThrow(MediaColumns.BUCKET_ID)
            val iBname = c.getColumnIndexOrThrow(MediaColumns.BUCKET_DISPLAY_NAME)
            val iRel = c.getColumnIndexOrThrow(MediaColumns.RELATIVE_PATH)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val video = c.getInt(iType) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                val taken = c.getLong(iTaken).takeIf { it > 0 } ?: (c.getLong(iAdded) * 1000)
                out += GalleryMedia(
                    id = id,
                    uri = ContentUris.withAppendedId(base, id),
                    isVideo = video,
                    name = c.getString(iName) ?: "Unknown",
                    size = c.getLong(iSize),
                    dateTaken = taken,
                    duration = c.getLong(iDur),
                    bucketId = c.getLong(iBid),
                    bucketName = c.getString(iBname) ?: "Other",
                    relativePath = c.getString(iRel) ?: ""
                )
            }
        }
        out
    }
}
