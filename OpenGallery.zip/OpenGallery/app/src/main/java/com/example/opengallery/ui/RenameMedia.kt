package com.example.opengallery.ui

import android.content.ContentValues
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.example.opengallery.data.GalleryMedia

/** Renames a picture / video / GIF (the extension is kept). Asks Android for permission when needed. */
@Composable
fun RenameMediaDialog(m: GalleryMedia, onDismiss: () -> Unit, onRenamed: (String) -> Unit) {
    val ctx = LocalContext.current
    val gate = rememberWriteGate(m.uri)
    val ext = m.name.substringAfterLast('.', "")
    val base = if (ext.isEmpty()) m.name else m.name.dropLast(ext.length + 1)
    NameDialog("Rename", base, "Rename", onDismiss) { n ->
        val clean = n.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (clean.isBlank() || clean == base) { onDismiss(); return@NameDialog }
        val full = if (ext.isEmpty()) clean else "$clean.$ext"
        // the dialog stays on screen until Android's permission prompt (if any) is answered
        gate {
            val ok = runCatching {
                val cv = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, full) }
                ctx.contentResolver.update(m.uri, cv, null, null) > 0
            }.getOrDefault(false)
            Toast.makeText(ctx, if (ok) "Renamed" else "Couldn't rename (is there already a file with that name?)", Toast.LENGTH_LONG).show()
            if (ok) onRenamed(full)
            onDismiss()
        }
    }
}
