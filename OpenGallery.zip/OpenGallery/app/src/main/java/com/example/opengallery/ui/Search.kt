package com.example.opengallery.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.GalleryMedia
import com.example.opengallery.data.SortOption
import com.example.opengallery.data.sortedByOption

/** Does [m] match one search word? Understands type words (video, gif, screenshot ...) as well as names/albums/dates. */
private fun matchesToken(m: GalleryMedia, t: String): Boolean {
    val n = m.name.lowercase()
    val p = m.relativePath.lowercase()
    return when (t) {
        "video", "videos" -> m.isVideo
        "image", "images", "photo", "photos", "picture", "pictures" -> !m.isVideo
        "gif", "gifs" -> n.endsWith(".gif")
        "screenshot", "screenshots", "screen" -> "screenshot" in n || "screenshot" in p || "screen_rec" in n || "screenrecord" in p
        "edited", "edit" -> "_edit" in n || "edited" in n || m.bucketName.equals("OpenGallery", true)
        "burst" -> "burst" in n
        "selfie", "selfies" -> "selfie" in n || "selfie" in p || "front" in n
        "portrait" -> "portrait" in n
        else -> t in (n + " " + m.bucketName.lowercase() + " " + fmtDate(m.dateTaken).lowercase())
    }
}

private fun matchesAll(m: GalleryMedia, tokens: List<String>) = tokens.all { matchesToken(m, it) }

@Composable
private fun SearchChip(text: String, onClick: () -> Unit) {
    Text(
        text, color = Color.White, fontSize = 15.sp, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(22.dp)).background(CardBg).clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    )
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 16.dp, top = 22.dp, bottom = 10.dp))
}

@Composable
private fun CountRow(label: String, count: Int, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text("$count", color = Color(0xAAFFFFFF), fontSize = 16.sp)
    }
}

@Composable
fun SearchScreen(vm: GalleryViewModel, nav: NavController, scopeKey: String) {
    val media by vm.media.collectAsState()
    val albums by vm.albums.collectAsState()
    val links by vm.links.collectAsState()
    val favorites by vm.favorites.collectAsState()
    var scoped by rememberSaveable { mutableStateOf(scopeKey != "all") }
    var query by rememberSaveable { mutableStateOf("") }
    var grouped by rememberSaveable { mutableStateOf(true) }
    var menuOpen by remember { mutableStateOf(false) }
    var sortOpt by rememberSaveable { mutableStateOf(SortOption.CREATED_DESC) }
    var showSort by remember { mutableStateOf(false) }
    var selecting by remember { mutableStateOf(false) }
    var selectedIds by remember { mutableStateOf(setOf<Long>()) }
    var creating by remember { mutableStateOf(false) }

    val scopeMedia = remember(scopeKey, media, links, favorites) {
        if (scopeKey == "all") media else mediaForKey(scopeKey, media, links, favorites)
    }
    val base = if (scoped) scopeMedia else media
    val scopeTitle = remember(scopeKey, albums, scopeMedia, FolderNames.map) { titleForKey(scopeKey, albums, scopeMedia) }
    val tokens = query.lowercase().split(" ").filter { it.isNotBlank() }
    val active = tokens.isNotEmpty()
    val results = remember(base, tokens, sortOpt) {
        if (tokens.isEmpty()) emptyList()
        else base.filter { matchesAll(it, tokens) }.sortedByOption(sortOpt)
    }

    // Search-home data
    val suggestions = remember(base) {
        val albumNames = base.groupBy { it.bucketName }.entries.sortedByDescending { it.value.size }.map { it.key }.filter { it.isNotBlank() }.take(6)
        listOf("Video", "Image") + albumNames
    }
    val shotTypes = remember(base) {
        listOf("Video", "GIF", "Screenshot", "Burst", "Selfie", "Portrait")
            .map { it to base.count { m -> matchesToken(m, it.lowercase()) } }
            .filter { it.second > 0 }
    }
    val editedCount = remember(base) { base.count { matchesToken(it, "edited") } }

    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (query.isEmpty()) focus.requestFocus() }

    fun exitSelect() { selecting = false; selectedIds = emptySet() }
    BackHandler(enabled = selecting || active) {
        if (selecting) exitSelect() else query = ""
    }

    Column(Modifier.fillMaxSize().background(AppBg)) {
        // Top bar
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (selecting) exitSelect() else nav.popBackStack() }) {
                Icon(if (selecting) Icons.Filled.Close else Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                if (selecting) {
                    Text(if (selectedIds.isEmpty()) "Select items" else "${selectedIds.size} selected", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                } else if (active) {
                    Text("Search results", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            if (active) Box {
                IconButton(onClick = { menuOpen = true }) { Icon(Icons.Filled.MoreVert, "More", tint = Color.White) }
                DropdownMenu(
                    expanded = menuOpen, onDismissRequest = { menuOpen = false },
                    modifier = Modifier.background(CardBg, RoundedCornerShape(20.dp))
                ) {
                    MenuItem(if (selecting) "Deselect all" else "Select") {
                        menuOpen = false
                        if (selecting) selectedIds = emptySet() else selecting = true
                    }
                    MenuItem("Sort") { menuOpen = false; showSort = true }
                    MenuItem("Create album") { menuOpen = false; creating = true }
                    MenuItem("Start slideshow") {
                        menuOpen = false
                        if (results.isNotEmpty()) { vm.viewerList = results; nav.navigate("viewer/0/1") }
                    }
                }
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (!active) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    SectionTitle("You might be looking for")
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        suggestions.forEach { s -> SearchChip(s) { query = s } }
                    }
                    if (editedCount > 0) {
                        SectionTitle("Activity")
                        CountRow("Edited", editedCount) { query = "edited" }
                    }
                    if (shotTypes.isNotEmpty()) {
                        SectionTitle("Shot types")
                        shotTypes.forEach { (label, count) -> CountRow(label, count) { query = label.lowercase() } }
                    }
                    Spacer(Modifier.size(24.dp))
                }
            } else if (results.isEmpty()) {
                Text(
                    "No results found", color = Color.Gray,
                    modifier = Modifier.align(Alignment.Center).padding(32.dp)
                )
            } else {
                val top = results.take(8)
                MediaList(
                    media = results, grouped = grouped, selected = selectedIds, selecting = selecting,
                    onTap = { i ->
                        if (selecting) { val id = results[i].id; selectedIds = if (id in selectedIds) selectedIds - id else selectedIds + id }
                        else { vm.viewerList = results; nav.navigate("viewer/$i/0") }
                    },
                    onLong = { m -> selecting = true; selectedIds = selectedIds + m.id },
                    onDragSet = { m, on -> selecting = true; selectedIds = if (on) selectedIds + m.id else selectedIds - m.id },
                    modifier = Modifier.fillMaxSize(),
                    header = {
                        Column(Modifier.fillMaxWidth()) {
                            SectionTitle("Top results")
                            top.chunked(4).forEach { rowItems ->
                                Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                    rowItems.forEach { m ->
                                        val i = results.indexOf(m)
                                        MediaCell(
                                            m, m.id in selectedIds, selecting,
                                            onClick = {
                                                if (selecting) selectedIds = if (m.id in selectedIds) selectedIds - m.id else selectedIds + m.id
                                                else { vm.viewerList = results; nav.navigate("viewer/$i/0") }
                                            },
                                            onLong = { selecting = true; selectedIds = selectedIds + m.id },
                                            modifier = Modifier.weight(1f).aspectRatio(1f)
                                        )
                                    }
                                    repeat(4 - rowItems.size) { Spacer(Modifier.weight(1f)) }
                                }
                                Spacer(Modifier.size(2.dp))
                            }
                            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 22.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("All results", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.width(8.dp))
                                Text("${results.size} items", color = Color(0xAAFFFFFF), fontSize = 14.sp, modifier = Modifier.weight(1f))
                                Text(
                                    if (grouped) "Ungroup" else "Group by date", color = Accent, fontSize = 15.sp,
                                    modifier = Modifier.clickable { grouped = !grouped }.padding(4.dp)
                                )
                            }
                        }
                    }
                )
            }
        }

        // Bottom search pill
        Row(
            Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.ime.union(WindowInsets.navigationBars)).padding(12.dp)
                .clip(RoundedCornerShape(30.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF2A3342), Color(0xFF2E2A3A), Color(0xFF1E1E1E))))
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (scoped) {
                Row(
                    Modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xFF3A3A3A)).padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(scopeTitle, color = Color.White, fontSize = 13.sp, maxLines = 1)
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.Filled.Close, "Remove", tint = Color.White, modifier = Modifier.size(16.dp).clickable { scoped = false })
                }
                Spacer(Modifier.width(8.dp))
            }
            BasicTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 17.sp),
                cursorBrush = SolidColor(Color.White),
                modifier = Modifier.weight(1f).focusRequester(focus),
                decorationBox = { inner ->
                    Box {
                        if (query.isEmpty()) Text("What are you looking for?", color = Color(0xAAFFFFFF), fontSize = 17.sp)
                        inner()
                    }
                }
            )
            if (query.isNotEmpty()) Icon(Icons.Filled.Close, "Clear", tint = Color.White, modifier = Modifier.size(24.dp).clickable { query = "" })
            else Icon(Icons.Filled.Search, null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
    }

    if (showSort) SortDialog(sortOpt, grouped, onDismiss = { showSort = false }) { o, g ->
        sortOpt = o; grouped = g; showSort = false
    }
    if (creating) NameDialog("Create album", "Album", "Create", { creating = false }) { name ->
        creating = false
        val items = if (selecting && selectedIds.isNotEmpty()) results.filter { it.id in selectedIds } else results
        vm.createAlbum(name) { id -> vm.addToAlbum(id, items) }
        exitSelect()
    }
}
