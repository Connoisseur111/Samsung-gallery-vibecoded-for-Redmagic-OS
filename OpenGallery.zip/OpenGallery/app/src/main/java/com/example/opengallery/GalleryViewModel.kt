package com.example.opengallery

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.opengallery.data.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class GalleryViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = MediaRepo(app)
    private val dao = GalleryDb.get(app).albumDao()

    val media = MutableStateFlow<List<GalleryMedia>>(emptyList())
    val sort = MutableStateFlow(SortOption.NEWEST)

    /** The list the full-screen viewer pages through (set right before navigating to it). */
    var viewerList: List<GalleryMedia> = emptyList()

    fun refresh() { viewModelScope.launch { media.value = repo.load() } }
    fun setSort(s: SortOption) { sort.value = s }

    // Album id 0 = the top level.
    private fun pid(id: Long): Long? = if (id == 0L) null else id

    fun children(parent: Long): Flow<List<AlbumEntity>> = dao.children(pid(parent))
    fun albumItems(albumId: Long): Flow<List<AlbumItemEntity>> = dao.items(albumId)
    suspend fun albumName(id: Long): String = if (id == 0L) "Albums" else dao.get(id)?.name ?: "Album"

    fun createAlbum(name: String, parent: Long) {
        viewModelScope.launch { dao.insert(AlbumEntity(name = name, parentId = pid(parent))) }
    }

    fun renameAlbum(id: Long, name: String) { viewModelScope.launch { dao.rename(id, name) } }
    fun deleteAlbum(id: Long) { viewModelScope.launch { dao.delete(id) } } // cascades to sub-albums

    /** Moves an album under another one; refuses to create a loop (album inside itself/its child). */
    fun moveAlbum(id: Long, newParent: Long, done: (Boolean) -> Unit) {
        viewModelScope.launch {
            var cursor: Long? = pid(newParent)
            var ok = true
            while (cursor != null) {
                if (cursor == id) { ok = false; break }
                cursor = dao.get(cursor)?.parentId
            }
            if (ok) dao.move(id, pid(newParent))
            done(ok)
        }
    }

    fun addToAlbum(albumId: Long, items: List<GalleryMedia>) {
        viewModelScope.launch {
            dao.addItems(items.map { AlbumItemEntity(albumId, it.id) })
            Toast.makeText(getApplication(), "Added ${items.size} item(s)", Toast.LENGTH_SHORT).show()
        }
    }

    fun removeFromAlbum(albumId: Long, ids: List<Long>) {
        viewModelScope.launch { dao.removeItems(albumId, ids) }
    }
}
