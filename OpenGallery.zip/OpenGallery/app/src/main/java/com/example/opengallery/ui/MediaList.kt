package com.example.opengallery.ui

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.opengallery.data.GalleryMedia

sealed interface ListRow {
    data class Header(val label: String) : ListRow
    /** cells = (index into the media list, aspect ratio); full rows stretch to the screen width. */
    data class Cells(val cells: List<Pair<Int, Float>>, val heightDp: Float, val full: Boolean) : ListRow
}

private const val GAP = 2f

/**
 * grouped = false -> uniform 4-column squares (default album view).
 * grouped = true  -> date headers + justified rows that keep each picture's aspect ratio.
 */
fun buildRows(media: List<GalleryMedia>, widthDp: Float, grouped: Boolean): List<ListRow> {
    val rows = mutableListOf<ListRow>()
    if (!grouped) {
        val cols = (widthDp / 120f).toInt().coerceAtLeast(4)
        val h = (widthDp - GAP * (cols - 1)) / cols
        media.indices.chunked(cols).forEach { idx ->
            rows += ListRow.Cells(idx.map { it to 1f }, h, idx.size == cols)
        }
        return rows
    }
    val target = 120f
    fun addSection(label: String, idx: List<Int>) {
        rows += ListRow.Header(label)
        var cur = mutableListOf<Pair<Int, Float>>()
        var sum = 0f
        for (i in idx) {
            val m = media[i]
            val a = if (m.width > 0 && m.height > 0) (m.width.toFloat() / m.height).coerceIn(0.6f, 2f) else 1f
            cur.add(i to a)
            sum += a
            if (sum * target + GAP * (cur.size - 1) >= widthDp) {
                val h = (widthDp - GAP * (cur.size - 1)) / sum
                rows += ListRow.Cells(cur.toList(), h, true)
                cur = mutableListOf()
                sum = 0f
            }
        }
        if (cur.isNotEmpty()) rows += ListRow.Cells(cur.toList(), target, false)
    }
    var label: String? = null
    var section = mutableListOf<Int>()
    media.forEachIndexed { i, m ->
        val l = fmtDate(m.dateTaken)
        if (l != label) {
            val prev = label
            if (prev != null) addSection(prev, section)
            label = l
            section = mutableListOf()
        }
        section.add(i)
    }
    val last = label
    if (last != null) addSection(last, section)
    return rows
}

@Composable
fun MediaList(
    media: List<GalleryMedia>,
    grouped: Boolean,
    selected: Set<Long>,
    selecting: Boolean,
    onTap: (Int) -> Unit,
    onLong: (GalleryMedia) -> Unit,
    modifier: Modifier = Modifier,
    state: LazyListState = rememberLazyListState(),
    bottomPadding: androidx.compose.ui.unit.Dp = 0.dp,
    header: (@Composable () -> Unit)? = null
) {
    BoxWithConstraints(modifier) {
        val w = maxWidth.value
        val rows = remember(media, w, grouped) { buildRows(media, w, grouped) }
        LazyColumn(Modifier.fillMaxWidth().fillMaxHeight(), state = state, contentPadding = PaddingValues(bottom = bottomPadding)) {
            if (header != null) item { header() }
            items(rows) { row ->
                when (row) {
                    is ListRow.Header -> Text(
                        row.label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(start = 14.dp, top = 14.dp, bottom = 6.dp)
                    )
                    is ListRow.Cells -> Row(
                        Modifier.fillMaxWidth().padding(bottom = GAP.dp).height(row.heightDp.dp),
                        horizontalArrangement = Arrangement.spacedBy(GAP.dp)
                    ) {
                        row.cells.forEach { (idx, aspect) ->
                            val m = media[idx]
                            val cellModifier = if (row.full) Modifier.weight(aspect).fillMaxHeight()
                            else Modifier.width((row.heightDp * aspect).dp).fillMaxHeight()
                            MediaCell(
                                m, m.id in selected, selecting,
                                onClick = { onTap(idx) }, onLong = { onLong(m) }, modifier = cellModifier
                            )
                        }
                    }
                }
            }
        }
    }
}
