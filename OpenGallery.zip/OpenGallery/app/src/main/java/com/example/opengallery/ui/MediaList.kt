package com.example.opengallery.ui

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.foundation.gestures.scrollBy
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.opengallery.data.GalleryMedia

sealed interface ListRow {
    data class Header(val label: String) : ListRow
    /** cells = (index into the media list, aspect ratio); full rows stretch to the screen width. */
    data class Cells(val cells: List<Pair<Int, Float>>, val heightDp: Float, val full: Boolean) : ListRow
}

private const val GAP = 2f

/**
 * grouped = false -> uniform 4-column squares (default album view).
 * grouped = true  -> date headers + justified rows that keep each picture's aspect ratio.
 */
fun buildRows(media: List<GalleryMedia>, widthDp: Float, grouped: Boolean): List<ListRow> {
    val rows = mutableListOf<ListRow>()
    if (!grouped) {
        val cols = (widthDp / 120f).toInt().coerceAtLeast(4)
        val h = (widthDp - GAP * (cols - 1)) / cols
        media.indices.chunked(cols).forEach { idx ->
            rows += ListRow.Cells(idx.map { it to 1f }, h, idx.size == cols)
        }
        return rows
    }
    val target = 120f
    fun addSection(label: String, idx: List<Int>) {
        rows += ListRow.Header(label)
        var cur = mutableListOf<Pair<Int, Float>>()
        var sum = 0f
        for (i in idx) {
            val m = media[i]
            val a = if (m.width > 0 && m.height > 0) (m.width.toFloat() / m.height).coerceIn(0.6f, 2f) else 1f
            cur.add(i to a)
            sum += a
            if (sum * target + GAP * (cur.size - 1) >= widthDp) {
                val h = (widthDp - GAP * (cur.size - 1)) / sum
                rows += ListRow.Cells(cur.toList(), h, true)
                cur = mutableListOf()
                sum = 0f
            }
        }
        if (cur.isNotEmpty()) rows += ListRow.Cells(cur.toList(), target, false)
    }
    var label: String? = null
    var section = mutableListOf<Int>()
    media.forEachIndexed { i, m ->
        val l = fmtDate(m.dateTaken)
        if (l != label) {
            val prev = label
            if (prev != null) addSection(prev, section)
            label = l
            section = mutableListOf()
        }
        section.add(i)
    }
    val last = label
    if (last != null) addSection(last, section)
    return rows
}

@Composable
fun MediaList(
    media: List<GalleryMedia>,
    grouped: Boolean,
    selected: Set<Long>,
    selecting: Boolean,
    onTap: (Int) -> Unit,
    onLong: (GalleryMedia) -> Unit,
    modifier: Modifier = Modifier,
    state: LazyListState = rememberLazyListState(),
    bottomPadding: androidx.compose.ui.unit.Dp = 0.dp,
    onDragSet: ((GalleryMedia, Boolean) -> Unit)? = null,
    header: (@Composable () -> Unit)? = null
) {
    val drag = remember { DragSel() }
    val mediaNow by rememberUpdatedState(media)
    val selectedNow by rememberUpdatedState(selected)
    val selectingNow by rememberUpdatedState(selecting)
    val setNow by rememberUpdatedState(onDragSet)
    BoxWithConstraints(modifier) {
        val w = maxWidth.value
        val rows = remember(media, w, grouped) { buildRows(media, w, grouped) }
        val rowsNow by rememberUpdatedState(rows)
        val hasHeader = header != null
        LazyColumn(
            Modifier.fillMaxWidth().fillMaxHeight().pointerInput(hasHeader) {
                dragSelectGestures(
                    state, hasHeader, { rowsNow }, { mediaNow }, { selectedNow }, { selectingNow }, { setNow }, drag
                )
            },
            state = state, contentPadding = PaddingValues(bottom = bottomPadding)
        ) {
            if (header != null) item { header() }
            items(rows) { row ->
                when (row) {
                    is ListRow.Header -> Text(
                        row.label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(start = 14.dp, top = 14.dp, bottom = 6.dp)
                    )
                    is ListRow.Cells -> Row(
                        Modifier.fillMaxWidth().padding(bottom = GAP.dp).height(row.heightDp.dp),
                        horizontalArrangement = Arrangement.spacedBy(GAP.dp)
                    ) {
                        row.cells.forEach { (idx, aspect) ->
                            val m = media[idx]
                            val cellModifier = if (row.full) Modifier.weight(aspect).fillMaxHeight()
                            else Modifier.width((row.heightDp * aspect).dp).fillMaxHeight()
                            MediaCell(
                                m, m.id in selected, selecting,
                                onClick = { onTap(idx) },
                                onLong = {
                                    if (onDragSet != null) {
                                        // arm "drag to select": the finger can now slide over other pictures
                                        drag.base = selected; drag.select = m.id !in selected
                                        drag.anchor = idx; drag.applied.clear(); drag.armed = true
                                        if (m.id in selected) onDragSet(m, false) else onLong(m)
                                    } else onLong(m)
                                },
                                modifier = cellModifier
                            )
                        }
                    }
                }
            }
        }
        // date of every list item (grouped lists only), for the date bubble and the year marks
        val lazyDates = remember(rows, media, hasHeader, grouped) {
            if (!grouped || rows.isEmpty()) null else {
                val d = LongArray(rows.size + (if (hasHeader) 1 else 0))
                var next = media.firstOrNull()?.dateTaken ?: 0L
                for (r in rows.indices.reversed()) {
                    val row = rows[r]
                    if (row is ListRow.Cells) next = media[row.cells.first().first].dateTaken
                    d[r + (if (hasHeader) 1 else 0)] = next
                }
                if (hasHeader) d[0] = d[1.coerceAtMost(d.size - 1)]
                d
            }
        }
        val yearMarks = remember(lazyDates) {
            val out = mutableListOf<Pair<Int, Int>>()
            if (lazyDates != null) {
                val cal = java.util.Calendar.getInstance()
                var last = -1
                lazyDates.forEachIndexed { i, ms ->
                    cal.timeInMillis = ms
                    val y = cal.get(java.util.Calendar.YEAR)
                    if (y != last) { out += i to y; last = y }
                }
            }
            out
        }
        FastScroller(state, topPad = 96.dp, bottomPad = maxOf(bottomPadding, 100.dp), lazyDates, yearMarks)
    }
}

/**
 * Samsung-style fast scroller: while the list moves, a thin track and a round handle appear on the right
 * edge (they fade out a moment after the list stops). Grab the handle and slide it to jump through the
 * whole list quickly.
 */
@Composable
private fun androidx.compose.foundation.layout.BoxScope.FastScroller(
    state: LazyListState, topPad: androidx.compose.ui.unit.Dp, bottomPad: androidx.compose.ui.unit.Dp,
    dates: LongArray?, yearMarks: List<Pair<Int, Int>>
) {
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var dragging by remember { androidx.compose.runtime.mutableStateOf(false) }
    var dragFrac by remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
    var recent by remember { androidx.compose.runtime.mutableStateOf(false) }
    var trackPx by remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
    val job = remember { arrayOfNulls<Job>(1) }
    val moving = state.isScrollInProgress
    androidx.compose.runtime.LaunchedEffect(moving, dragging) {
        if (moving || dragging) recent = true else { kotlinx.coroutines.delay(1400); recent = false }
    }
    val alpha by androidx.compose.animation.core.animateFloatAsState(
        if (recent || dragging) 1f else 0f,
        androidx.compose.animation.core.tween(if (recent || dragging) 120 else 350), label = "fastScroll"
    )
    val listFrac by androidx.compose.runtime.remember {
        androidx.compose.runtime.derivedStateOf {
            val info = state.layoutInfo
            val first = info.visibleItemsInfo.firstOrNull()
            if (first == null) 0f else {
                val span = (info.totalItemsCount - info.visibleItemsInfo.size).coerceAtLeast(1)
                ((state.firstVisibleItemIndex + state.firstVisibleItemScrollOffset / first.size.toFloat().coerceAtLeast(1f)) / span)
                    .coerceIn(0f, 1f)
            }
        }
    }
    if (alpha < 0.01f || state.layoutInfo.totalItemsCount < 2) return
    val handleDp = 64.dp
    val handlePx = with(androidx.compose.ui.platform.LocalDensity.current) { handleDp.toPx() }
    val range = (trackPx - handlePx).coerceAtLeast(1f)
    val frac = if (dragging) dragFrac else listFrac
    fun jump(f: Float) {
        job[0]?.cancel()
        job[0] = scope.launch {
            val info = state.layoutInfo
            val first = info.visibleItemsInfo.firstOrNull() ?: return@launch
            val span = (info.totalItemsCount - info.visibleItemsInfo.size).coerceAtLeast(1)
            val t = f * span
            val idx = t.toInt().coerceIn(0, info.totalItemsCount - 1)
            state.scrollToItem(idx, ((t - idx) * first.size).toInt().coerceAtLeast(0))
        }
    }
    Box(
        Modifier.align(Alignment.TopEnd).padding(top = topPad, bottom = bottomPad, end = 2.dp)
            .fillMaxHeight().width(40.dp)
            .androidx_onSize { trackPx = it }
            .graphicsLayer {
                this.alpha = alpha
                // fade each draw call instead of rendering into a box-sized buffer, which cut the date pill off at the left
                compositingStrategy = androidx.compose.ui.graphics.CompositingStrategy.ModulateAlpha
            }
    ) {
        Box(
            Modifier.align(Alignment.TopEnd)
                .offset { androidx.compose.ui.unit.IntOffset(0, (frac * range).toInt()) }
                .width(40.dp).height(handleDp)
                .draggable(
                    state = androidx.compose.foundation.gestures.rememberDraggableState { dy ->
                        dragFrac = (dragFrac + dy / range).coerceIn(0f, 1f)
                        jump(dragFrac)
                    },
                    orientation = androidx.compose.foundation.gestures.Orientation.Vertical,
                    onDragStarted = { dragFrac = listFrac; dragging = true },
                    onDragStopped = { dragging = false }
                )
        ) {
            // Samsung look: just a slim bar at the screen edge; grey while scrolling, a bit thicker and blue while dragged
            Box(
                Modifier.align(Alignment.CenterEnd).fillMaxHeight(0.8f)
                    .width(if (dragging) 5.dp else 3.dp)
                    .background(
                        if (dragging) Color(0xFF2F6BF0) else Color.White.copy(alpha = 0.5f),
                        androidx.compose.foundation.shape.RoundedCornerShape(50)
                    )
            )
        }
        if (dates != null) {
            val info = state.layoutInfo
            val span = (info.totalItemsCount - info.visibleItemsInfo.size).coerceAtLeast(1)
            val density = androidx.compose.ui.platform.LocalDensity.current
            // year marks along the track
            var lastY = -1000f
            if (dragging) yearMarks.forEach { (idx, year) ->
                val y = (idx.toFloat() / span).coerceIn(0f, 1f) * range
                if (y - lastY >= with(density) { 26.dp.toPx() }) {
                    lastY = y
                    Text(
                        year.toString(), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.align(Alignment.TopEnd)
                            .wrapContentWidth(Alignment.End, unbounded = true)
                            .offset { androidx.compose.ui.unit.IntOffset(-(18.dp.toPx()).toInt(), (y + handlePx / 2 - 10.dp.toPx()).toInt()) }
                            .background(Color(0xCC2C2C2E), androidx.compose.foundation.shape.RoundedCornerShape(50))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            // date bubble next to the handle (blue while you drag, grey while the list just scrolls)
            val cur = if (dragging) (dragFrac * span).toInt() else state.firstVisibleItemIndex
            val ms = dates.getOrNull(cur.coerceIn(0, dates.size - 1)) ?: 0L
            val label = remember(ms, dragging) {
                java.text.SimpleDateFormat(if (dragging) "MMM d, yyyy" else "MMM d", java.util.Locale.getDefault()).format(java.util.Date(ms))
            }
            Text(
                label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false,
                modifier = Modifier.align(Alignment.TopEnd)
                    .wrapContentWidth(Alignment.End, unbounded = true)
                    .offset { androidx.compose.ui.unit.IntOffset(-(16.dp.toPx()).toInt(), (frac * range + handlePx / 2 - 15.dp.toPx()).toInt()) }
                    .background(if (dragging) Color(0xFF2F6BF0) else Color(0xCC3A3A3C), androidx.compose.foundation.shape.RoundedCornerShape(50))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
    }
}

private fun Modifier.androidx_onSize(onSize: (Float) -> Unit): Modifier =
    this.onSizeChanged { onSize(it.height.toFloat()) }

/** State of one "drag over pictures to select / un-select them" gesture. */
class DragSel {
    var armed = false
    var anchor = -1
    var select = true
    var base: Set<Long> = emptySet()
    val applied = HashMap<Int, Boolean>()
}

/**
 * Samsung-style multi select: long-press a picture (or, while selecting, slide sideways over one) and keep
 * sliding across others. Everything between where you started and your finger gets selected, or un-selected
 * when you started on a selected picture. Slide back to undo. Holding near the top / bottom edge scrolls the list.
 */
private suspend fun PointerInputScope.dragSelectGestures(
    state: LazyListState,
    hasHeader: Boolean,
    getRows: () -> List<ListRow>,
    getMedia: () -> List<GalleryMedia>,
    getSelected: () -> Set<Long>,
    isSelecting: () -> Boolean,
    getSet: () -> ((GalleryMedia, Boolean) -> Unit)?,
    drag: DragSel
) = coroutineScope {
    val scope = this
    val gap = GAP * density
    val edge = 110f * density

    fun cellAt(pos: Offset): Int? {
        val info = state.layoutInfo.visibleItemsInfo.firstOrNull { pos.y >= it.offset && pos.y < it.offset + it.size } ?: return null
        val ri = info.index - (if (hasHeader) 1 else 0)
        val row = getRows().getOrNull(ri) as? ListRow.Cells ?: return null
        val w = size.width.toFloat()
        var x = 0f
        val n = row.cells.size
        val sum = row.cells.sumOf { it.second.toDouble() }.toFloat()
        row.cells.forEach { (idx, aspect) ->
            val cw = if (row.full) (w - gap * (n - 1)) * aspect / sum else row.heightDp * density * aspect
            if (pos.x < x + cw + gap / 2f) return idx
            x += cw + gap
        }
        return row.cells.last().first
    }

    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        val downIdx = cellAt(down.position)
        var started = false
        var lastPos = down.position
        var total = Offset.Zero
        var scrollV = 0f
        var scroller: Job? = null
        var prevRange: IntRange = IntRange.EMPTY

        fun apply(pos: Offset) {
            val set = getSet() ?: return
            val media = getMedia()
            val idx = cellAt(pos) ?: return
            val range = minOf(drag.anchor, idx)..maxOf(drag.anchor, idx)
            val touched = if (prevRange.isEmpty()) range
            else minOf(range.first, prevRange.first)..maxOf(range.last, prevRange.last)
            for (i in touched) {
                val m = media.getOrNull(i) ?: continue
                val want = if (i in range) drag.select else (m.id in drag.base)
                val have = drag.applied[i] ?: (m.id in drag.base)
                if (want != have) { set(m, want); drag.applied[i] = want }
            }
            prevRange = range
        }

        fun begin(anchor: Int, select: Boolean, armedAlready: Boolean) {
            started = true
            if (!armedAlready) {
                drag.base = getSelected(); drag.select = select; drag.anchor = anchor; drag.applied.clear()
                getMedia().getOrNull(anchor)?.let { getSet()?.invoke(it, select) }
            }
            drag.applied[drag.anchor] = drag.select
            prevRange = drag.anchor..drag.anchor
            scroller = scope.launch {
                while (isActive) {
                    if (scrollV != 0f) { state.scrollBy(scrollV); apply(lastPos) }
                    androidx.compose.runtime.withFrameNanos { }
                }
            }
        }

        while (true) {
            val ev = awaitPointerEvent(PointerEventPass.Initial)
            val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
            if (!ch.pressed) break
            lastPos = ch.position
            if (!started) {
                if (drag.armed) begin(drag.anchor, drag.select, true)
                else if (isSelecting() && downIdx != null && getSet() != null) {
                    total += ch.positionChange()
                    val ax = kotlin.math.abs(total.x); val ay = kotlin.math.abs(total.y)
                    if (ax > viewConfiguration.touchSlop && ax > ay * 1.5f) {
                        val m = getMedia().getOrNull(downIdx)
                        begin(downIdx, m != null && m.id !in getSelected(), false)
                    } else if (ay > viewConfiguration.touchSlop) break   // up/down: just scroll
                }
            }
            if (started) {
                ch.consume()
                scrollV = when {
                    lastPos.y < edge -> -((edge - lastPos.y) / edge).coerceIn(0f, 1f) * 26f
                    lastPos.y > size.height - edge -> ((lastPos.y - (size.height - edge)) / edge).coerceIn(0f, 1f) * 26f
                    else -> 0f
                }
                apply(lastPos)
            }
        }
        scroller?.cancel()
        drag.armed = false
    }
}
