@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.opengallery.ui

import android.app.Activity
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.GalleryMedia
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Real file operations through MediaStore.
 *  - trash: moves to the system trash (restorable ~30 days), after Android's own confirmation dialog
 *  - move:  changes the folder on disk (Android asks for write access first)
 *  - copy:  writes a duplicate into the target folder
 * A target containing '/' is an existing folder path (e.g. "DCIM/Camera/"); anything else is a new folder name.
 */
class FileActions(
    private val ctx: Context,
    private val scope: CoroutineScope,
    private val onChanged: () -> Unit,
    private val request: (PendingIntent, (Boolean) -> Unit) -> Unit
) {
    private fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    private fun targetPath(m: GalleryMedia, target: String): String =
        if ('/' in target) target else (if (m.isVideo) "Movies/" else "Pictures/") + target + "/"

    fun trash(items: List<GalleryMedia>, onDone: () -> Unit = {}) {
        if (items.isEmpty()) return
        val pi = MediaStore.createTrashRequest(ctx.contentResolver, items.map { it.uri }, true)
        request(pi) { ok ->
            if (ok) { toast("Moved ${items.size} item(s) to trash"); onChanged(); onDone() }
        }
    }

    fun move(items: List<GalleryMedia>, target: String, onDone: () -> Unit = {}) {
        if (items.isEmpty()) return
        val pi = MediaStore.createWriteRequest(ctx.contentResolver, items.map { it.uri })
        request(pi) { ok ->
            if (ok) scope.launch {
                val n = withContext(Dispatchers.IO) {
                    items.count { m ->
                        runCatching {
                            val v = ContentValues().apply {
                                put(MediaStore.MediaColumns.RELATIVE_PATH, targetPath(m, target))
                            }
                            ctx.contentResolver.update(m.uri, v, null, null) > 0
                        }.getOrDefault(false)
                    }
                }
                toast("Moved $n of ${items.size}")
                onChanged(); onDone()
            }
        }
    }

    fun copy(items: List<GalleryMedia>, target: String, onDone: () -> Unit = {}) {
        scope.launch {
            val n = withContext(Dispatchers.IO) {
                items.count { m ->
                    runCatching {
                        val res = ctx.contentResolver
                        val v = ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, m.name)
                            put(MediaStore.MediaColumns.MIME_TYPE, res.getType(m.uri) ?: if (m.isVideo) "video/mp4" else "image/jpeg")
                            put(MediaStore.MediaColumns.RELATIVE_PATH, targetPath(m, target))
                            put(MediaStore.MediaColumns.IS_PENDING, 1)
                        }
                        val base = if (m.isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                        val dst = res.insert(base, v)!!
                        res.openInputStream(m.uri)!!.use { i -> res.openOutputStream(dst)!!.use { o -> i.copyTo(o) } }
                        v.clear(); v.put(MediaStore.MediaColumns.IS_PENDING, 0)
                        res.update(dst, v, null, null)
                        true
                    }.getOrDefault(false)
                }
            }
            toast("Copied $n of ${items.size}")
            onChanged(); onDone()
        }
    }
}

@Composable
fun rememberFileActions(onChanged: () -> Unit): FileActions {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pending by remember { mutableStateOf<((Boolean) -> Unit)?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        val cb = pending
        pending = null
        cb?.invoke(r.resultCode == Activity.RESULT_OK)
    }
    return remember {
        FileActions(ctx, scope, onChanged) { pi, cb ->
            pending = cb
            launcher.launch(IntentSenderRequest.Builder(pi).build())
        }
    }
}

/** Trash button + "more" menu (move / copy to folder) for the current selection. */
@Composable
fun SelectionActions(vm: GalleryViewModel, actions: FileActions, items: List<GalleryMedia>, onDone: () -> Unit) {
    var more by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf<String?>(null) }
    IconButton(onClick = { actions.trash(items, onDone) }) { Icon(Icons.Default.Delete, "Move to trash") }
    Box {
        IconButton(onClick = { more = true }) { Icon(Icons.Default.MoreVert, "More") }
        DropdownMenu(expanded = more, onDismissRequest = { more = false }) {
            DropdownMenuItem(text = { Text("Move to folder…") }, onClick = { mode = "move"; more = false })
            DropdownMenuItem(text = { Text("Copy to folder…") }, onClick = { mode = "copy"; more = false })
        }
    }
    mode?.let { md ->
        FolderPickerDialog(vm, if (md == "move") "Move to folder" else "Copy to folder", onDismiss = { mode = null }) { target ->
            if (md == "move") actions.move(items, target, onDone) else actions.copy(items, target, onDone)
            mode = null
        }
    }
}

@Composable
fun FolderPickerDialog(vm: GalleryViewModel, title: String, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val media by vm.media.collectAsState()
    val folders = remember(media) { media.map { it.relativePath }.filter { it.isNotBlank() }.distinct().sorted() }
    var newName by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                LazyColumn(Modifier.heightIn(max = 240.dp)) {
                    items(folders, key = { it }) { p ->
                        ListItem(
                            headlineContent = { Text(p.trimEnd('/')) },
                            leadingContent = { Icon(Icons.Default.Folder, null) },
                            modifier = Modifier.clickable { onPick(p) }
                        )
                    }
                }
                OutlinedTextField(newName, { newName = it }, singleLine = true, label = { Text("Or new folder name") })
            }
        },
        confirmButton = {
            TextButton(enabled = newName.isNotBlank(), onClick = { onPick(newName.trim().replace('/', '_')) }) { Text("Use new folder") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
