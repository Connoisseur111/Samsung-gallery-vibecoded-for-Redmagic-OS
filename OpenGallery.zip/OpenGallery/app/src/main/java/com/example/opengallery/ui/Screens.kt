@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.example.opengallery.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.AlbumEntity
import com.example.opengallery.data.GalleryMedia
import com.example.opengallery.data.sortedBySetting

private data class Folder(val id: Long, val name: String, val items: List<GalleryMedia>)

@Composable
fun HomeScreen(vm: GalleryViewModel, nav: NavController) {
    var tab by remember { mutableIntStateOf(0) }
    val sort by vm.sort.collectAsState()
    Scaffold(topBar = {
        Column {
            TopAppBar(title = { Text("Gallery") }, actions = { SortMenu(sort, vm::setSort) })
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Folders") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Albums") })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad)) { if (tab == 0) FoldersTab(vm, nav) else AlbumContent(vm, nav, 0L) }
    }
}

@Composable
private fun FoldersTab(vm: GalleryViewModel, nav: NavController) {
    val media by vm.media.collectAsState()
    val sort by vm.sort.collectAsState()
    val folders = remember(media, sort) {
        media.groupBy { it.bucketId }.map { (id, l) -> Folder(id, l.first().bucketName, l) }
            .sortedBySetting(sort, { it.name }, { f -> f.items.maxOf { it.dateTaken } }, { f -> f.items.sumOf { it.size } })
    }
    LazyVerticalGrid(GridCells.Adaptive(150.dp), contentPadding = PaddingValues(4.dp), modifier = Modifier.fillMaxSize()) {
        items(folders, key = { it.id }) { f ->
            val cover = f.items.maxBy { it.dateTaken }
            Box(
                Modifier.padding(4.dp).aspectRatio(1f).clip(RoundedCornerShape(12.dp))
                    .clickable { nav.navigate("folder/${f.id}") }
            ) {
                MediaImage(cover, Modifier.fillMaxSize())
                Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().background(Color(0x99000000)).padding(8.dp)) {
                    Text(f.name, color = Color.White, maxLines = 1, style = MaterialTheme.typography.labelLarge)
                    Text("${f.items.size}", color = Color(0xCCFFFFFF), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
fun FolderScreen(vm: GalleryViewModel, nav: NavController, bucketId: Long) {
    val media by vm.media.collectAsState()
    val sort by vm.sort.collectAsState()
    val items = remember(media, sort, bucketId) {
        media.filter { it.bucketId == bucketId }.sortedBySetting(sort, { it.name }, { it.dateTaken }, { it.size })
    }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var picker by remember { mutableStateOf(false) }
    val actions = rememberFileActions(vm::refresh)
    BackHandler(selected.isNotEmpty()) { selected = emptySet() }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(items.firstOrNull()?.bucketName ?: "Folder") },
            navigationIcon = {
                IconButton(onClick = { if (selected.isNotEmpty()) selected = emptySet() else nav.popBackStack() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                }
            },
            actions = {
                if (selected.isNotEmpty()) {
                    Text("${selected.size}")
                    IconButton(onClick = { picker = true }) { Icon(Icons.Default.CreateNewFolder, "Add to album") }
                    SelectionActions(vm, actions, items.filter { it.id in selected }) { selected = emptySet() }
                } else SortMenu(sort, vm::setSort)
            }
        )
    }) { pad ->
        LazyVerticalGrid(GridCells.Adaptive(110.dp), contentPadding = PaddingValues(2.dp), modifier = Modifier.padding(pad).fillMaxSize()) {
            itemsIndexed(items, key = { _, m -> m.id }) { i, m ->
                Thumb(m, m.id in selected, selected.isNotEmpty(),
                    onClick = {
                        if (selected.isNotEmpty()) selected = if (m.id in selected) selected - m.id else selected + m.id
                        else { vm.viewerList = items; nav.navigate("viewer/$i") }
                    },
                    onLong = { selected = selected + m.id })
            }
        }
    }
    if (picker) AlbumPickerDialog(vm, "Add to album", allowRoot = false, onDismiss = { picker = false }) { id ->
        vm.addToAlbum(id, items.filter { it.id in selected }); selected = emptySet(); picker = false
    }
}

@Composable
fun AlbumScreen(vm: GalleryViewModel, nav: NavController, albumId: Long) {
    var name by remember { mutableStateOf("Album") }
    LaunchedEffect(albumId) { name = vm.albumName(albumId) }
    val sort by vm.sort.collectAsState()
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(name) },
            navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            actions = { SortMenu(sort, vm::setSort) }
        )
    }) { pad -> Box(Modifier.padding(pad)) { AlbumContent(vm, nav, albumId) } }
}

/** Shows sub-albums + photos/videos of one album (albumId 0 = top level). */
@Composable
fun AlbumContent(vm: GalleryViewModel, nav: NavController, albumId: Long) {
    val ctx = LocalContext.current
    val actions = rememberFileActions(vm::refresh)
    val sort by vm.sort.collectAsState()
    val media by vm.media.collectAsState()
    val subsRaw by remember(albumId) { vm.children(albumId) }.collectAsState(emptyList())
    val rows by remember(albumId) { vm.albumItems(albumId) }.collectAsState(emptyList())
    val subs = remember(subsRaw, sort) { subsRaw.sortedBySetting(sort, { it.name }, { it.createdAt }, { 0L }) }
    val ids = remember(rows) { rows.map { it.mediaId }.toSet() }
    val items = remember(media, ids, sort) {
        media.filter { it.id in ids }.sortedBySetting(sort, { it.name }, { it.dateTaken }, { it.size })
    }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var create by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf<AlbumEntity?>(null) }
    var rename by remember { mutableStateOf<AlbumEntity?>(null) }
    var move by remember { mutableStateOf<AlbumEntity?>(null) }
    var delete by remember { mutableStateOf<AlbumEntity?>(null) }
    BackHandler(selected.isNotEmpty()) { selected = emptySet() }

    Box(Modifier.fillMaxSize()) {
        Column {
            if (selected.isNotEmpty()) Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${selected.size}", Modifier.weight(1f))
                TextButton(onClick = { vm.removeFromAlbum(albumId, selected.toList()); selected = emptySet() }) { Text("Remove") }
                SelectionActions(vm, actions, items.filter { it.id in selected }) { selected = emptySet() }
                TextButton(onClick = { selected = emptySet() }) { Text("Cancel") }
            }
            if (subs.isEmpty() && items.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    if (albumId == 0L) "No albums yet. Tap + to create one."
                    else "Empty album. Tap + for a sub-album, or add photos from a folder (long-press to select).",
                    textAlign = TextAlign.Center, modifier = Modifier.padding(32.dp)
                )
            } else LazyVerticalGrid(GridCells.Adaptive(110.dp), contentPadding = PaddingValues(2.dp), modifier = Modifier.fillMaxSize()) {
                items(subs, key = { "a${it.id}" }) { a ->
                    AlbumTile(a.name, onClick = { nav.navigate("album/${a.id}") }, onLong = { menu = a })
                }
                itemsIndexed(items, key = { _, m -> "m${m.id}" }) { i, m ->
                    Thumb(m, m.id in selected, selected.isNotEmpty(),
                        onClick = {
                            if (selected.isNotEmpty()) selected = if (m.id in selected) selected - m.id else selected + m.id
                            else { vm.viewerList = items; nav.navigate("viewer/$i") }
                        },
                        onLong = { selected = selected + m.id })
                }
            }
        }
        FloatingActionButton(onClick = { create = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)) {
            Icon(Icons.Default.Add, "New album")
        }
    }

    if (create) NamePromptDialog(if (albumId == 0L) "New album" else "New sub-album", "", { create = false }) {
        vm.createAlbum(it, albumId); create = false
    }
    menu?.let { a ->
        AlertDialog(
            onDismissRequest = { menu = null },
            title = { Text(a.name) },
            text = {
                Column {
                    TextButton(onClick = { rename = a; menu = null }) { Text("Rename") }
                    TextButton(onClick = { move = a; menu = null }) { Text("Move into another album…") }
                    TextButton(onClick = { delete = a; menu = null }) { Text("Delete") }
                }
            },
            confirmButton = { TextButton(onClick = { menu = null }) { Text("Close") } }
        )
    }
    rename?.let { a -> NamePromptDialog("Rename album", a.name, { rename = null }) { vm.renameAlbum(a.id, it); rename = null } }
    move?.let { a ->
        AlbumPickerDialog(vm, "Move “${a.name}” to", allowRoot = true, hideId = a.id, onDismiss = { move = null }) { target ->
            vm.moveAlbum(a.id, target) { ok -> if (!ok) Toast.makeText(ctx, "Can't move an album into itself", Toast.LENGTH_SHORT).show() }
            move = null
        }
    }
    delete?.let { a ->
        AlertDialog(
            onDismissRequest = { delete = null },
            title = { Text("Delete “${a.name}”?") },
            text = { Text("This removes the album and its sub-albums. Your photos and videos are not deleted.") },
            confirmButton = { TextButton(onClick = { vm.deleteAlbum(a.id); delete = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { delete = null }) { Text("Cancel") } }
        )
    }
}
