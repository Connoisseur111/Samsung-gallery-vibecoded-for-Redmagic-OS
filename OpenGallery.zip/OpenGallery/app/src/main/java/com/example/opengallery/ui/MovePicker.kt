package com.example.opengallery.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.ui.focus.focusRequester
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.GalleryMedia
import com.example.opengallery.data.SortOption
import com.example.opengallery.data.sortedBySetting

/**
 * Samsung-style "Move to album" / "Copy to album": a full-screen album grid with "Create" on top,
 * a bottom pill showing "N items" + Cancel, then a "Moving items to X..." progress dialog.
 */
@Composable
fun AlbumMovePicker(
    vm: GalleryViewModel,
    actions: FileActions,
    mediaItems: List<GalleryMedia>,
    move: Boolean,
    onDismiss: () -> Unit,
    onDone: () -> Unit
) {
    val ctx = LocalContext.current
    val media by vm.media.collectAsState()
    val albums by vm.albums.collectAsState()
    val links by vm.links.collectAsState()
    val members by vm.members.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val model = remember(media, albums, links, members, favorites, FolderNames.map) { buildAlbums(media, albums, links, members, favorites) }
    var sortOpt by remember { mutableStateOf(SortOption.NAME_AZ) }
    var showSort by remember { mutableStateOf(false) }
    val gridState = rememberLazyGridState()
    // Re-ordering keeps the grid anchored on the same album (which may have moved far down): go back to the top instead.
    LaunchedEffect(sortOpt) {
        withFrameNanos { }
        gridState.scrollToItem(0)
    }
    val targets = remember(model, sortOpt) {
        model.byKey.values.filter { it.kind == Kind.FOLDER || it.kind == Kind.CUSTOM }
            .sortedBySetting(sortOpt, { it.title }, { it.latest }, { it.modified }, { it.size })
    }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val shownTargets = remember(targets, query) {
        val q = query.trim()
        if (q.isEmpty()) targets else targets.filter { it.title.contains(q, ignoreCase = true) }
    }
    val pathByBucket = remember(media) { media.groupBy { it.bucketId }.mapValues { e -> e.value.first().relativePath } }

    var creating by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<Triple<String, Int, Int>?>(null) }
    var cancelled by remember { mutableStateOf(false) }
    val verb = if (move) "Moving" else "Copying"

    fun startOp(label: String, target: String) {
        cancelled = false
        progress = Triple(label, 0, mediaItems.size)
        val onProg = { n: Int -> progress = Triple(label, n, mediaItems.size) }
        val fin = { progress = null; onDone(); onDismiss() }
        if (move) actions.move(mediaItems, target, fin, onProg) { cancelled }
        else actions.copy(mediaItems, target, fin, onProg) { cancelled }
    }

    Dialog(
        onDismissRequest = { if (progress == null) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
    ) {
        Box(Modifier.fillMaxSize().background(AppBg)) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().padding(top = 24.dp).padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { if (searching) { searching = false; query = "" } else onDismiss() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
                    }
                    if (searching) {
                        val focus = remember { androidx.compose.ui.focus.FocusRequester() }
                        LaunchedEffect(Unit) { focus.requestFocus() }
                        androidx.compose.foundation.text.BasicTextField(
                            value = query, onValueChange = { query = it }, singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 18.sp),
                            cursorBrush = androidx.compose.ui.graphics.SolidColor(Color.White),
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp).focusRequester(focus),
                            decorationBox = { inner ->
                                Box {
                                    if (query.isEmpty()) Text("Search albums", color = Color(0x99FFFFFF), fontSize = 18.sp)
                                    inner()
                                }
                            }
                        )
                        if (query.isNotEmpty()) IconButton(onClick = { query = "" }) {
                            Icon(Icons.Filled.Close, "Clear", tint = Color.White)
                        }
                    } else {
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { searching = true }) { Icon(Icons.Filled.Search, "Search", tint = Color.White) }
                    Text(
                        "Sort", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.clip(RoundedCornerShape(20.dp)).clickable { showSort = true }.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                    Text(
                        "Create", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.clip(RoundedCornerShape(20.dp)).clickable { creating = true }.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                    }
                }
                LazyVerticalGrid(
                    GridCells.Fixed(albumColumns()), Modifier.weight(1f).fillMaxWidth(), state = gridState,
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 190.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(shownTargets, key = { sortOpt.name + it.key }) { a ->
                        AlbumTile(a, selected = false, selecting = false, onClick = {
                            if (a.kind == Kind.CUSTOM) {
                                vm.addToAlbum(a.id, mediaItems); onDone(); onDismiss()
                            } else {
                                startOp(a.title, pathByBucket[a.id] ?: a.title)
                            }
                        })
                    }
                }
            }
            Row(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 72.dp, start = 16.dp, end = 16.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(36.dp)).background(Color(0xFF2B2B2B)).padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                mediaItems.firstOrNull()?.let { MediaImage(it, Modifier.size(38.dp).clip(RoundedCornerShape(10.dp))) }
                Spacer(Modifier.width(10.dp))
                Text(if (mediaItems.size == 1) "1 item" else "${mediaItems.size} items", color = Color.White, fontSize = 14.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onDismiss) { Text("Cancel", color = Color.White, fontSize = 16.sp) }
            }
        }
    }

    if (showSort) SortDialog(sortOpt, null, { showSort = false }) { o, _ -> sortOpt = o; showSort = false }

    if (creating) NameDialog(
        "Create album", "Album", "Create", { creating = false }
    ) { name ->
        creating = false
        val clean = name.trim().replace('/', '_')
        if (clean.isNotEmpty()) startOp(clean, clean)
    }

    progress?.let { (label, done, total) ->
        val frac = if (total == 0) 1f else done.toFloat() / total
        AlertDialog(
            onDismissRequest = {}, containerColor = CardBg, shape = RoundedCornerShape(28.dp),
            title = { Text("$verb items to $label...", fontSize = 17.sp) },
            text = {
                Column {
                    LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth())
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("$done/$total", fontSize = 13.sp, color = Color(0xCCFFFFFF))
                        Text("${(frac * 100).toInt()}%", fontSize = 13.sp, color = Color(0xCCFFFFFF))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    cancelled = true
                    Toast.makeText(ctx, "Cancelled", Toast.LENGTH_SHORT).show()
                }) { Text("Cancel") }
            }
        )
    }
}
