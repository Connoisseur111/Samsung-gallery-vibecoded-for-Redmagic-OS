package com.example.opengallery.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.ui.focus.focusRequester
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.GalleryMedia
import com.example.opengallery.data.SortOption
import com.example.opengallery.data.sortedBySetting

/**
 * Samsung-style "Move to album" / "Copy to album": a full-screen album grid with "Create" on top,
 * a bottom pill showing "N items" + Cancel, then a "Moving items to X..." progress dialog.
 */
@Composable
fun AlbumMovePicker(
    vm: GalleryViewModel,
    actions: FileActions,
    mediaItems: List<GalleryMedia>,
    move: Boolean,
    onDismiss: () -> Unit,
    onDone: () -> Unit
) {
    val ctx = LocalContext.current
    val media by vm.media.collectAsState()
    val albums by vm.albums.collectAsState()
    val links by vm.links.collectAsState()
    val members by vm.members.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val model = remember(media, albums, links, members, favorites, FolderNames.map, CoverStore.map) { buildAlbums(media, albums, links, members, favorites) }
    var sortOpt by remember { mutableStateOf(SortOption.NAME_AZ) }
    var showSort by remember { mutableStateOf(false) }
    val gridState = rememberLazyGridState()
    // Re-ordering keeps the grid anchored on the same album (which may have moved far down): go back to the top instead.
    LaunchedEffect(sortOpt) {
        withFrameNanos { }
        gridState.scrollToItem(0)
    }
    // Merged albums stay merged here too (like the Albums tab): a group is ONE tile, and tapping it shows its albums.
    var openGroup by remember { mutableStateOf<String?>(null) }
    // Like the Albums tab: start with the essential albums, "View all" shows everything.
    val essential by vm.essential.collectAsState()
    val essentialOn by vm.essentialEnabled.collectAsState()
    val hidden by vm.hidden.collectAsState()
    val order by vm.albumOrder.collectAsState()
    var viewAll by remember { mutableStateOf(false) }
    val essentialMode = essentialOn && !viewAll && openGroup == null
    val essSet = remember(model, hidden, order, essential) {
        essential ?: run {
            val vis = model.topLevel.filter { it.key !in hidden }
            val idx = order.withIndex().associate { it.value to it.index }
            (if (order.isEmpty()) vis else vis.sortedBy { idx[it.key] ?: Int.MAX_VALUE }).take(9).map { it.key }.toSet()
        }
    }
    val targets = remember(model, sortOpt, openGroup, members, essentialMode, essSet) {
        val list = if (openGroup == null) {
            model.topLevel.filter { it.kind == Kind.FOLDER || it.kind == Kind.CUSTOM || it.kind == Kind.GROUP }
                .filter { !essentialMode || it.key in essSet }
        } else {
            val gid = openGroup!!.removePrefix("group:").toLongOrNull()
            members.filter { it.groupId == gid }.mapNotNull { model.byKey[it.albumKey] }
                .filter { it.kind == Kind.FOLDER || it.kind == Kind.CUSTOM }
        }
        list.sortedBySetting(sortOpt, { it.title }, { it.latest }, { it.modified }, { it.size })
    }
    LaunchedEffect(openGroup) { withFrameNanos { }; gridState.scrollToItem(0) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val shownTargets = remember(targets, query, model, sortOpt) {
        val q = query.trim()
        // searching looks through every album, also the ones inside a group
        if (q.isEmpty()) targets
        else model.byKey.values.filter { (it.kind == Kind.FOLDER || it.kind == Kind.CUSTOM) && it.title.contains(q, ignoreCase = true) }
            .sortedBySetting(sortOpt, { it.title }, { it.latest }, { it.modified }, { it.size })
    }
    val pathByBucket = remember(media) { media.groupBy { it.bucketId }.mapValues { e -> e.value.first().relativePath } }

    var creating by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<Triple<String, Int, Int>?>(null) }
    var cancelled by remember { mutableStateOf(false) }
    var progFrac by remember { mutableStateOf(0f) }
    val verb = if (move) "Moving" else "Copying"

    fun startOp(label: String, target: String) {
        cancelled = false
        progress = Triple(label, 0, mediaItems.size)
        progFrac = 0f
        val onProg = { f: Float ->
            progress = Triple(label, f.toInt().coerceAtMost(mediaItems.size), mediaItems.size)
            progFrac = (f / mediaItems.size.coerceAtLeast(1)).coerceIn(0f, 1f)
        }
        val fin = { progress = null; if (move) vm.unlinkEverywhere(mediaItems.map { it.id }); onDone(); onDismiss() }
        if (move) actions.move(mediaItems, target, fin, onProg) { cancelled }
        else actions.copy(mediaItems, target, fin, onProg) { cancelled }
    }

    Dialog(
        onDismissRequest = { if (openGroup != null) openGroup = null else if (viewAll && essentialOn) viewAll = false else if (progress == null) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
    ) {
        Box(Modifier.fillMaxSize().background(AppBg)) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().padding(top = 24.dp).padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { if (searching) { searching = false; query = "" } else if (openGroup != null) openGroup = null else if (viewAll && essentialOn) viewAll = false else onDismiss() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
                    }
                    if (searching) {
                        val focus = remember { androidx.compose.ui.focus.FocusRequester() }
                        LaunchedEffect(Unit) { focus.requestFocus() }
                        androidx.compose.foundation.text.BasicTextField(
                            value = query, onValueChange = { query = it }, singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 18.sp),
                            cursorBrush = androidx.compose.ui.graphics.SolidColor(Color.White),
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp).focusRequester(focus),
                            decorationBox = { inner ->
                                Box {
                                    if (query.isEmpty()) Text("Search albums", color = Color(0x99FFFFFF), fontSize = 18.sp)
                                    inner()
                                }
                            }
                        )
                        if (query.isNotEmpty()) IconButton(onClick = { query = "" }) {
                            Icon(Icons.Filled.Close, "Clear", tint = Color.White)
                        }
                    } else {
                    val gname = openGroup?.let { model.byKey[it]?.title }
                    if (gname != null) Text(gname, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp))
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { searching = true }) { Icon(Icons.Filled.Search, "Search", tint = Color.White) }
                    Text(
                        "Sort", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.clip(RoundedCornerShape(20.dp)).clickable { showSort = true }.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                    Text(
                        "Create", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.clip(RoundedCornerShape(20.dp)).clickable { creating = true }.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                    }
                }
                LazyVerticalGrid(
                    GridCells.Fixed(albumColumns()), Modifier.weight(1f).fillMaxWidth(), state = gridState,
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 190.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (essentialMode && query.isBlank()) item(span = { GridItemSpan(maxLineSpan) }) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Essential albums", Modifier.weight(1f), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            Text("View all", color = Accent, fontSize = 15.sp, modifier = Modifier.clickable { viewAll = true })
                        }
                    }
                    items(shownTargets, key = { sortOpt.name + it.key }) { a ->
                        AlbumTile(a, selected = false, selecting = false, onClick = {
                            if (a.kind == Kind.GROUP) {
                                openGroup = a.key
                            } else if (a.kind == Kind.CUSTOM) {
                                startOp(a.title, a.title)
                            } else {
                                startOp(a.title, pathByBucket[a.id] ?: a.title)
                            }
                        })
                    }
                }
            }
            Row(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 72.dp, start = 16.dp, end = 16.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(36.dp)).background(Color(0xFF2B2B2B)).padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                mediaItems.firstOrNull()?.let { MediaImage(it, Modifier.size(38.dp).clip(RoundedCornerShape(10.dp))) }
                Spacer(Modifier.width(10.dp))
                Text(if (mediaItems.size == 1) "1 item" else "${mediaItems.size} items", color = Color.White, fontSize = 14.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onDismiss) { Text("Cancel", color = Color.White, fontSize = 16.sp) }
            }
        }
    }

    if (showSort) SortDialog(sortOpt, null, { showSort = false }) { o, _ -> sortOpt = o; showSort = false }

    if (creating) NameDialog(
        "Create album", "Album", "Create", { creating = false }
    ) { name ->
        creating = false
        val clean = name.trim().replace('/', '_')
        val gid = openGroup?.removePrefix("group:")?.toLongOrNull()
        if (clean.isNotEmpty()) {
            if (gid != null) {
                // created inside a merged group: make it a member of that group
                vm.createAlbum(clean) { id -> vm.addMembers(gid, setOf("album:$id")); startOp(clean, clean) }
            } else startOp(clean, clean)
        }
    }

    progress?.let { (label, done, total) ->
        TransferProgressDialog(
            title = "$verb items to $label...", done = done, total = total, fraction = progFrac,
            onCancel = {
                cancelled = true
                Toast.makeText(ctx, "Cancelled", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

/** Samsung-style transfer progress: a card near the bottom with a thin bar, "13/199", "6%" and Cancel. */
@Composable
fun TransferProgressDialog(title: String, done: Int, total: Int, fraction: Float, onCancel: () -> Unit) {
    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false, usePlatformDefaultWidth = false)
    ) {
        val view = androidx.compose.ui.platform.LocalView.current
        androidx.compose.runtime.SideEffect {
            val w = (view.parent as? androidx.compose.ui.window.DialogWindowProvider)?.window
            w?.setGravity(android.view.Gravity.BOTTOM)
        }
        val bars = activityBarInsets()
        val anim by androidx.compose.animation.core.animateFloatAsState(fraction, androidx.compose.animation.core.tween(120), label = "xfer")
        Column(
            Modifier.padding(start = 16.dp, end = 16.dp, bottom = bars.bottom + 24.dp).fillMaxWidth()
                .clip(RoundedCornerShape(28.dp)).background(Color(0xFF2B2B2B)).padding(horizontal = 24.dp, vertical = 20.dp)
        ) {
            Text(title, color = Color.White, fontSize = 17.sp)
            Spacer(Modifier.height(18.dp))
            LinearProgressIndicator(
                progress = { anim }, modifier = Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp)),
                color = Color(0xFF4C9BFF), trackColor = Color(0xFF555555)
            )
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("$done/$total", fontSize = 13.sp, color = Color(0xCCFFFFFF))
                Text("${(anim * 100).toInt()}%", fontSize = 13.sp, color = Color(0xCCFFFFFF))
            }
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).clickable { onCancel() }.padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) { Text("Cancel", color = Color.White, fontSize = 16.sp) }
        }
    }
}
