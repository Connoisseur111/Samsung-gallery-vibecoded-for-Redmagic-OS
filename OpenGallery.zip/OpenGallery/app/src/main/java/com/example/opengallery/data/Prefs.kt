package com.example.opengallery.data

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("gallery_prefs", Context.MODE_PRIVATE)
    fun getSet(key: String): Set<String>? = sp.getStringSet(key, null)?.toSet()
    fun putSet(key: String, value: Set<String>) { sp.edit().putStringSet(key, value.toSet()).apply() }
    fun getBool(key: String, def: Boolean): Boolean = sp.getBoolean(key, def)
    fun putBool(key: String, value: Boolean) { sp.edit().putBoolean(key, value).apply() }
}
