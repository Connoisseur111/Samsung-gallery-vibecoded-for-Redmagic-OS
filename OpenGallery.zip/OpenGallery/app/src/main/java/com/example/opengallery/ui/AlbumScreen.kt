package com.example.opengallery.ui

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.SortOption
import com.example.opengallery.data.sortedByOption

/** One album: device folder, your own album, Favorites, Videos or Recent. */
@Composable
fun AlbumScreen(vm: GalleryViewModel, nav: NavController, key: String) {
    val media by vm.media.collectAsState()
    val albums by vm.albums.collectAsState()
    val links by vm.links.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val hidden by vm.hidden.collectAsState()
    val globalSort by vm.sort.collectAsState()
    val perSort by vm.albumSorts.collectAsState()
    val askScope by vm.askSortScope.collectAsState()
    val sort = perSort[key] ?: globalSort
    var pendingSort by remember { mutableStateOf<SortOption?>(null) }
    val grouped by vm.groupByDate.collectAsState()
    val actions = rememberFileActions(vm::refresh)

    val base = remember(key, media, links, favorites) { mediaForKey(key, media, links, favorites) }
    val items = remember(base, sort) { base.sortedByOption(sort) }
    val title = remember(key, albums, base, FolderNames.map) { titleForKey(key, albums, base) }
    val images = items.count { !it.isVideo }
    val videos = items.size - images
    val subtitle = buildString {
        if (images > 0) append("$images images")
        if (videos > 0) { if (isNotEmpty()) append(" "); append("$videos videos") }
        if (isEmpty()) append("No items")
    }
    val customId: Long? = if (key.startsWith("album:")) key.removePrefix("album:").toLongOrNull() else null

    val openedAt = remember { android.os.SystemClock.uptimeMillis() }
    val sel = rememberSelection<Long>()
    val state = rememberLazyListState()
    // After changing the order (or grouping) always start from the top.
    // Only when the sort / grouping really changes (not when coming back to this screen).
    val firstSortRun = androidx.compose.runtime.remember { booleanArrayOf(true) }
    androidx.compose.runtime.LaunchedEffect(sort, grouped) {
        if (firstSortRun[0]) { firstSortRun[0] = false; return@LaunchedEffect }
        androidx.compose.runtime.withFrameNanos { }; state.scrollToItem(0)
    }
    var showSort by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var delete by remember { mutableStateOf(false) }
    BackHandler(sel.mode) { sel.clear() }

    Box(Modifier.fillMaxSize().background(AppBg)) {
        MediaList(
            media = items, grouped = grouped, selected = sel.ids, selecting = sel.mode,
            onTap = { i ->
                if (sel.mode) sel.toggle(items[i].id)
                // Ignore a second quick tap that lands while the album is still opening
                // (it used to open a random picture instead of showing the album).
                else if (android.os.SystemClock.uptimeMillis() - openedAt >= 500) { vm.viewerList = items; nav.navigate("viewer/$i/0") }
            },
            onLong = { m -> if (sel.mode) sel.toggle(m.id) else sel.start(m.id) },
            onDragSet = { m, on -> if (!sel.mode) sel.start(); sel.set(m.id, on) },
            modifier = Modifier.fillMaxSize(), state = state, bottomPadding = 120.dp,
            header = { AlbumHeader(title, subtitle, items.firstOrNull()) }
        )
        if (sel.mode) {
            val all = items.isNotEmpty() && sel.ids.size == items.size
            SelectionTop(
                sel.ids.size, all,
                onToggleAll = { sel.ids = if (all) emptySet() else items.map { it.id }.toSet() },
                onCancel = { sel.clear() }, modifier = Modifier.align(Alignment.TopCenter)
            )
            MediaSelectionBar(
                vm, actions, items.filter { it.id in sel.ids }, onDone = { sel.clear() },
                extra = { close ->
                    if (customId != null) MenuItem("Remove from album") {
                        close(); vm.removeFromAlbum(customId, sel.ids.toList()); sel.clear()
                    }
                }
            )
        } else {
            Row(
                Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                CircleButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", { nav.popBackStack() })
                PillActions(onSearch = { nav.navigate("search/" + Uri.encode(key)) }) { close ->
                    MenuItem("Select") { close(); sel.start() }
                    if (customId != null) MenuItem("Add items") { close(); nav.navigate("additems/$customId") }
                    MenuItem("Sort") { close(); showSort = true }
                    MenuItem("Start slideshow") {
                        close()
                        if (items.isNotEmpty()) { vm.viewerList = items; nav.navigate("viewer/0/1") }
                    }
                    if (customId != null || key.startsWith("folder:")) MenuItem("Rename") { close(); rename = true }
                    MenuItem("Album settings") { close(); showSettings = true }
                }
            }
        }
    }

    if (showSort) SortDialog(sort, grouped, onDismiss = { showSort = false }) { s, g ->
        vm.groupByDate.value = g; showSort = false
        if (s != sort) { if (askScope) pendingSort = s else vm.setAlbumSortFor(key, s) }
    }
    pendingSort?.let { s ->
        AlertDialog(
            onDismissRequest = { pendingSort = null }, containerColor = CardBg,
            title = { Text("Apply sort order") },
            text = { Text("Apply “${s.label}” to every album, or only to this one?") },
            confirmButton = { TextButton(onClick = { vm.setSortForAll(s); pendingSort = null }) { Text("All albums") } },
            dismissButton = { TextButton(onClick = { vm.setAlbumSortFor(key, s); pendingSort = null }) { Text("This album only") } }
        )
    }
    if (showSettings) AlertDialog(
        onDismissRequest = { showSettings = false }, containerColor = CardBg,
        title = { Text("Album settings") },
        text = {
            Column {
                if (customId != null) {
                    TextButton(onClick = { showSettings = false; rename = true }) { Text("Rename album") }
                    TextButton(onClick = { showSettings = false; delete = true }) { Text("Delete album") }
                } else if (key.startsWith("folder:")) {
                    TextButton(onClick = { showSettings = false; rename = true }) { Text("Rename album") }
                    TextButton(onClick = { showSettings = false; vm.setHidden(hidden + key); nav.popBackStack() }) { Text("Hide album") }
                } else {
                    Text("This is an automatic album.")
                }
            }
        },
        confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Close") } }
    )
    if (rename && (customId != null || key.startsWith("folder:"))) NameDialog("Rename album", title, "Rename", { rename = false }) { n ->
        if (customId != null) vm.renameAlbum(customId, n) else vm.renameFolder(key, n)
        rename = false
    }
    if (delete && customId != null) ConfirmDialog(
        "Delete album", "The pictures and videos in it are not deleted.", "Delete", { delete = false }
    ) { delete = false; vm.deleteAlbum(customId, false); nav.popBackStack() }
}

/** Pick pictures/videos to put into one of your albums. */
@Composable
fun AddItemsScreen(vm: GalleryViewModel, nav: NavController, albumId: Long) {
    val media by vm.media.collectAsState()
    val items = remember(media) { media.sortedByOption(SortOption.CREATED_DESC) }
    val sel = remember { Selection<Long>().apply { start() } }
    Box(Modifier.fillMaxSize().background(AppBg)) {
        MediaList(
            media = items, grouped = true, selected = sel.ids, selecting = true,
            onTap = { i -> sel.toggle(items[i].id) }, onLong = { m -> sel.toggle(m.id) },
            onDragSet = { m, on -> sel.set(m.id, on) },
            modifier = Modifier.fillMaxSize(), bottomPadding = 120.dp,
            header = { Spacer(Modifier.statusBarsPadding().height(72.dp)) }
        )
        Row(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircleButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", { nav.popBackStack() })
            Spacer(Modifier.width(12.dp))
            Text("Add items", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text("${sel.ids.size} selected", color = Color.White, fontSize = 14.sp)
        }
        ActionPill(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 16.dp)) {
            PillAction(Icons.Filled.Check, "Done", sel.ids.isNotEmpty()) {
                vm.addToAlbum(albumId, items.filter { it.id in sel.ids })
                nav.popBackStack()
            }
        }
    }
}
