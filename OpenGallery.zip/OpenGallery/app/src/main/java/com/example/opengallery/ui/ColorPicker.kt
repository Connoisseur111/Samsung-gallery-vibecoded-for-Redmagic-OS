package com.example.opengallery.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Dark colours only: all text in the app is white, so every choice here keeps it easy to read. */
private val swatches = listOf(
    0xFF000000, 0xFF15161A, 0xFF22252B, 0xFF26323F, 0xFF0A1530,
    0xFF14123A, 0xFF1E1B4B, 0xFF2A1245, 0xFF3A1236, 0xFF3B0F14,
    0xFF2E1D12, 0xFF2A2E12, 0xFF0F2A1A, 0xFF0B2F33, 0xFF0C2D48
).map { Color(it) }

/** Pick the colour of the whole app: a colour grid, or a custom colour with two sliders. */
@Composable
fun BackgroundColorDialog(current: Color, onPick: (Color) -> Unit, onDone: () -> Unit) {
    var hue by remember { mutableFloatStateOf(220f) }
    var shade by remember { mutableFloatStateOf(0.22f) }   // brightness, limited to dark colours
    val customColor = Color.hsv(hue, 0.70f, shade)
    AlertDialog(
        onDismissRequest = onDone, containerColor = CardBg,
        title = { Text("Background color", color = Color.White) },
        text = {
            Column {
                swatches.chunked(5).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding5(), horizontalArrangement = Arrangement.SpaceBetween) {
                        row.forEach { c ->
                            Box(
                                Modifier.size(46.dp).clip(CircleShape).background(c)
                                    .border(BorderStroke(if (c == current) 3.dp else 1.dp, if (c == current) Color.White else Color(0x55FFFFFF)), CircleShape)
                                    .clickable { onPick(c) },
                                contentAlignment = Alignment.Center
                            ) { if (c == current) Icon(Icons.Filled.Check, null, tint = Color.White) }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Custom color", color = Color.LightGray, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(36.dp).clip(CircleShape).background(customColor)
                            .border(1.dp, Color(0x88FFFFFF), CircleShape).clickable { onPick(customColor) }
                    )
                    Column(Modifier.padding(start = 12.dp)) {
                        Slider(hue, { hue = it; onPick(Color.hsv(hue, 0.70f, shade)) }, valueRange = 0f..360f)
                        Slider(shade, { shade = it; onPick(Color.hsv(hue, 0.70f, shade)) }, valueRange = 0.04f..0.40f)
                    }
                }
                Text("Top slider: color. Bottom slider: how light it is.", color = Color.Gray, fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton(onClick = onDone) { Text("Done") } },
        dismissButton = { TextButton(onClick = { onPick(Color.Black) }) { Text("Reset to black") } }
    )
}

private fun Modifier.padding5(): Modifier = this.then(Modifier.padding(vertical = 5.dp))
