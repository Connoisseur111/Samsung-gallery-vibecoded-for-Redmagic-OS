package com.example.opengallery.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PhotoAlbum
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.sortedByOption

@Composable
fun MainScreen(vm: GalleryViewModel, nav: NavController) {
    val pager = rememberPagerState(0) { 2 }
    val scope = rememberCoroutineScope()
    var menuOpen by remember { mutableStateOf(false) }
    var selPictures by remember { mutableStateOf(false) }
    var selAlbums by remember { mutableStateOf(false) }
    val selecting = selPictures || selAlbums
    Box(Modifier.fillMaxSize().background(AppBg)) {
        // Swipe finger right -> Pictures, swipe finger left -> Albums (the page follows your finger).
        HorizontalPager(
            pager, Modifier.fillMaxSize(), userScrollEnabled = !selecting, beyondViewportPageCount = 1
        ) { page ->
            if (page == 0) PicturesTab(vm, nav) { selPictures = it }
            else AlbumsContent(vm, nav, viewAll = false) { selAlbums = it }
        }
        if (!selecting) BottomNav(
            pager.currentPage, menuOpen,
            onTab = { t -> menuOpen = false; scope.launch { pager.animateScrollToPage(t) } },
            onMenu = { menuOpen = !menuOpen }
        )
        if (menuOpen) MenuPopup(nav) { menuOpen = false }
    }
}

@Composable
fun LargeTitleHeader(title: String, leading: (@Composable () -> Unit)? = null, actions: @Composable () -> Unit) {
    val land = androidx.compose.ui.platform.LocalConfiguration.current.orientation ==
        android.content.res.Configuration.ORIENTATION_LANDSCAPE
    Box(Modifier.fillMaxWidth().height(if (land) 96.dp else 200.dp).statusBarsPadding()) {
        Text(
            title, color = Color.White, fontSize = if (land) 26.sp else 34.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = if (land) 10.dp else 44.dp)
        )
        if (leading != null) Box(Modifier.align(Alignment.BottomStart).padding(start = 12.dp, bottom = 8.dp)) { leading() }
        Box(Modifier.align(Alignment.BottomEnd).padding(end = 12.dp, bottom = 8.dp)) { actions() }
    }
}

@Composable
fun PicturesTab(vm: GalleryViewModel, nav: NavController, onSelecting: (Boolean) -> Unit) {
    val media by vm.media.collectAsState()
    val sort by vm.sort.collectAsState()
    val items = remember(media, sort) { media.sortedByOption(sort) }
    val sel = rememberSelection<Long>()
    val actions = rememberFileActions(vm::refresh)
    val state = rememberLazyListState()
    var showSort by remember { mutableStateOf(false) }
    val collapsed by remember { derivedStateOf { state.firstVisibleItemIndex > 0 } }
    LaunchedEffect(sel.mode) { onSelecting(sel.mode) }
    BackHandler(sel.mode) { sel.clear() }

    val pill: @Composable (Modifier) -> Unit = { m ->
        PillActions(m, onSearch = { nav.navigate("search/all") }) { close ->
            MenuItem("Select") { close(); sel.start() }
            MenuItem("Sort") { close(); showSort = true }
        }
    }

    Box(Modifier.fillMaxSize()) {
        MediaList(
            media = items, grouped = true, selected = sel.ids, selecting = sel.mode,
            onTap = { i ->
                if (sel.mode) sel.toggle(items[i].id)
                else { vm.viewerList = items; nav.navigate("viewer/$i/0") }
            },
            onLong = { m -> if (sel.mode) sel.toggle(m.id) else sel.start(m.id) },
            onDragSet = { m, on -> if (!sel.mode) sel.start(); sel.set(m.id, on) },
            modifier = Modifier.fillMaxSize(), state = state, bottomPadding = 120.dp,
            header = { LargeTitleHeader("Pictures") { pill(Modifier) } }
        )
        if (sel.mode) {
            val all = items.isNotEmpty() && sel.ids.size == items.size
            SelectionTop(
                sel.ids.size, all,
                onToggleAll = { sel.ids = if (all) emptySet() else items.map { it.id }.toSet() },
                onCancel = { sel.clear() }, modifier = Modifier.align(Alignment.TopCenter)
            )
            MediaSelectionBar(vm, actions, items.filter { it.id in sel.ids }, onDone = { sel.clear() })
        } else if (collapsed) {
            pill(Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(8.dp))
        }
    }
    if (showSort) SortDialog(sort, null, onDismiss = { showSort = false }) { s, _ -> vm.setSortForAll(s); showSort = false }
}

@Composable
private fun BoxScope.BottomNav(tab: Int, menuOpen: Boolean, onTab: (Int) -> Unit, onMenu: () -> Unit) {
    Row(
        Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 14.dp)
            .clip(RoundedCornerShape(36.dp)).background(PillBg).padding(6.dp)
    ) {
        NavItem(Icons.Filled.PhotoLibrary, "Pictures", tab == 0 && !menuOpen) { onTab(0) }
        NavItem(Icons.Filled.PhotoAlbum, "Albums", tab == 1 && !menuOpen) { onTab(1) }
        NavItem(Icons.Filled.Menu, "Menu", menuOpen, onMenu)
    }
}

@Composable
private fun NavItem(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    // Lights up when tapped, then fades out quickly instead of staying lit.
    val flash = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    Column(
        Modifier.clip(RoundedCornerShape(30.dp))
            .background(Color.White.copy(alpha = 0.22f * flash.value))
            .clickable {
                scope.launch { flash.snapTo(1f); flash.animateTo(0f, tween(450)) }
                onClick()
            }.padding(horizontal = 22.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, Modifier.size(24.dp), tint = Color.White)
        Text(label, fontSize = 11.sp, color = Color.White)
    }
}

private class MenuEntry(val icon: ImageVector, val label: String, val go: () -> Unit)

@Composable
private fun MenuPopup(nav: NavController, onClose: () -> Unit) {
    val entries = listOf(
        MenuEntry(Icons.Filled.Videocam, "Videos") { nav.navigate(albumRoute("videos")) },
        MenuEntry(Icons.Filled.Favorite, "Favorites") { nav.navigate(albumRoute("favorites")) },
        MenuEntry(Icons.Filled.Schedule, "Recent") { nav.navigate(albumRoute("recent")) },
        MenuEntry(Icons.Filled.Delete, "Trash") { nav.navigate("trash") },
        MenuEntry(Icons.Filled.Settings, "Settings") { nav.navigate("settings") }
    )
    Box(
        Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose)
    ) {
        Column(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(start = 20.dp, end = 20.dp, bottom = 100.dp)
                .clip(RoundedCornerShape(28.dp)).background(CardBg)
                .pointerInput(Unit) { detectTapGestures { } }.padding(12.dp)
        ) {
            entries.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth()) {
                    row.forEach { e ->
                        Column(
                            Modifier.weight(1f).clickable { onClose(); e.go() }.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(Modifier.size(52.dp).clip(CircleShape).background(Color(0xFF3C3C3C)), contentAlignment = Alignment.Center) {
                                Icon(e.icon, e.label, tint = Color.White)
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(e.label, fontSize = 12.sp, color = Color.White)
                        }
                    }
                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}
