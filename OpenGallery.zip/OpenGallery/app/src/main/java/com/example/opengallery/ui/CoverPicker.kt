package com.example.opengallery.ui

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.opengallery.data.GalleryMedia
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.net.URLDecoder
import java.net.URLEncoder

/**
 * Custom album thumbnails ("like a wallpaper"). The chosen picture / video frame is COPIED into the app's
 * own storage, so the thumbnail stays the same even if the original file is deleted or moved, and it does
 * not follow the album's newest item. Removing the file here goes back to the automatic thumbnail.
 */
object CoverStore {
    /** album key -> saved thumbnail file */
    var map by mutableStateOf(emptyMap<String, File>())

    private fun dir(ctx: Context) = File(ctx.filesDir, "covers").apply { mkdirs() }

    fun init(ctx: Context) {
        val out = HashMap<String, File>()
        dir(ctx).listFiles()?.forEach { f ->
            val key = runCatching { URLDecoder.decode(f.name.substringBefore("__"), "UTF-8") }.getOrNull()
            if (key != null) out[key] = f
        }
        map = out
    }

    suspend fun set(ctx: Context, key: String, bmp: Bitmap) = withContext(Dispatchers.IO) {
        val enc = URLEncoder.encode(key, "UTF-8")
        dir(ctx).listFiles()?.filter { it.name.startsWith(enc + "__") }?.forEach { it.delete() }
        // a new name every time, so the picture cache never shows the old thumbnail
        val f = File(dir(ctx), enc + "__" + System.currentTimeMillis() + ".jpg")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        map = map + (key to f)
    }

    fun clear(ctx: Context, key: String) {
        val enc = URLEncoder.encode(key, "UTF-8")
        dir(ctx).listFiles()?.filter { it.name.startsWith(enc + "__") }?.forEach { it.delete() }
        map = map - key
    }
}

/** Still picture for a picture / GIF (a video goes through [VideoFramePickerDialog]). */
suspend fun coverBitmapOfImage(ctx: Context, m: GalleryMedia): Bitmap? = withContext(Dispatchers.IO) {
    runCatching { ctx.contentResolver.loadThumbnail(m.uri, android.util.Size(720, 720), null) }.getOrNull()
}

private fun frameAt(ctx: Context, m: GalleryMedia, ms: Long, size: Int): Bitmap? {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(ctx, m.uri)
        r.getScaledFrameAtTime(ms * 1000L, MediaMetadataRetriever.OPTION_CLOSEST, size, size)
    } catch (_: Exception) { null } finally { runCatching { r.release() } }
}

/** Choose any frame of a video with a slider; "Set" makes that frame the album thumbnail. */
@Composable
fun VideoFramePickerDialog(m: GalleryMedia, onDismiss: () -> Unit, onPick: (Bitmap) -> Unit) {
    val ctx = LocalContext.current
    val total = m.duration.coerceAtLeast(1L)
    var pos by remember { mutableFloatStateOf(0f) }
    var frame by remember { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(pos) {
        delay(60)   // while the slider is moving only the last position is decoded
        frame = withContext(Dispatchers.IO) { frameAt(ctx, m, pos.toLong(), 720) } ?: frame
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(AppBg).statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
            Text("Choose a frame for the thumbnail", color = Color.White, fontSize = 18.sp)
            Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 16.dp), contentAlignment = Alignment.Center) {
                frame?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
            }
            Slider(value = pos, onValueChange = { pos = it }, valueRange = 0f..total.toFloat())
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onDismiss) { Text("Cancel", color = Color.White) }
                TextButton(onClick = { frame?.let(onPick) }, enabled = frame != null) { Text("Set", color = Accent) }
            }
        }
    }
}
