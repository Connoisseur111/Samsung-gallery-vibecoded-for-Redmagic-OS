package com.example.opengallery.ui

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

fun fmtDuration(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

fun fmtClock(ms: Long): String {
    val s = ms / 1000
    return "%02d:%02d".format(s / 60, s % 60)
}

fun fmtClockMs(ms: Long): String {
    val s = ms / 1000
    return "%02d:%02d.%02d".format(s / 60, s % 60, (ms % 1000) / 10)
}

fun fmtSize(b: Long): String = when {
    b >= (1L shl 30) -> "%.2f GB".format(b / 1073741824.0)
    b >= (1L shl 20) -> "%.1f MB".format(b / 1048576.0)
    b >= 1024 -> "%.0f KB".format(b / 1024.0)
    else -> "$b B"
}

private val calendar: Calendar = Calendar.getInstance()
private val fmtRecent = SimpleDateFormat("MMM d", Locale.getDefault())
private val fmtOld = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
private val fmtFull = SimpleDateFormat("MMM d, yyyy  h:mm a", Locale.getDefault())
private val currentYear = Calendar.getInstance().get(Calendar.YEAR)

/** "Feb 6" for this year, "Aug 27, 2025" for older items (like Samsung Gallery). */
fun fmtDate(ms: Long): String {
    calendar.timeInMillis = ms
    val f = if (calendar.get(Calendar.YEAR) == currentYear) fmtRecent else fmtOld
    return f.format(Date(ms))
}

fun fmtDateFull(ms: Long): String = fmtFull.format(Date(ms))

fun albumRoute(key: String): String = "album/" + Uri.encode(key)

/** Multi-select state shared by every grid. */
class Selection<T> {
    var mode by mutableStateOf(false)
    var ids by mutableStateOf(setOf<T>())

    fun start(first: T? = null) {
        mode = true
        ids = if (first != null) setOf(first) else emptySet()
    }

    fun set(id: T, on: Boolean) { ids = if (on) ids + id else ids - id }

    fun toggle(id: T) { ids = if (id in ids) ids - id else ids + id }

    fun clear() { mode = false; ids = emptySet() }
}

@Composable
fun <T> rememberSelection(): Selection<T> = remember { Selection<T>() }
