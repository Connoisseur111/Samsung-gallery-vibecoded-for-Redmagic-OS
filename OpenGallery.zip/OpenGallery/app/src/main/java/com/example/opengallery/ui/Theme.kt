package com.example.opengallery.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

val Accent = Color(0xFF3E91FF)
val Yellow = Color(0xFFFFD84D)
val PillBg = Color(0xE61E1E1E)
val CardBg = Color(0xFF2B2B2B)
val OverlayBg = Color(0x66000000)

/** The app-wide background colour (Settings > Background color). Pure black by default. */
object AppTheme { var bg by mutableStateOf(Color.Black) }
val AppBg: Color get() = AppTheme.bg

@Composable
fun GalleryTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = AppTheme.bg,
            surface = AppTheme.bg,
            onSurface = Color.White,
            onBackground = Color.White,
            surfaceContainer = CardBg,
            secondaryContainer = Color(0xFF2E2E2E)
        ),
        typography = Typography(),
        content = content
    )
}
