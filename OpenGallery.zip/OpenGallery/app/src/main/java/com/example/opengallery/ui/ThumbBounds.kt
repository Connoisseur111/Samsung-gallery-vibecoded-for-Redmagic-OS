package com.example.opengallery.ui

import androidx.compose.ui.layout.boundsInWindow

/**
 * Live on-screen grid tiles (media id -> layout coordinates), used by the viewer's Samsung-style zoom.
 * Deliberately stores NO rectangles: the position is read from the live tile at the moment it is needed, and only
 * when that tile is still attached (on screen). A tile that scrolled away / was disposed gives null -> the viewer
 * then uses its plain fade instead of the zoom.
 */
object ThumbBounds {
    private val live = HashMap<Long, androidx.compose.ui.layout.LayoutCoordinates>()

    fun register(id: Long, c: androidx.compose.ui.layout.LayoutCoordinates) { live[id] = c }

    /** Only removes the entry if it still belongs to [c] (another screen may have registered the same id since). */
    fun unregister(id: Long, c: androidx.compose.ui.layout.LayoutCoordinates?) {
        if (c != null && live[id] === c) live.remove(id)
    }

    fun rectNow(id: Long): androidx.compose.ui.geometry.Rect? {
        val c = live[id] ?: return null
        if (!c.isAttached) return null
        val r = runCatching { c.boundsInWindow() }.getOrNull() ?: return null
        if (r.width < 8f || r.height < 8f) return null
        return r
    }
}
