@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.opengallery.ui

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.RotateLeft
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.opengallery.GalleryViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class Look(val label: String) { ORIGINAL("Original"), BW("B&W"), SEPIA("Sepia"), VIVID("Vivid"), WARM("Warm"), COOL("Cool") }

private fun lookMatrix(l: Look): ColorMatrix? = when (l) {
    Look.ORIGINAL -> null
    Look.BW -> ColorMatrix().apply { setSaturation(0f) }
    Look.VIVID -> ColorMatrix().apply { setSaturation(1.5f) }
    Look.SEPIA -> ColorMatrix(floatArrayOf(
        0.393f, 0.769f, 0.189f, 0f, 0f,
        0.349f, 0.686f, 0.168f, 0f, 0f,
        0.272f, 0.534f, 0.131f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f))
    Look.WARM -> ColorMatrix(floatArrayOf(
        1.1f, 0f, 0f, 0f, 0f,
        0f, 1f, 0f, 0f, 0f,
        0f, 0f, 0.9f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f))
    Look.COOL -> ColorMatrix(floatArrayOf(
        0.9f, 0f, 0f, 0f, 0f,
        0f, 1f, 0f, 0f, 0f,
        0f, 0f, 1.1f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f))
}

private data class Adjust(val look: Look, val brightness: Float, val contrast: Float, val saturation: Float) {
    fun matrix(): ColorMatrix? {
        if (look == Look.ORIGINAL && brightness == 0f && contrast == 1f && saturation == 1f) return null
        val m = ColorMatrix().apply { setSaturation(saturation) }
        val t = (-0.5f * contrast + 0.5f) * 255f + brightness * 255f
        m.postConcat(ColorMatrix(floatArrayOf(
            contrast, 0f, 0f, 0f, t,
            0f, contrast, 0f, 0f, t,
            0f, 0f, contrast, 0f, t,
            0f, 0f, 0f, 1f, 0f)))
        lookMatrix(look)?.let { m.postConcat(it) }
        return m
    }
}

/** flip -> rotate -> crop (fractions of the rotated image) -> color filter. */
private fun render(
    src: Bitmap, rotation: Int, flip: Boolean,
    l: Float, r: Float, t: Float, b: Float, filter: ColorMatrix?
): Bitmap {
    val mtx = Matrix().apply {
        if (flip) postScale(-1f, 1f, src.width / 2f, src.height / 2f)
        postRotate(rotation.toFloat())
    }
    val rotated = Bitmap.createBitmap(src, 0, 0, src.width, src.height, mtx, true)
    val x = (rotated.width * l).toInt()
    val y = (rotated.height * t).toInt()
    val w = (rotated.width * (1f - l - r)).toInt().coerceAtLeast(1).coerceAtMost(rotated.width - x)
    val h = (rotated.height * (1f - t - b)).toInt().coerceAtLeast(1).coerceAtMost(rotated.height - y)
    val cropped = Bitmap.createBitmap(rotated, x, y, w, h)
    if (filter == null) return cropped
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    Canvas(out).drawBitmap(cropped, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(filter) })
    return out
}

private suspend fun decode(ctx: Context, uri: Uri, maxEdge: Int): Bitmap = withContext(Dispatchers.IO) {
    ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { dec, info, _ ->
        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val s = maxOf(info.size.width, info.size.height)
        if (s > maxEdge) {
            val k = maxEdge.toFloat() / s
            dec.setTargetSize((info.size.width * k).toInt().coerceAtLeast(1), (info.size.height * k).toInt().coerceAtLeast(1))
        }
    }
}

private fun scaleDown(b: Bitmap, maxEdge: Int): Bitmap {
    val s = maxOf(b.width, b.height)
    if (s <= maxEdge) return b
    val k = maxEdge.toFloat() / s
    return Bitmap.createScaledBitmap(b, (b.width * k).toInt(), (b.height * k).toInt(), true)
}

private suspend fun saveJpeg(ctx: Context, bmp: Bitmap, baseName: String): Boolean = withContext(Dispatchers.IO) {
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, "${baseName.substringBeforeLast('.')}_edit_${System.currentTimeMillis()}.jpg")
        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/OpenGallery")
        put(MediaStore.MediaColumns.IS_PENDING, 1)
    }
    val res = ctx.contentResolver
    val uri = res.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
    res.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
    values.clear(); values.put(MediaStore.MediaColumns.IS_PENDING, 0)
    res.update(uri, values, null, null)
    true
}

@Composable
fun PhotoEditorScreen(vm: GalleryViewModel, nav: NavController, mediaId: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val m = vm.media.value.firstOrNull { it.id == mediaId }
    if (m == null || m.isVideo) { LaunchedEffect(Unit) { nav.popBackStack() }; return }

    var full by remember { mutableStateOf<Bitmap?>(null) }   // up to 4096 px, used for the saved copy
    var small by remember { mutableStateOf<Bitmap?>(null) }  // up to 1080 px, used for the live preview
    LaunchedEffect(mediaId) {
        runCatching {
            val f = decode(ctx, m.uri, 4096)
            full = f
            small = withContext(Dispatchers.Default) { scaleDown(f, 1080) }
        }.onFailure { Toast.makeText(ctx, "Couldn't open this image", Toast.LENGTH_SHORT).show() }
    }

    var rotation by remember { mutableIntStateOf(0) }
    var flip by remember { mutableStateOf(false) }
    var cl by remember { mutableFloatStateOf(0f) }
    var cr by remember { mutableFloatStateOf(0f) }
    var ct by remember { mutableFloatStateOf(0f) }
    var cb by remember { mutableFloatStateOf(0f) }
    var look by remember { mutableStateOf(Look.ORIGINAL) }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(1f) }
    var saving by remember { mutableStateOf(false) }

    val adjust = Adjust(look, brightness, contrast, saturation)
    val preview by produceState<Bitmap?>(null, small, rotation, flip, cl, cr, ct, cb, adjust) {
        val s = small
        value = if (s == null) null else withContext(Dispatchers.Default) {
            render(s, rotation, flip, cl, cr, ct, cb, adjust.matrix())
        }
    }

    fun save() {
        val f = full ?: return
        saving = true
        scope.launch {
            val ok = withContext(Dispatchers.Default) {
                runCatching { saveJpeg(ctx, render(f, rotation, flip, cl, cr, ct, cb, adjust.matrix()), m.name) }.getOrDefault(false)
            }
            saving = false
            vm.refresh()
            Toast.makeText(ctx, if (ok) "Saved to Pictures/OpenGallery" else "Save failed", Toast.LENGTH_LONG).show()
            if (ok) nav.popBackStack()
        }
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Edit photo") },
            navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            actions = { TextButton(enabled = !saving && full != null, onClick = { save() }) { Text("Save copy") } }
        )
    }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState())) {
            if (saving) LinearProgressIndicator(Modifier.fillMaxWidth())
            Box(Modifier.fillMaxWidth().height(340.dp), contentAlignment = Alignment.Center) {
                preview?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
                    ?: CircularProgressIndicator()
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                IconButton(onClick = { rotation = (rotation + 270) % 360 }) { Icon(Icons.Default.RotateLeft, "Rotate left") }
                IconButton(onClick = { rotation = (rotation + 90) % 360 }) { Icon(Icons.Default.RotateRight, "Rotate right") }
                IconButton(onClick = { flip = !flip }) { Icon(Icons.Default.Flip, "Flip") }
            }
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Look.entries) { l ->
                    FilterChip(selected = look == l, onClick = { look = l }, label = { Text(l.label) })
                }
            }
            Column(Modifier.padding(16.dp)) {
                Adj("Brightness", brightness, -0.5f..0.5f) { brightness = it }
                Adj("Contrast", contrast, 0.5f..1.5f) { contrast = it }
                Adj("Saturation", saturation, 0f..2f) { saturation = it }
                Spacer(Modifier.height(8.dp))
                Text("Crop", style = MaterialTheme.typography.titleSmall)
                Adj("Left", cl, 0f..0.45f) { cl = it }
                Adj("Right", cr, 0f..0.45f) { cr = it }
                Adj("Top", ct, 0f..0.45f) { ct = it }
                Adj("Bottom", cb, 0f..0.45f) { cb = it }
                TextButton(onClick = {
                    rotation = 0; flip = false; cl = 0f; cr = 0f; ct = 0f; cb = 0f
                    look = Look.ORIGINAL; brightness = 0f; contrast = 1f; saturation = 1f
                }) { Text("Reset") }
                Text("“Save copy” writes a new JPEG (max 4096 px on the long edge); the original is untouched.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun Adj(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Text(label, style = MaterialTheme.typography.bodySmall)
    Slider(value = value, onValueChange = onChange, valueRange = range)
}
