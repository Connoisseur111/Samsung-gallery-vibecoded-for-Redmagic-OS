@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.opengallery.ui

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CropRotate
import androidx.compose.material.icons.filled.InvertColors
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Tonality
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.opengallery.GalleryViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class PState(
    val rot: Int = 0,
    val flipH: Boolean = false,
    val flipV: Boolean = false,
    val crop: CropRect = CropRect(),
    val look: Look = Look.ORIGINAL,
    val brightness: Int = 0,
    val exposure: Int = 0,
    val contrast: Int = 0,
    val saturation: Int = 0,
    val warmth: Int = 0,
    val strokes: List<InkStroke> = emptyList()
)

private fun PState.matrix(): ColorMatrix? {
    if (look == Look.ORIGINAL && brightness == 0 && exposure == 0 && contrast == 0 && saturation == 0 && warmth == 0) return null
    val sat = 1f + saturation / 100f
    val c = 1f + contrast / 100f * 0.6f
    val e = 1f + exposure / 100f * 0.8f
    val t = (-0.5f * c + 0.5f) * 255f + brightness / 100f * 80f
    val w = warmth / 100f * 0.15f
    val m = ColorMatrix()
    m.setSaturation(sat)
    m.postConcat(ColorMatrix(floatArrayOf(
        c * e + w, 0f, 0f, 0f, t,
        0f, c * e, 0f, 0f, t,
        0f, 0f, c * e - w, 0f, t,
        0f, 0f, 0f, 1f, 0f)))
    val lm = lookMatrix(look)
    if (lm != null) m.postConcat(lm)
    return m
}

/** flip -> rotate -> (optional) crop -> color adjustments. */
private fun render(src: Bitmap, s: PState, applyCrop: Boolean): Bitmap {
    val mtx = Matrix()
    mtx.postScale(if (s.flipH) -1f else 1f, if (s.flipV) -1f else 1f, src.width / 2f, src.height / 2f)
    mtx.postRotate(s.rot.toFloat())
    val rotated = Bitmap.createBitmap(src, 0, 0, src.width, src.height, mtx, true)
    val c = if (applyCrop) s.crop else CropRect()
    val x = (rotated.width * c.l).toInt().coerceIn(0, rotated.width - 1)
    val y = (rotated.height * c.t).toInt().coerceIn(0, rotated.height - 1)
    val w = (rotated.width * (1f - c.l - c.r)).toInt().coerceIn(1, rotated.width - x)
    val h = (rotated.height * (1f - c.t - c.b)).toInt().coerceIn(1, rotated.height - y)
    val cropped = if (x == 0 && y == 0 && w == rotated.width && h == rotated.height) rotated
    else Bitmap.createBitmap(rotated, x, y, w, h)
    val filter = s.matrix()
    if (filter == null && s.strokes.isEmpty()) return cropped
    val out = Bitmap.createBitmap(cropped.width, cropped.height, Bitmap.Config.ARGB_8888)
    val cv = Canvas(out)
    val paint = Paint()
    if (filter != null) paint.colorFilter = ColorMatrixColorFilter(filter)
    cv.drawBitmap(cropped, 0f, 0f, paint)
    drawInk(cv, out.width.toFloat(), out.height.toFloat(), s.strokes)
    return out
}

private suspend fun decode(ctx: Context, uri: Uri, maxEdge: Int): Bitmap = withContext(Dispatchers.IO) {
    ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { dec, info, _ ->
        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val s = maxOf(info.size.width, info.size.height)
        if (s > maxEdge) {
            val k = maxEdge.toFloat() / s
            dec.setTargetSize((info.size.width * k).toInt().coerceAtLeast(1), (info.size.height * k).toInt().coerceAtLeast(1))
        }
    }
}

private fun scaleDown(b: Bitmap, maxEdge: Int): Bitmap {
    val s = maxOf(b.width, b.height)
    if (s <= maxEdge) return b
    val k = maxEdge.toFloat() / s
    return Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true)
}

/** Replaces the original picture with the edited one (same file, same name). */
private suspend fun overwriteImage(ctx: Context, uri: Uri, name: String, bmp: Bitmap): Boolean = withContext(Dispatchers.IO) {
    val ext = name.substringAfterLast('.', "").lowercase()
    val (fmt, q) = when (ext) {
        "png" -> Bitmap.CompressFormat.PNG to 100
        "webp" -> (if (android.os.Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP) to 95
        else -> Bitmap.CompressFormat.JPEG to 95
    }
    runCatching {
        ctx.contentResolver.openOutputStream(uri, "wt")!!.use { bmp.compress(fmt, q, it) }
    }.getOrDefault(false)
}

private suspend fun saveJpeg(ctx: Context, bmp: Bitmap, baseName: String): Boolean = withContext(Dispatchers.IO) {
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, "${baseName.substringBeforeLast('.')}_edit_${System.currentTimeMillis()}.jpg")
        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/OpenGallery")
        put(MediaStore.MediaColumns.IS_PENDING, 1)
    }
    val res = ctx.contentResolver
    val uri = res.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
    res.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
    values.clear()
    values.put(MediaStore.MediaColumns.IS_PENDING, 0)
    res.update(uri, values, null, null)
    true
}

@Composable
fun PhotoEditorScreen(vm: GalleryViewModel, nav: NavController, mediaId: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val m = vm.media.value.firstOrNull { it.id == mediaId }
    if (m == null || m.isVideo) {
        LaunchedEffect(Unit) { exitEditor(vm, nav) }
        return
    }

    var full by remember { mutableStateOf<Bitmap?>(null) }   // up to 4096 px: used for the saved copy
    var small by remember { mutableStateOf<Bitmap?>(null) }  // up to 1080 px: used for the live preview
    LaunchedEffect(mediaId) {
        runCatching {
            val f = decode(ctx, m.uri, 4096)
            full = f
            small = withContext(Dispatchers.Default) { scaleDown(f, 1080) }
        }.onFailure { Toast.makeText(ctx, "Couldn't open this image", Toast.LENGTH_SHORT).show() }
    }

    var tool by remember { mutableIntStateOf(1) } // 0 crop, 1 filters, 2 tune
    var cur by remember { mutableStateOf(PState()) }
    var hist by remember { mutableStateOf(listOf(PState())) }
    var hi by remember { mutableIntStateOf(0) }
    var saving by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }

    var brushMode by remember { mutableIntStateOf(0) }   // 0 pen, 1 marker, 2 eraser
    var brushColor by remember { mutableStateOf(Color.Red) }
    var brushSize by remember { mutableFloatStateOf(20f) }
    var brushOpacity by remember { mutableFloatStateOf(1f) }
    var showWheel by remember { mutableStateOf(false) }
    var live by remember { mutableStateOf<InkStroke?>(null) }

    fun commit(s0: PState) {
        var s = s0
        val prev = hist[hi]
        if (s.strokes.isNotEmpty() && (s.rot != prev.rot || s.flipH != prev.flipH || s.flipV != prev.flipV || s.crop != prev.crop)) {
            s = s.copy(strokes = emptyList())
            Toast.makeText(ctx, "Drawing cleared because the picture was cropped or rotated", Toast.LENGTH_SHORT).show()
        }
        cur = s
        hist = hist.take(hi + 1) + s
        hi = hist.size - 1
    }

    val edited = hi > 0
    BackHandler(edited && !saving) { confirmExit = true }

    val base = cur.copy(strokes = emptyList())
    val preview by produceState<Bitmap?>(null, small, base, tool) {
        val s = small
        value = if (s == null) null else withContext(Dispatchers.Default) { render(s, base, tool != 0) }
    }
    val thumb = remember(small) { small?.let { scaleDown(it, 140).asImageBitmap() } }

    val writeGate = rememberWriteGate(m.uri)
    fun saveOriginal() {
        val f = full ?: return
        saving = true
        scope.launch {
            val ok = withContext(Dispatchers.Default) {
                runCatching { overwriteImage(ctx, m.uri, m.name, render(f, cur, true)) }.getOrDefault(false)
            }
            saving = false
            clearImageCaches(ctx)
            vm.refresh()
            Toast.makeText(ctx, if (ok) "Saved" else "Save failed", Toast.LENGTH_LONG).show()
            if (ok) exitEditor(vm, nav)
        }
    }

    fun save() {
        val f = full ?: return
        saving = true
        scope.launch {
            val ok = withContext(Dispatchers.Default) {
                runCatching { saveJpeg(ctx, render(f, cur, true), m.name) }.getOrDefault(false)
            }
            saving = false
            vm.refresh()
            Toast.makeText(ctx, if (ok) "Saved to Pictures/OpenGallery" else "Save failed", Toast.LENGTH_LONG).show()
            if (ok) exitEditor(vm, nav)
        }
    }

    Column(Modifier.fillMaxSize().background(Color.Black).navigationBarsPadding()) {
        EditTopBar(
            canUndo = hi > 0, canRedo = hi < hist.size - 1,
            onUndo = { if (hi > 0) { hi -= 1; cur = hist[hi] } },
            onRedo = { if (hi < hist.size - 1) { hi += 1; cur = hist[hi] } },
            onRevert = { cur = PState(); hist = listOf(PState()); hi = 0 },
            onSave = { writeGate { saveOriginal() } }, saveEnabled = !saving && full != null && hi > 0,
            onSaveCopy = { save() }
        )
        if (saving) LinearProgressIndicator(Modifier.fillMaxWidth())
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            val bmp = preview
            if (bmp == null) CircularProgressIndicator() else BoxWithConstraints(Modifier.fillMaxSize()) {
                val density = LocalDensity.current
                val cw = with(density) { maxWidth.toPx() }
                val ch = with(density) { maxHeight.toPx() }
                val sc = minOf(cw / bmp.width, ch / bmp.height)
                val iw = with(density) { (bmp.width * sc).toDp() }
                val ih = with(density) { (bmp.height * sc).toDp() }
                Box(Modifier.align(Alignment.Center).size(iw, ih)) {
                    Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                    if (tool != 0) InkLayer(
                        strokes = cur.strokes, live = live, enabled = tool == 3,
                        onStart = { p ->
                            val mk = brushMode == 1
                            live = InkStroke(listOf(p), brushColor.toArgb(), brushSize / 100f * 0.1f * (if (mk) 1.8f else 1f), brushOpacity, brushMode == 2)
                        },
                        onMove = { p -> live = live?.let { it.copy(pts = it.pts + p) } },
                        onEnd = { live?.let { commit(cur.copy(strokes = cur.strokes + it)) }; live = null },
                        modifier = Modifier.fillMaxSize()
                    )
                    if (tool == 0) CropOverlay(
                        cur.crop, onChange = { r -> cur = cur.copy(crop = r) }, onCommit = { commit(cur) },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
            when (tool) {
                0 -> CropToolsRow(
                    onFlipH = { commit(cur.copy(flipH = !cur.flipH, crop = CropRect())) },
                    onRotate = { commit(cur.copy(rot = (cur.rot + 90) % 360, crop = CropRect())) },
                    onFlipV = { commit(cur.copy(flipV = !cur.flipV, crop = CropRect())) },
                    onRatio = { r ->
                        val b = preview
                        if (b != null) commit(cur.copy(crop = rectForRatio(r, b.width.toFloat() / b.height)))
                    }
                )
                1 -> FilterStrip(Look.entries, cur.look, thumb) { l -> commit(cur.copy(look = l)) }
                2 -> TunePanel(
                    names = listOf("Brightness", "Exposure", "Contrast", "Saturation", "Warmth"),
                    icons = listOf(Icons.Filled.WbSunny, Icons.Filled.Brightness6, Icons.Filled.Tonality, Icons.Filled.InvertColors, Icons.Filled.Whatshot),
                    values = listOf(cur.brightness, cur.exposure, cur.contrast, cur.saturation, cur.warmth),
                    onChange = { i, v ->
                        cur = when (i) {
                            0 -> cur.copy(brightness = v)
                            1 -> cur.copy(exposure = v)
                            2 -> cur.copy(contrast = v)
                            3 -> cur.copy(saturation = v)
                            else -> cur.copy(warmth = v)
                        }
                    },
                    onCommit = { commit(cur) }
                )
                else -> DrawPanel(
                    mode = brushMode,
                    onMode = { brushMode = it; if (it == 1) brushOpacity = 0.4f else if (it == 0) brushOpacity = 1f },
                    color = brushColor, onColorClick = { showWheel = true },
                    size = brushSize, onSize = { brushSize = it },
                    opacity = brushOpacity, onOpacity = { brushOpacity = it }
                )
            }
        }
        ToolDock(listOf(Icons.Filled.CropRotate, Icons.Filled.Palette, Icons.Filled.Tune, Icons.Filled.Brush), tool) { tool = it }
    }

    if (showWheel) ColorWheelDialog(brushColor, onPick = { brushColor = it; if (brushMode == 2) brushMode = 0 }, onDismiss = { showWheel = false })

    if (confirmExit) AlertDialog(
        onDismissRequest = { confirmExit = false }, containerColor = CardBg,
        title = { Text("Save your changes or discard them?") },
        confirmButton = { TextButton(onClick = { confirmExit = false; save() }) { Text("Save copy") } },
        dismissButton = {
            Column {
                TextButton(onClick = { confirmExit = false; exitEditor(vm, nav) }) { Text("Discard") }
                TextButton(onClick = { confirmExit = false }) { Text("Cancel") }
            }
        }
    )
}
