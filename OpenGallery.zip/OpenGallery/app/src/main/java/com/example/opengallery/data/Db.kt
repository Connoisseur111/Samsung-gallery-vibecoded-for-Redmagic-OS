package com.example.opengallery.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** A virtual, in-app album. parentId == null means top level, so albums nest freely. */
@Entity(
    tableName = "albums",
    foreignKeys = [ForeignKey(
        entity = AlbumEntity::class, parentColumns = ["id"],
        childColumns = ["parentId"], onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("parentId")]
)
data class AlbumEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val parentId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

/** Links a MediaStore item to an album (the file itself is never moved or copied). */
@Entity(
    tableName = "album_items",
    primaryKeys = ["albumId", "mediaId"],
    foreignKeys = [ForeignKey(
        entity = AlbumEntity::class, parentColumns = ["id"],
        childColumns = ["albumId"], onDelete = ForeignKey.CASCADE
    )]
)
data class AlbumItemEntity(
    val albumId: Long,
    val mediaId: Long,
    val addedAt: Long = System.currentTimeMillis()
)

@Dao
interface AlbumDao {
    @Query("SELECT * FROM albums WHERE parentId IS :parentId")
    fun children(parentId: Long?): Flow<List<AlbumEntity>>

    @Query("SELECT * FROM albums WHERE id = :id")
    suspend fun get(id: Long): AlbumEntity?

    @Insert suspend fun insert(album: AlbumEntity): Long

    @Query("UPDATE albums SET name = :name WHERE id = :id")
    suspend fun rename(id: Long, name: String)

    @Query("UPDATE albums SET parentId = :parentId WHERE id = :id")
    suspend fun move(id: Long, parentId: Long?)

    @Query("DELETE FROM albums WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM album_items WHERE albumId = :albumId")
    fun items(albumId: Long): Flow<List<AlbumItemEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addItems(items: List<AlbumItemEntity>)

    @Query("DELETE FROM album_items WHERE albumId = :albumId AND mediaId IN (:ids)")
    suspend fun removeItems(albumId: Long, ids: List<Long>)
}

@Database(entities = [AlbumEntity::class, AlbumItemEntity::class], version = 1, exportSchema = false)
abstract class GalleryDb : RoomDatabase() {
    abstract fun albumDao(): AlbumDao

    companion object {
        @Volatile private var inst: GalleryDb? = null
        fun get(c: Context): GalleryDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, GalleryDb::class.java, "gallery.db")
                .build().also { inst = it }
        }
    }
}
