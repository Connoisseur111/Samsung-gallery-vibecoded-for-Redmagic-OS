@file:OptIn(UnstableApi::class, ExperimentalFoundationApi::class)

package com.example.opengallery.ui

import android.content.Intent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.Image
import androidx.compose.runtime.produceState
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitVerticalTouchSlopOrCancellation
import androidx.compose.foundation.gestures.drag
import androidx.compose.animation.core.tween
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.zIndex
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.border
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.GalleryMedia
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ViewerScreen(vm: GalleryViewModel, nav: NavController, startIndex: Int, slideshow: Boolean) {
    // The viewer keeps its own list so a deleted / moved file can disappear and the next one slide in.
    var list by remember { mutableStateOf(vm.viewerList) }
    val actions = rememberFileActions(vm::refresh)
    val favs by vm.favorites.collectAsState()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var showUi by remember { mutableStateOf(true) }
    var dialog by remember { mutableStateOf<String?>(null) }
    var detailsOpen by remember { mutableStateOf(false) }   // Samsung-style: picture moves up, details slide in below it
    if (list.isEmpty()) {
        LaunchedEffect(Unit) { nav.popBackStack() }
        return
    }
    val pager = rememberPagerState(startIndex.coerceIn(0, list.lastIndex)) { list.size }
    // Warm the quick thumbnails of the videos next to the one on screen, so swiping to them never shows black.
    val warmCtx = LocalContext.current
    LaunchedEffect(pager.currentPage) {
        withContext(Dispatchers.IO) {
            for (i in (pager.currentPage - 3)..(pager.currentPage + 3)) {
                val mm = list.getOrNull(i) ?: continue
                if (quickThumbs.get(mm.id) == null) runCatching {
                    quickThumbs.put(mm.id, warmCtx.contentResolver.loadThumbnail(mm.uri, android.util.Size(640, 640), null))
                }
            }
        }
    }
    // Make the viewer's window cover the whole screen, including behind the navigation bar (no gap at the bottom).
    val hostView = androidx.compose.ui.platform.LocalView.current
    // Window set-up runs once: touching the window's attributes on every recomposition (every page change)
    // makes Android re-lay-out the whole window, which shows up as a black flash.
    val windowDone = remember { booleanArrayOf(false) }
    androidx.compose.runtime.SideEffect {
        val w = (hostView.parent as? androidx.compose.ui.window.DialogWindowProvider)?.window
        if (w != null && !windowDone[0]) {
            windowDone[0] = true
            androidx.core.view.WindowCompat.setDecorFitsSystemWindows(w, false)
            w.setDimAmount(0f)
            w.navigationBarColor = android.graphics.Color.TRANSPARENT
            w.statusBarColor = android.graphics.Color.TRANSPARENT
            if (android.os.Build.VERSION.SDK_INT >= 29) w.isNavigationBarContrastEnforced = false
            // sideways: also draw under the camera cut-out so no strip of the album shows at the screen edge
            val lp = w.attributes
            lp.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            w.attributes = lp
        }
    }
    var zoomed by remember { mutableStateOf(false) }
    // Hide the viewer the instant "back" is pressed; the heavy clean-up happens after it is already gone.
    var closing by remember { mutableStateOf(false) }
    var vctlNow: VideoCtl? = null
    val closeViewer: () -> Unit = {
        if (!closing) {
            closing = true
            vctlNow?.player?.pause()
            nav.popBackStack()
        }
    }
    androidx.activity.compose.BackHandler(enabled = !closing) { closeViewer() }
    androidx.activity.compose.BackHandler(enabled = detailsOpen && !closing) { detailsOpen = false }
    var stripExpanded by remember { mutableStateOf(false) }
    var stripTouch by remember { mutableLongStateOf(0L) }
    var shot by remember { mutableStateOf<Shot?>(null) }
    var dragY by remember { mutableFloatStateOf(0f) }
    var dragX by remember { mutableFloatStateOf(0f) }
    var detailFrac by remember { mutableFloatStateOf(1f) }   // picture share of the screen while details open/close
    val landV = androidx.compose.ui.platform.LocalConfiguration.current.orientation ==
        android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val fracTarget = if (landV) 0.5f else 0.45f
    LaunchedEffect(detailsOpen, landV) {
        animate(detailFrac, if (detailsOpen) fracTarget else 1f, animationSpec = tween(250)) { v, _ -> detailFrac = v }
    }
    val dragging by remember { androidx.compose.runtime.derivedStateOf { dragX != 0f || dragY != 0f } }
    LaunchedEffect(dragging) { vm.viewerDragging = dragging }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { vm.viewerDragging = false } }
    val current = list[pager.currentPage.coerceIn(0, list.lastIndex)]
    // After a delete / move: show the next file (or the previous one if it was the last); close when none are left.
    val removeFromViewer: (GalleryMedia) -> Unit = { gone ->
        val rest = list.filter { it.uri != gone.uri }
        vm.viewerList = rest
        list = rest
    }
    // One controller per video on screen; it exists immediately so the controls never flicker when switching videos.
    val ctl = remember(current.id) { if (current.isVideo) VideoCtl(current) else null }
    vctlNow = ctl
    // The frame strip shrinks back to the thumbnails a few seconds after you stop touching it.
    // The big strip now stays open until you tap it (no more closing by itself); a new file starts closed.
    LaunchedEffect(pager.currentPage) { stripExpanded = false }
    val capture: (VideoCtl) -> Unit = { c ->
        val posMs = c.pos
        scope.launch {
            val res = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching {
                    val r = android.media.MediaMetadataRetriever()
                    r.setDataSource(ctx, c.media.uri)
                    val bmp = r.getFrameAtTime(posMs * 1000, android.media.MediaMetadataRetriever.OPTION_CLOSEST)
                    r.release()
                    if (bmp == null) null else saveShot(ctx, bmp)?.let { id -> id to bmp }
                }.getOrNull()
            }
            if (res != null) {
                vm.refresh()
                shot = Shot(res.first, res.second.asImageBitmap(), c.media.id, posMs)
            } else {
                android.widget.Toast.makeText(ctx, "Couldn't capture this frame", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }
    if (slideshow) LaunchedEffect(Unit) {
        while (pager.currentPage < list.lastIndex) {
            delay(3000)
            pager.animateScrollToPage(pager.currentPage + 1)
        }
        nav.popBackStack()
    }

    Box(
        Modifier.fillMaxSize().graphicsLayer { alpha = if (closing) 0f else 1f }
            // The page behind (the album / search results) shows through as the picture is dragged away.
            .drawBehind {
                val dist = kotlin.math.hypot(dragX, dragY)
                drawRect(Color.Black.copy(alpha = (1f - dist / 700f).coerceIn(0f, 1f)))
            }
            .pointerInput(zoomed, detailsOpen) {
                if (zoomed) return@pointerInput
                // Slide a finger down: the picture shrinks and follows your finger anywhere on screen.
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    var firstOver = 0f
                    val slop = awaitVerticalTouchSlopOrCancellation(down.id) { change, over ->
                        change.consume(); firstOver = over
                    } ?: return@awaitEachGesture
                    val tracker = VelocityTracker()
                    tracker.addPosition(slop.uptimeMillis, slop.position)
                    if (detailsOpen) {
                        // details are showing: swiping down brings the picture back to full size
                        var total = 0f
                        drag(slop.id) { change ->
                            total += change.positionChange().y
                            tracker.addPosition(change.uptimeMillis, change.position)
                            change.consume()
                        }
                        if (total > 90f || tracker.calculateVelocity().y > 1200f) detailsOpen = false
                        return@awaitEachGesture
                    }
                    if (firstOver < 0f) {
                        // sliding up: the picture itself doesn't shrink, it just makes room for the details
                        var upY = 0f
                        val okUp = drag(slop.id) { change ->
                            upY += change.positionChange().y
                            tracker.addPosition(change.uptimeMillis, change.position)
                            val prog = (-upY / 450f).coerceIn(0f, 1f)
                            detailFrac = 1f - (1f - fracTarget) * prog
                            change.consume()
                        }
                        val vy = tracker.calculateVelocity().y
                        if (okUp && (upY < -110f || vy < -1100f)) detailsOpen = true
                        else scope.launch { animate(detailFrac, 1f, animationSpec = tween(200)) { v, _ -> detailFrac = v } }
                        return@awaitEachGesture
                    }
                    val ok = drag(slop.id) { change ->
                        val d = change.positionChange()
                        dragX += d.x; dragY += d.y
                        tracker.addPosition(change.uptimeMillis, change.position)
                        change.consume()
                    }
                    val v = tracker.calculateVelocity()
                    val dist = kotlin.math.hypot(dragX, dragY)
                    if (ok && (dist > 260f || v.y > 1800f) && dragY > 0f) {
                        scope.launch {
                            val sx = dragX; val sy = dragY
                            animate(0f, 1f, animationSpec = tween(160)) { t, _ ->
                                dragX = sx * (1f + t); dragY = sy + 400f * t
                            }
                            closeViewer()
                        }
                    } else {
                        // sliding up opens the details, like Samsung
                        if (ok && dragY < 0f && (dragY < -110f || v.y < -1100f)) detailsOpen = true
                        scope.launch {
                            val sx = dragX; val sy = dragY
                            animate(1f, 0f, animationSpec = spring(stiffness = 500f)) { t, _ -> dragX = sx * t; dragY = sy * t }
                        }
                    }
                }
            }
    ) {
        Box(Modifier.fillMaxSize().background(Color(0xFFFF00FF)))   // DIAG: magenta = pager has no page at all
        LaunchedEffect(pager) {
            androidx.compose.runtime.snapshotFlow {
                Triple(pager.currentPage, (pager.currentPageOffsetFraction * 100).toInt(), pager.layoutInfo.visiblePagesInfo.size)
            }.collect { Dbg.log("pager cur=${it.first} off=${it.second}% vis=${it.third}") }
        }
        HorizontalPager(
            pager,
            beyondViewportPageCount = 1,
            key = { page -> list.getOrNull(page)?.uri?.toString() ?: page },
            modifier = Modifier.fillMaxSize().graphicsLayer {
                val dist = kotlin.math.hypot(dragX, dragY)
                val f = (1f - dist / 1400f).coerceIn(0.5f, 1f)
                translationX = dragX; translationY = dragY; scaleX = f; scaleY = f
            }
        ) { page ->
            val m = list.getOrNull(page) ?: return@HorizontalPager
            val land = androidx.compose.ui.platform.LocalConfiguration.current.orientation ==
                android.content.res.Configuration.ORIENTATION_LANDSCAPE
            val frac = detailFrac
            val showPanel = detailsOpen || detailFrac < 0.999f
            val pageContent: @Composable () -> Unit = {
                if (m.isVideo) VideoPage(
                    m, if (m.id == current.id) ctl else null, vm.resumeVideo,
                    onResumed = { vm.resumeVideo = null }, onTap = { showUi = !showUi }
                )
                else ZoomImage(m, pager.currentPage == page, { zoomed = it }) { showUi = !showUi }
            }
            if (land) Row(Modifier.fillMaxSize()) {
                // sideways: the picture stays on the left and the details sit on its right
                Box(Modifier.fillMaxHeight().fillMaxWidth(frac)) { pageContent() }
                if (showPanel) {
                    val bars = activityBarInsets()
                    Box(
                        Modifier.weight(1f).fillMaxHeight().padding(top = bars.top, end = bars.right)
                            .verticalScroll(androidx.compose.foundation.rememberScrollState())
                    ) { DetailsPanel(m, onEdit = { dialog = "detailsEdit" }) }
                }
            } else Column(Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxWidth().fillMaxHeight(frac)) { pageContent() }
                if (showPanel) DetailsPanel(m, onEdit = { dialog = "detailsEdit" })
            }
        }
        Text(
            Dbg.lines.joinToString("\n"), color = Color.Yellow, fontSize = 9.sp,
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
            modifier = Modifier.align(Alignment.TopStart).statusBarsPadding().padding(top = 60.dp, start = 4.dp)
                .background(Color(0x88000000))
        )
        if (showUi && !dragging && !detailsOpen) {
            Row(
                Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                CircleButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", { closeViewer() })
                PillActions { close ->
                    MenuItem("Details") { close(); detailsOpen = true }
                    if (current.isVideo) MenuItem("Open in video player") {
                        close()
                        val i = Intent(Intent.ACTION_VIEW).setDataAndType(current.uri, "video/*")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        runCatching { ctx.startActivity(i) }
                    } else MenuItem("Set as wallpaper") {
                        close()
                        val i = Intent(Intent.ACTION_ATTACH_DATA).setDataAndType(current.uri, "image/*")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        runCatching { ctx.startActivity(Intent.createChooser(i, "Set as")) }
                    }
                    MenuItem("Rename") { close(); dialog = "rename" }
                    MenuItem("Copy to album") { close(); dialog = "copy" }
                    MenuItem("Move to album") { close(); dialog = "move" }
                }
            }
            Column(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 78.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (ctl != null) {
                    VideoControlRow(ctl) { capture(ctl) }
                    Spacer(Modifier.height(8.dp))
                }
                if (ctl != null && stripExpanded) VideoScrubber(
                    ctl.media, ctl.dur, ctl.pos,
                    onTapEnd = { stripExpanded = false }
                ) { t ->
                    stripTouch = System.currentTimeMillis(); ctl.player?.seekTo(t)
                } else Filmstrip(list, pager.currentPage, { i -> scope.launch { pager.scrollToPage(i) } }) {
                    if (ctl != null) { stripExpanded = true; stripTouch = System.currentTimeMillis() }
                }
                Spacer(Modifier.height(10.dp))
                ActionPill {
                    PillAction(if (current.id in favs) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null) {
                        vm.toggleFavorite(listOf(current.id), current.id !in favs)
                    }
                    PillAction(Icons.Filled.Edit, null) {
                        // The viewer is a dialog destination, so close it first, then open the editor.
                        val route = if (current.isVideo) "editor/${current.id}" else "photoeditor/${current.id}"
                        nav.popBackStack()
                        nav.navigate(route)
                    }
                    PillAction(Icons.Filled.Share, null) { actions.share(listOf(current)) }
                    PillAction(Icons.Filled.Delete, null) { actions.trash(listOf(current)) { removeFromViewer(current) } }
                }
            }
        }
    }

    // Screenshot preview: springs up from the capture button to the size of the video, holds a moment, then fades away.
    var shotShown by remember { mutableStateOf<Shot?>(null) }
    val shotGrow = remember { androidx.compose.animation.core.Animatable(0f) }
    val shotAlpha = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(shot) {
        val s0 = shot
        if (s0 != null) {
            shotShown = s0
            shotGrow.snapTo(0f); shotAlpha.snapTo(0f)
            launch { shotAlpha.animateTo(1f, androidx.compose.animation.core.tween(140)) }
            launch {
                shotGrow.animateTo(
                    1f, androidx.compose.animation.core.spring(dampingRatio = 0.62f, stiffness = 260f)
                )
            }
            delay(1500)
            shotAlpha.animateTo(0f, androidx.compose.animation.core.tween(380))
            if (shotShown === s0) shotShown = null
            if (shot === s0) shot = null
        }
    }
    shotShown?.let { sh ->
        val screenH = androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp
        val density = androidx.compose.ui.platform.LocalDensity.current
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val ratio = (sh.bitmap.width.toFloat() / sh.bitmap.height.toFloat()).coerceIn(0.3f, 3f)
            androidx.compose.foundation.Image(
                bitmap = sh.bitmap, contentDescription = "Screenshot",
                contentScale = ContentScale.Fit,
                modifier = Modifier.aspectRatio(ratio)
                    .graphicsLayer {
                        // starts small near the capture button (bottom-left), ends at the video's size
                        val t = shotGrow.value
                        val sc = 0.12f + 0.88f * t
                        scaleX = sc; scaleY = sc
                        alpha = shotAlpha.value.coerceIn(0f, 1f)
                        translationY = (1f - t) * with(density) { (screenH * 0.28f).dp.toPx() }
                        translationX = (1f - t) * with(density) { (-90).dp.toPx() }
                    }
                    .clip(RoundedCornerShape(6.dp))
                    .clickable {
                        val s2 = sh; shot = null; shotShown = null
                        scope.launch {
                            var tries = 0
                            while (vm.media.value.none { it.id == s2.id } && tries < 40) { delay(100); tries++ }
                            vm.resumeVideo = s2.videoId to s2.posMs
                            vm.pendingReturn = "viewer/${pager.currentPage}/0"
                            nav.popBackStack()
                            nav.navigate("photoeditor/${s2.id}")
                        }
                    }
            )
        }
    }

    when (dialog) {
        "detailsEdit" -> DetailsEditDialog(current, { dialog = null }) { newName, newDate ->
            val u = current.uri
            val updated = list.map { if (it.uri == u) it.copy(name = newName, dateTaken = newDate) else it }
            vm.viewerList = updated
            list = updated
            vm.refresh()
        }
        "rename" -> RenameMediaDialog(current, { dialog = null }) { newName ->
            val u = current.uri
            val renamed = list.map { if (it.uri == u) it.copy(name = newName) else it }
            vm.viewerList = renamed
            list = renamed
            vm.refresh()
        }
        "copy" -> AlbumMovePicker(vm, actions, listOf(current), move = false, onDismiss = { dialog = null }, onDone = { dialog = null })
        "move" -> AlbumMovePicker(vm, actions, listOf(current), move = true, onDismiss = { dialog = null }, onDone = { dialog = null; removeFromViewer(current) })
    }
}

/** Small thumbnail strip above the action bar; the current item is slightly bigger. */
@Composable
private fun Filmstrip(list: List<GalleryMedia>, current: Int, onPick: (Int) -> Unit, onCurrent: () -> Unit = {}) {
    val state = rememberLazyListState(initialFirstVisibleItemIndex = current.coerceAtLeast(0))
    // The strip itself snaps to the middle item when you let go (built-in snapping, no hand-made settling).
    val fling = androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior(state)
    // True only while the APP is scrolling the strip (tap / swipe of the big picture); then it must not pick files.
    val appMoving = remember { booleanArrayOf(false) }
    val latestCurrent by androidx.compose.runtime.rememberUpdatedState(current)
    val latestPick by androidx.compose.runtime.rememberUpdatedState(onPick)
    androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxWidth().height(60.dp)) {
        val side = (maxWidth / 2 - 26.dp).coerceAtLeast(0.dp)
        // Your finger moves the strip -> the big picture follows the item in the middle.
        LaunchedEffect(state) {
            snapshotFlow {
                val li = state.layoutInfo
                val c = (li.viewportStartOffset + li.viewportEndOffset) / 2
                li.visibleItemsInfo.minByOrNull { kotlin.math.abs(it.offset + it.size / 2 - c) }?.index ?: -1
            }.collect { mid ->
                if (mid >= 0 && !appMoving[0] && state.isScrollInProgress && mid != latestCurrent) latestPick(mid)
            }
        }
        // The big picture changed (swipe / tap) while the strip is not being touched: glide the strip to it.
        LaunchedEffect(current) {
            if (!state.isScrollInProgress) {
                val li = state.layoutInfo
                val c = (li.viewportStartOffset + li.viewportEndOffset) / 2
                val mid = li.visibleItemsInfo.minByOrNull { kotlin.math.abs(it.offset + it.size / 2 - c) }?.index
                if (mid != current) {
                    appMoving[0] = true
                    try { state.animateScrollToItem(current) } finally { appMoving[0] = false }
                }
            }
        }
        LazyRow(
            state = state,
            flingBehavior = fling,
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            contentPadding = PaddingValues(horizontal = side),
            verticalAlignment = Alignment.CenterVertically
        ) {
            itemsIndexed(list) { i, m ->
                val cur = i == current
                Box(
                    Modifier.height(48.dp).width(52.dp)
                        .zIndex(if (cur) 1f else 0f)
                        .graphicsLayer { val sc = if (cur) 1.15f else 0.92f; scaleX = sc; scaleY = sc }
                        .clip(RoundedCornerShape(7.dp))
                        .then(if (cur) Modifier.border(2.dp, Color.White, RoundedCornerShape(7.dp)) else Modifier)
                        .clickable { if (cur) onCurrent() else onPick(i) }
                ) {
                    MediaImage(m, Modifier.fillMaxSize(), fade = false, strip = true)
                    if (m.isVideo) androidx.compose.material3.Icon(
                        Icons.Filled.PlayArrow, null, tint = Color.White,
                        modifier = Modifier.align(Alignment.BottomStart).size(14.dp).padding(1.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ZoomImage(m: GalleryMedia, active: Boolean, onZoom: (Boolean) -> Unit, onTap: () -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val state = rememberTransformableState { zoom, pan, _ ->
        scale = (scale * zoom).coerceIn(1f, 6f)
        offset = if (scale == 1f) Offset.Zero else offset + pan
    }
    LaunchedEffect(scale > 1f, active) { if (active) onZoom(scale > 1f) }
    val appCtx = LocalContext.current.applicationContext
    // This loader can decode animated GIFs, so they play in the viewer.
    val gifLoader = remember(appCtx) { sharedGifLoader(appCtx) }
    Box(Modifier.fillMaxSize()) {
    // Stand-in picture under the sharp one: a photo page is never empty while the full picture is decoded.
    StandIn(m)
    AsyncImage(
        model = m.uri, imageLoader = gifLoader, contentDescription = m.name, contentScale = ContentScale.Fit,
        modifier = Modifier.fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = { scale = if (scale > 1f) 1f else 2.5f; offset = Offset.Zero }
                )
            }
            .transformable(state, canPan = { scale > 1f })
            .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y)
    )
    }
}

/** Small picture (already in memory from the filmstrip/grid, else Android's own thumbnail) drawn instantly. */
@Composable
private fun StandIn(m: GalleryMedia) {
    val ctx = LocalContext.current
    val instant = remember(m.id) {
        val mc = coil.Coil.imageLoader(ctx).memoryCache
        (mc?.get(coil.memory.MemoryCache.Key("strip-${m.uri}")) ?: mc?.get(coil.memory.MemoryCache.Key("thumb-${m.uri}")))
            ?.bitmap?.asImageBitmap()
    }
    val quick by produceState<androidx.compose.ui.graphics.ImageBitmap?>(quickThumbs.get(m.id)?.asImageBitmap(), m.id) {
        if (value == null) value = withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.loadThumbnail(m.uri, android.util.Size(640, 640), null)
                    .also { quickThumbs.put(m.id, it) }.asImageBitmap()
            }.getOrNull()
        }
    }
    val img = quick ?: instant
    if (img != null) Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
}

/** What the viewer needs from the video that is on screen (progress, player). */
private class VideoCtl(val media: GalleryMedia) {
    var player by mutableStateOf<ExoPlayer?>(null)
    var pos by mutableLongStateOf(0L)
    var dur by mutableLongStateOf(media.duration.coerceAtLeast(1L))
    var playing by mutableStateOf(false)
}

private class Shot(val id: Long, val bitmap: androidx.compose.ui.graphics.ImageBitmap, val videoId: Long, val posMs: Long)

/** Saves a captured video frame to Pictures/Screenshots and returns its MediaStore id. */
private fun saveShot(ctx: android.content.Context, bmp: android.graphics.Bitmap): Long? {
    val res = ctx.contentResolver
    val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
    val v = android.content.ContentValues().apply {
        put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, "Screenshot_${stamp}_Gallery.jpg")
        put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Screenshots/")
        put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1)
    }
    val uri = res.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return null
    res.openOutputStream(uri)?.use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 95, it) } ?: return null
    v.clear(); v.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0)
    res.update(uri, v, null, null)
    return android.content.ContentUris.parseId(uri)
}

/** After editing a screenshot taken from a video: leave the editor and go back to that video. */
fun exitEditor(vm: GalleryViewModel, nav: NavController) {
    nav.popBackStack()
    vm.pendingReturn?.let { vm.pendingReturn = null; nav.navigate(it) }
}

/** [capture]  [ > 00:06 / 00:27 ]  [volume] */
@Composable
private fun VideoControlRow(ctl: VideoCtl, onCapture: () -> Unit) {
    var muted by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        CircleButton(Icons.Filled.CropFree, "Capture frame", onCapture, Modifier.align(Alignment.CenterStart))
        Row(
            Modifier.align(Alignment.Center).clip(RoundedCornerShape(24.dp)).background(PillBg)
                .clickable {
                    val p = ctl.player ?: return@clickable
                    if (p.playbackState == Player.STATE_ENDED) p.seekTo(0)
                    if (p.isPlaying) p.pause() else p.play()
                }
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(if (ctl.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = Color.White)
            Spacer(Modifier.width(8.dp))
            Text("${fmtClock(ctl.pos)} / ${fmtClock(ctl.dur)}", color = Color.White, fontSize = 14.sp)
        }
        CircleButton(
            if (muted) Icons.Filled.VolumeOff else Icons.Filled.VolumeUp, "Volume",
            { muted = !muted; ctl.player?.volume = if (muted) 0f else 1f },
            Modifier.align(Alignment.CenterEnd)
        )
    }
}

/** DIAGNOSTIC (0.57): tiny on-screen event log. */
private object Dbg {
    val lines = androidx.compose.runtime.mutableStateListOf<String>()
    fun log(msg: String) {
        lines.add((android.os.SystemClock.uptimeMillis() % 100000).toString() + " " + msg)
        while (lines.size > 9) lines.removeAt(0)
    }
}

@Composable
private fun SideEffectLog(m: GalleryMedia) {
    androidx.compose.runtime.DisposableEffect(m.id) {
        Dbg.log("page+ #${m.id % 1000}")
        onDispose { Dbg.log("page- #${m.id % 1000}") }
    }
}

/** System thumbnails of videos seen in the viewer, so a page is never blank while its frame is decoded. */
private val quickThumbs = android.util.LruCache<Long, android.graphics.Bitmap>(40)

@Composable
private fun VideoPage(
    m: GalleryMedia, ctl: VideoCtl?, resume: Pair<Long, Long>?,
    onResumed: () -> Unit, onTap: () -> Unit
) {
    val ctx = LocalContext.current
    // The player is built a moment after the page becomes the current one (so fast switching stays smooth);
    // a still frame is shown until the first video frame is ready.
    LaunchedEffect(ctl) {
        if (ctl != null && ctl.player == null) {
            delay(350)
            val p = ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(m.uri)); prepare() }
            ctl.player = p
            Dbg.log("player built #${m.id % 1000}")
            if (resume != null && resume.first == m.id) { p.seekTo(resume.second); p.pause(); onResumed() }
        }
    }
    DisposableEffect(ctl) {
        onDispose {
            val p = ctl?.player
            if (p != null) {
                p.pause()
                ctl.player = null
                // Releasing blocks for a moment: do it after the screen has already changed / closed.
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ p.release() }, 400)
            }
        }
    }
    val pl = ctl?.player
    LaunchedEffect(pl) {
        if (pl == null || ctl == null) return@LaunchedEffect
        while (true) {
            ctl.pos = pl.currentPosition
            if (pl.duration > 0) ctl.dur = pl.duration
            ctl.playing = pl.isPlaying
            delay(100)
        }
    }
    // The still frame stays until the player really shows its first video frame (then it is hidden).
    var firstFrame by remember(pl) { mutableStateOf(false) }
    DisposableEffect(pl) {
        val l = object : androidx.media3.common.Player.Listener {
            override fun onRenderedFirstFrame() { firstFrame = true; Dbg.log("firstFrame #${m.id % 1000}") }
        }
        pl?.addListener(l)
        onDispose { pl?.removeListener(l) }
    }
    // The live video is only shown once it is playing (or was moved). Until then the still frame stays, so
    // there is no swap (brightness change) and no stray stretched first frame while the video just sits paused.
    // It is revealed a moment AFTER the first frame was reported (the texture can still be black for a few
    // frames before it really shows the picture) and then stays shown, so the page never flashes black.
    var showPlayer by remember(pl) { mutableStateOf(false) }
    val wantPlayer = firstFrame && ctl != null && (ctl.playing || ctl.pos > 150)
    LaunchedEffect(wantPlayer) {
        if (wantPlayer && !showPlayer) { delay(220); showPlayer = true; Dbg.log("reveal #${m.id % 1000}") }
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF00AA00))) {   // DIAG: green = page exists but nothing drawn
        // Fit (never crop/stretch) so the still frame always has the video's real shape.
        // Both stills stay underneath the live video at all times, so a page never shows plain black while
        // the frame is still being decoded or the player is being swapped.
        val quick by produceState<androidx.compose.ui.graphics.ImageBitmap?>(quickThumbs.get(m.id)?.asImageBitmap(), m.id) {
            if (value == null) value = withContext(Dispatchers.IO) {
                runCatching {
                    ctx.contentResolver.loadThumbnail(m.uri, android.util.Size(640, 640), null)
                        .also { quickThumbs.put(m.id, it); Dbg.log("quick ok #${m.id % 1000}") }.asImageBitmap()
                }.getOrNull()
            }
        }
        // Instant stand-in: the small thumbnail the filmstrip / grid already decoded, read straight from memory
        // in the same frame the page appears (no loading step at all), so a page is never empty.
        SideEffectLog(m)
        val instant = remember(m.id) {
            val mc = coil.Coil.imageLoader(ctx).memoryCache
            (mc?.get(coil.memory.MemoryCache.Key("strip-${m.uri}")) ?: mc?.get(coil.memory.MemoryCache.Key("thumb-${m.uri}")))
                ?.bitmap?.asImageBitmap()
        }
        if (quick == null) instant?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
        quick?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
        MediaImage(m, Modifier.fillMaxSize(), fade = false, scale = ContentScale.Fit)
        MediaImage(m, Modifier.fillMaxSize(), fade = false, poster = true, scale = ContentScale.Fit)
        if (pl != null) AndroidView(
            // TextureView-based player: follows the pager slide / drag-to-close transforms exactly
            // (the default SurfaceView showed a stretched copy of the frame for a moment).
            factory = { c ->
                (android.view.LayoutInflater.from(c).inflate(com.example.opengallery.R.layout.video_player_texture, null) as PlayerView)
                    .also { v -> v.player = pl }
            },
            update = { v -> if (v.player !== pl) v.player = pl },
            onRelease = { v -> v.player = null },
            modifier = Modifier.fillMaxSize().graphicsLayer { alpha = if (showPlayer) 1f else 0f }
        )
        Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { onTap() } })
    }
}

private var gifLoaderInstance: coil.ImageLoader? = null
/** One loader for every photo page, so photos you already saw come straight from memory (no flash). */
private fun sharedGifLoader(ctx: android.content.Context): coil.ImageLoader =
    gifLoaderInstance ?: coil.ImageLoader.Builder(ctx).components { add(coil.decode.ImageDecoderDecoder.Factory()) }.build()
        .also { gifLoaderInstance = it }

internal fun clearSharedViewerLoader() { gifLoaderInstance?.memoryCache?.clear() }
