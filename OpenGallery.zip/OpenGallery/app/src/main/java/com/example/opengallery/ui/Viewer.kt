@file:OptIn(UnstableApi::class)

package com.example.opengallery.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.GalleryMedia

@Composable
fun ViewerScreen(vm: GalleryViewModel, nav: NavController, startIndex: Int) {
    val list = vm.viewerList
    val actions = rememberFileActions(vm::refresh)
    if (list.isEmpty()) { LaunchedEffect(Unit) { nav.popBackStack() }; return }
    val pager = rememberPagerState(startIndex.coerceIn(0, list.lastIndex)) { list.size }
    val current = list[pager.currentPage]
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(pager, Modifier.fillMaxSize()) { page ->
            val m = list[page]
            if (m.isVideo) VideoPage(m, active = pager.currentPage == page) else ZoomImage(m)
        }
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
            Text(current.name, color = Color.White, maxLines = 1, modifier = Modifier.weight(1f))
            IconButton(onClick = {
                nav.navigate(if (current.isVideo) "editor/${current.id}" else "photoeditor/${current.id}")
            }) {
                Icon(if (current.isVideo) Icons.Default.ContentCut else Icons.Default.Edit, "Edit", tint = Color.White)
            }
            IconButton(onClick = { actions.trash(listOf(current)) { nav.popBackStack() } }) {
                Icon(Icons.Default.Delete, "Move to trash", tint = Color.White)
            }
        }
    }
}

@Composable
private fun ZoomImage(m: GalleryMedia) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val state = rememberTransformableState { zoom, pan, _ ->
        scale = (scale * zoom).coerceIn(1f, 6f)
        offset = if (scale == 1f) Offset.Zero else offset + pan
    }
    AsyncImage(
        model = m.uri, contentDescription = m.name, contentScale = ContentScale.Fit,
        modifier = Modifier.fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = { scale = if (scale > 1f) 1f else 2.5f; offset = Offset.Zero })
            }
            .transformable(state, canPan = { scale > 1f })
            .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y)
    )
}

@Composable
private fun VideoPage(m: GalleryMedia, active: Boolean) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(m.uri)); prepare() } }
    DisposableEffect(Unit) { onDispose { player.release() } }
    LaunchedEffect(active) { player.playWhenReady = active; if (!active) player.pause() }
    AndroidView(factory = { c -> PlayerView(c).also { v -> v.player = player } }, modifier = Modifier.fillMaxSize())
}
