@file:OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)

package com.example.opengallery.ui

import android.content.ContentValues
import android.content.Context
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Crop
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.*
import androidx.media3.transformer.Composition
import androidx.media3.ui.PlayerView
import androidx.navigation.NavController
import com.example.opengallery.GalleryViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Fractions (0..0.45) trimmed from each edge -> Media3 Crop (normalized -1..1 coordinates). */
private fun cropEffect(l: Float, r: Float, t: Float, b: Float): Effect =
    Crop(-1f + 2f * l, 1f - 2f * r, -1f + 2f * b, 1f - 2f * t)

private suspend fun saveToGallery(ctx: Context, file: File, baseName: String): Boolean = withContext(Dispatchers.IO) {
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, "${baseName.substringBeforeLast('.')}_edit_${System.currentTimeMillis()}.mp4")
        put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
        put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/OpenGallery")
        put(MediaStore.MediaColumns.IS_PENDING, 1)
    }
    val res = ctx.contentResolver
    val uri = res.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
    res.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
    values.clear(); values.put(MediaStore.MediaColumns.IS_PENDING, 0)
    res.update(uri, values, null, null)
    file.delete()
    true
}

@Composable
fun EditorScreen(vm: GalleryViewModel, nav: NavController, mediaId: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val m = vm.media.value.firstOrNull { it.id == mediaId }
    if (m == null || !m.isVideo) { LaunchedEffect(Unit) { nav.popBackStack() }; return }

    val durMs = m.duration.coerceAtLeast(1000L).toFloat()
    var range by remember { mutableStateOf(0f..durMs) }
    var cl by remember { mutableFloatStateOf(0f) }
    var cr by remember { mutableFloatStateOf(0f) }
    var ct by remember { mutableFloatStateOf(0f) }
    var cb by remember { mutableFloatStateOf(0f) }
    var exporting by remember { mutableStateOf(false) }

    val player = remember { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(m.uri)); prepare() } }
    DisposableEffect(Unit) { onDispose { player.release() } }
    // Live crop preview.
    LaunchedEffect(cl, cr, ct, cb) { player.setVideoEffects(listOf(cropEffect(cl, cr, ct, cb))) }
    // Jump to the new start when the trim handle moves, and loop inside the trimmed range.
    LaunchedEffect(range.start) { player.seekTo(range.start.toLong()) }
    LaunchedEffect(range) {
        while (true) {
            delay(100)
            if (player.currentPosition >= range.endInclusive) player.seekTo(range.start.toLong())
        }
    }

    fun export() {
        exporting = true
        player.pause()
        val out = File(ctx.cacheDir, "edit_${System.currentTimeMillis()}.mp4")
        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(range.start.toLong())
            .setEndPositionMs(range.endInclusive.toLong()).build()
        val item = EditedMediaItem.Builder(
            MediaItem.Builder().setUri(m.uri).setClippingConfiguration(clip).build()
        ).setEffects(Effects(emptyList(), listOf(cropEffect(cl, cr, ct, cb)))).build()
        val transformer = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    scope.launch {
                        val ok = saveToGallery(ctx, out, m.name)
                        exporting = false
                        vm.refresh()
                        Toast.makeText(ctx, if (ok) "Saved to Movies/OpenGallery" else "Save failed", Toast.LENGTH_LONG).show()
                        if (ok) nav.popBackStack()
                    }
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    exporting = false
                    Toast.makeText(ctx, "Export failed: ${exportException.errorCodeName}", Toast.LENGTH_LONG).show()
                }
            }).build()
        transformer.start(item, out.absolutePath)
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Edit video") },
            navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            actions = { TextButton(enabled = !exporting, onClick = { export() }) { Text("Save copy") } }
        )
    }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState())) {
            if (exporting) LinearProgressIndicator(Modifier.fillMaxWidth())
            AndroidView(
                factory = { c -> PlayerView(c).also { v -> v.player = player } },
                modifier = Modifier.fillMaxWidth().height(280.dp)
            )
            Column(Modifier.padding(16.dp)) {
                Text("Cut: ${fmt(range.start.toLong())} – ${fmt(range.endInclusive.toLong())}", style = MaterialTheme.typography.titleSmall)
                RangeSlider(
                    value = range,
                    onValueChange = { if (it.endInclusive - it.start >= 500f) range = it },
                    valueRange = 0f..durMs
                )
                Spacer(Modifier.height(8.dp))
                Text("Crop", style = MaterialTheme.typography.titleSmall)
                CropSlider("Left", cl) { cl = it }
                CropSlider("Right", cr) { cr = it }
                CropSlider("Top", ct) { ct = it }
                CropSlider("Bottom", cb) { cb = it }
                TextButton(onClick = { cl = 0f; cr = 0f; ct = 0f; cb = 0f; range = 0f..durMs }) { Text("Reset") }
                Text("“Save copy” exports a new file; the original video is untouched.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun CropSlider(label: String, value: Float, onChange: (Float) -> Unit) {
    Text("$label ${(value * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
    Slider(value = value, onValueChange = onChange, valueRange = 0f..0.45f)
}
