package com.example.opengallery.ui

import android.content.ContentValues
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.opengallery.data.GalleryMedia
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val EditBlue = Color(0xFF4C9BFF)

private class VideoInfo(val codec: String?, val audio: String?, val fps: Int?)

private fun readVideoInfo(ctx: android.content.Context, m: GalleryMedia): VideoInfo {
    var codec: String? = null
    var audio: String? = null
    var fps: Int? = null
    runCatching {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, m.uri, null)
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/") && codec == null) {
                codec = when {
                    mime.contains("avc") -> "H.264"
                    mime.contains("hevc") -> "H.265"
                    mime.contains("vp9") -> "VP9"
                    mime.contains("vp8") -> "VP8"
                    mime.contains("av01") -> "AV1"
                    mime.contains("mp4v") -> "MPEG-4"
                    else -> mime.removePrefix("video/")
                }
                if (f.containsKey(MediaFormat.KEY_FRAME_RATE)) fps = runCatching { f.getInteger(MediaFormat.KEY_FRAME_RATE) }.getOrNull()
            } else if (mime.startsWith("audio/") && audio == null) {
                audio = when {
                    mime.contains("mp4a") -> "AAC"
                    mime.contains("opus") -> "Opus"
                    mime.contains("vorbis") -> "Vorbis"
                    mime.contains("mpeg") -> "MP3"
                    mime.contains("amr") -> "AMR"
                    else -> mime.removePrefix("audio/").uppercase()
                }
            }
        }
        ex.release()
    }
    // the real average frame rate (screen recordings are often variable): frames / seconds
    runCatching {
        val r = MediaMetadataRetriever()
        r.setDataSource(ctx, m.uri)
        val frames = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toLongOrNull()
        val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
        r.release()
        if (frames != null && dur != null && dur > 0) fps = Math.round(frames * 1000.0 / dur).toInt()
    }
    return VideoInfo(codec, audio, fps)
}

private fun detailSize(b: Long): String = when {
    b >= 1_000_000_000L -> String.format(Locale.US, "%.2f GB", b / 1e9)
    b >= 1_000_000L -> String.format(Locale.US, "%.2f MB", b / 1e6)
    else -> "${(b / 1000.0).toInt()} KB"
}

private fun fmtDur(ms: Long): String {
    val s = (ms / 1000).toInt()
    return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
}

private fun fmtDateLine(ms: Long): String = SimpleDateFormat("EEEE, MMMM d, yyyy · h:mm a", Locale.US).format(Date(ms))

/** Samsung-style details: date + "Edit", file name, path, album, size / resolution / video info. Shown under the picture. */
@Composable
fun DetailsPanel(m: GalleryMedia, onEdit: () -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val vinfo by produceState<VideoInfo?>(null, m.uri) {
        value = if (m.isVideo) withContext(Dispatchers.IO) { readVideoInfo(ctx, m) } else null
    }
    val path = "/Internal storage/" + m.relativePath.trim('/')
    val line = buildList {
        add(detailSize(m.size))
        if (m.width > 0 && m.height > 0) {
            add("${m.width}x${m.height}")
            if (!m.isVideo) add("${Math.round(m.width.toLong() * m.height / 1_000_000.0).toInt().coerceAtLeast(1)}MP")
        }
    }
    val line2 = if (m.isVideo) buildList {
        add(fmtDur(m.duration))
        vinfo?.codec?.let { add(it) }
        vinfo?.audio?.let { add(it) }
        vinfo?.fps?.let { add("${it}fps") }
    } else emptyList()
    Column(modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(fmtDateLine(m.dateTaken), Modifier.weight(1f), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text("Edit", color = EditBlue, fontSize = 14.sp, modifier = Modifier.clickable { onEdit() }.padding(start = 12.dp, top = 4.dp, bottom = 4.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(m.name, color = Color(0xFFB0B0B0), fontSize = 12.sp)
        Text(path, color = Color(0xFFB0B0B0), fontSize = 12.sp)
        Spacer(Modifier.height(22.dp))
        val n = m.name.lowercase()
        val label = when {
            !m.isVideo && n.startsWith("screenshot") -> "Screenshots"
            m.isVideo && (n.startsWith("screen_recording") || n.startsWith("screenrecord")) -> "Screen recording"
            m.isVideo -> "Video info"
            n.endsWith(".gif") -> "GIF info"
            else -> "Image info"
        }
        Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        InfoLine(line)
        if (line2.isNotEmpty()) { Spacer(Modifier.height(4.dp)); InfoLine(line2) }
    }
}

@Composable
private fun InfoLine(parts: List<String>) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        parts.forEachIndexed { i, p ->
            if (i > 0) Box(Modifier.padding(horizontal = 8.dp).width(1.dp).height(11.dp).background(Color(0xFF555555)))
            Text(p, color = Color(0xFFB0B0B0), fontSize = 12.sp)
        }
    }
}

/** Samsung's "Details" edit screen: change the date/time taken and the file name. */
@Composable
fun DetailsEditDialog(m: GalleryMedia, onDismiss: () -> Unit, onSaved: (name: String, dateTaken: Long) -> Unit) {
    val ctx = LocalContext.current
    val gate = rememberWriteGate(m.uri)
    var name by remember { mutableStateOf(m.name) }
    var when_ by remember { mutableLongStateOf(m.dateTaken) }

    fun pickDate() {
        val c = Calendar.getInstance().apply { timeInMillis = when_ }
        val theme = android.R.style.Theme_DeviceDefault_Dialog_Alert
        android.app.DatePickerDialog(ctx, theme, { _, y, mo, d ->
            android.app.TimePickerDialog(ctx, theme, { _, h, mi ->
                val n = Calendar.getInstance().apply { timeInMillis = when_; set(y, mo, d, h, mi) }
                when_ = n.timeInMillis
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    fun save() {
        val newName = name.trim()
        val nameChanged = newName != m.name
        val dateChanged = when_ != m.dateTaken
        if (!nameChanged && !dateChanged) {
            Toast.makeText(ctx, "Nothing to save.", Toast.LENGTH_SHORT).show(); return
        }
        if (newName.isBlank() || Regex("[\\\\/:*?\"<>|]").containsMatchIn(newName)) {
            Toast.makeText(ctx, "That file name isn't allowed.", Toast.LENGTH_SHORT).show(); return
        }
        // the screen stays open until Android's permission prompt (if any) is answered
        gate {
            val ok = runCatching {
                val cv = ContentValues()
                if (nameChanged) cv.put(MediaStore.MediaColumns.DISPLAY_NAME, newName)
                if (dateChanged) cv.put(MediaStore.MediaColumns.DATE_TAKEN, when_)
                ctx.contentResolver.update(m.uri, cv, null, null) > 0
            }.getOrDefault(false)
            Toast.makeText(ctx, if (ok) "Saved" else "Couldn't save (is there already a file with that name?)", Toast.LENGTH_LONG).show()
            if (ok) onSaved(newName, when_)
            onDismiss()
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        // draw edge to edge with see-through bars, so the buttons can sit ABOVE the navigation bar
        val hostView = androidx.compose.ui.platform.LocalView.current
        androidx.compose.runtime.SideEffect {
            val w = (hostView.parent as? androidx.compose.ui.window.DialogWindowProvider)?.window
            if (w != null) {
                androidx.core.view.WindowCompat.setDecorFitsSystemWindows(w, false)
                w.navigationBarColor = android.graphics.Color.TRANSPARENT
                w.statusBarColor = android.graphics.Color.TRANSPARENT
                if (android.os.Build.VERSION.SDK_INT >= 29) w.isNavigationBarContrastEnforced = false
            }
        }
        Box(Modifier.fillMaxSize().background(Color.Black).imePadding()) {
            Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 12.dp)) {
                Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(44.dp).clip(RoundedCornerShape(50)).clickable { onDismiss() },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
                    Text("Details", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 8.dp))
                }
                Spacer(Modifier.height(16.dp))
                DetailRow(Icons.Filled.CalendarMonth) {
                    Text(
                        SimpleDateFormat("MMMM d, yyyy h:mm a", Locale.US).format(Date(when_)),
                        color = Color.White, fontSize = 14.sp, textDecoration = TextDecoration.Underline,
                        modifier = Modifier.clickable { pickDate() }.padding(vertical = 6.dp)
                    )
                }
                DetailRow(if (m.isVideo) Icons.Filled.PlayCircleOutline else Icons.Filled.Image) {
                    BasicTextField(
                        value = name, onValueChange = { name = it }, singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 14.sp, textDecoration = TextDecoration.Underline),
                        cursorBrush = SolidColor(Color.White), modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                    )
                }
                DetailRow(Icons.Filled.LocationOn) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("No location information", color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(vertical = 6.dp))
                        Icon(
                            Icons.Filled.Add, "Add location", tint = Color(0xFF3DDC84),
                            modifier = Modifier.padding(start = 8.dp).size(18.dp).clickable {
                                Toast.makeText(ctx, "Adding a location isn't supported yet.", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }
            Row(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 16.dp)
                    .clip(RoundedCornerShape(50)).background(Color(0xFF2B2B2B)),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
            ) {
                Text("Cancel", color = Color.White, fontSize = 15.sp, modifier = Modifier.clickable { onDismiss() }.padding(horizontal = 28.dp, vertical = 14.dp))
                Box(Modifier.width(1.dp).height(20.dp).background(Color(0xFF555555)))
                Text("Save", color = Color.White, fontSize = 15.sp, modifier = Modifier.clickable { save() }.padding(horizontal = 28.dp, vertical = 14.dp))
            }
        }
    }
}

@Composable
private fun DetailRow(icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Color(0xFFB0B0B0), modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(16.dp))
        Box(Modifier.weight(1f)) { content() }
    }
}
