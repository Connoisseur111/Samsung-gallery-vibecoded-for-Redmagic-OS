package com.example.opengallery.ui

import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.material3.TextButton
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.SortOption
import com.example.opengallery.data.sortedByOption

@Composable
fun TrashScreen(vm: GalleryViewModel, nav: NavController) {
    val trash by vm.trash.collectAsState()
    LaunchedEffect(Unit) { vm.refreshTrash() }
    val actions = rememberFileActions { vm.refresh(); vm.refreshTrash() }
    val items = remember(trash) { trash.sortedByOption(SortOption.CREATED_DESC) }
    val sel = rememberSelection<Long>()
    var confirmEmpty by remember { mutableStateOf(false) }
    BackHandler(sel.mode) { sel.clear() }

    Box(Modifier.fillMaxSize().background(AppBg)) {
        Column(Modifier.fillMaxSize()) {
            if (sel.mode) SelectionTop(
                sel.ids.size, items.isNotEmpty() && sel.ids.size == items.size,
                onToggleAll = { sel.ids = if (sel.ids.size == items.size) emptySet() else items.map { it.id }.toSet() },
                onCancel = { sel.clear() }
            ) else Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircleButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", { nav.popBackStack() })
                Spacer(Modifier.width(12.dp))
                Text("Trash", color = Color.White, fontSize = 24.sp, modifier = Modifier.weight(1f))
                if (items.isNotEmpty()) PillActions { close ->
                    MenuItem("Select") { close(); sel.start() }
                    MenuItem("Empty trash") { close(); confirmEmpty = true }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (items.isEmpty()) Column(
                    Modifier.align(Alignment.Center).padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("No pictures or videos", color = Color.White, fontSize = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Any images or videos you delete will stay in the Trash for 30 days before they're deleted forever.",
                        color = Color.Gray, fontSize = 14.sp, textAlign = TextAlign.Center
                    )
                } else MediaList(
                    media = items, grouped = false, selected = sel.ids, selecting = sel.mode,
                    onTap = { i -> if (sel.mode) sel.toggle(items[i].id) else sel.start(items[i].id) },
                    onLong = { m -> if (sel.mode) sel.toggle(m.id) else sel.start(m.id) },
                    modifier = Modifier.fillMaxSize(), bottomPadding = 120.dp
                )
            }
        }
        if (sel.mode) ActionPill(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 16.dp)) {
            val chosen = items.filter { it.id in sel.ids }
            PillAction(Icons.Filled.Restore, "Restore", chosen.isNotEmpty()) { actions.restore(chosen) { sel.clear() } }
            PillAction(Icons.Filled.Delete, "Delete", chosen.isNotEmpty()) { actions.deleteForever(chosen) { sel.clear() } }
        }
    }
    if (confirmEmpty) ConfirmDialog(
        "Empty trash", "Permanently delete all ${items.size} item(s)?", "Delete", { confirmEmpty = false }
    ) { confirmEmpty = false; actions.deleteForever(items) }
}

@Composable
private fun SettingRow(
    title: String, desc: String, checked: Boolean, onChecked: (Boolean) -> Unit,
    extra: (@Composable () -> Unit)? = null
) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xFF1E1E1E)).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 17.sp)
                Text(desc, color = Color.Gray, fontSize = 13.sp)
            }
            Switch(checked = checked, onCheckedChange = onChecked)
        }
        if (extra != null) extra()
    }
}

@Composable
fun SettingsScreen(vm: GalleryViewModel, nav: NavController) {
    val ctx = LocalContext.current
    val essentialOn by vm.essentialEnabled.collectAsState()
    val askDelete by vm.askBeforeDelete.collectAsState()
    val askName by vm.askGroupName.collectAsState()
    val askMove by vm.askBeforeMove.collectAsState()
    val askScope by vm.askSortScope.collectAsState()
    var canManage by remember { mutableStateOf(MediaStore.canManageMedia(ctx)) }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) canManage = MediaStore.canManageMedia(ctx)
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }
    val openMediaAccess: () -> Unit = {
        runCatching {
            ctx.startActivity(Intent(Settings.ACTION_REQUEST_MANAGE_MEDIA, Uri.parse("package:" + ctx.packageName)))
        }
    }

    Column(
        Modifier.fillMaxSize().background(AppBg).statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircleButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", { nav.popBackStack() })
            Spacer(Modifier.width(12.dp))
            Text("Settings", color = Color.White, fontSize = 26.sp)
        }
        Spacer(Modifier.height(20.dp))
        SettingRow(
            "Ask before deleting",
            "Android asks you to confirm every time something is moved to the Trash or restored from it. " +
                "Turn this off to skip that prompt.",
            askDelete,
            { on ->
                vm.setAskBeforeDelete(on)
                if (!on && !canManage) openMediaAccess()
            }
        ) {
            if (!askDelete) {
                Spacer(Modifier.height(8.dp))
                if (canManage) {
                    Text("“Media management” is allowed, so these actions no longer ask.", color = Color(0xFF7FD67F), fontSize = 13.sp)
                } else {
                    Text(
                        "Android keeps asking until you allow “Media management” for OpenGallery in system settings.",
                        color = Color(0xFFFFB74D), fontSize = 13.sp
                    )
                    TextButton(onClick = { openMediaAccess() }) { Text("Open settings") }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        SettingRow(
            "Ask before moving files",
            "Android asks you to allow OpenGallery to modify a photo or video every time you move it to another album. " +
                "Turn this off to skip that prompt.",
            askMove,
            { on ->
                vm.setAskBeforeMove(on)
                if (!on && !canManage) openMediaAccess()
            }
        ) {
            if (!askMove) {
                Spacer(Modifier.height(8.dp))
                if (canManage) {
                    Text("“Media management” is allowed, so moving no longer asks.", color = Color(0xFF7FD67F), fontSize = 13.sp)
                } else {
                    Text(
                        "Android keeps asking until you allow “Media management” for OpenGallery in system settings.",
                        color = Color(0xFFFFB74D), fontSize = 13.sp
                    )
                    TextButton(onClick = { openMediaAccess() }) { Text("Open settings") }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        SettingRow(
            "Ask when changing sort order",
            "When you change the sort order inside an album, ask whether it should apply to every album or only to that one. " +
                "Off: the order is saved for that album only, so each album can have its own order.",
            askScope, { vm.setAskSortScope(it) }
        )
        Spacer(Modifier.height(12.dp))
        SettingRow(
            "Ask for a name when merging albums",
            "When you drop an album onto another one, you name the new group first. " +
                "Off: the group is created right away as “Group 1”, “Group 2”…",
            askName, { vm.setAskGroupName(it) }
        )
        Spacer(Modifier.height(12.dp))
        SettingRow(
            "Essential albums",
            "Show only the albums you select on the Albums tab instead of showing them all.",
            essentialOn, { vm.setEssentialEnabled(it) }
        )
        Spacer(Modifier.height(12.dp))
        var pickColor by remember { mutableStateOf(false) }
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xFF1E1E1E))
                .clickable { pickColor = true }.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Background color", color = Color.White, fontSize = 17.sp)
                Text("Change the background of the whole app. Pure black is the default.", color = Color.Gray, fontSize = 13.sp)
            }
            Box(Modifier.size(34.dp).clip(androidx.compose.foundation.shape.CircleShape).background(AppBg)
                .border(2.dp, Color.White, androidx.compose.foundation.shape.CircleShape))
        }
        if (pickColor) BackgroundColorDialog(AppBg, onPick = { vm.setBackground(it) }, onDone = { pickColor = false })
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xFF1E1E1E)).padding(20.dp)) {
            Text("About Gallery", color = Color.White, fontSize = 17.sp)
            Text("OpenGallery 0.45 — an independent Gallery-style app, not affiliated with Samsung.", color = Color.Gray, fontSize = 13.sp)
        }
    }
}
