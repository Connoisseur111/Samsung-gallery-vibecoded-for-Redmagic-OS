package com.example.opengallery.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.opengallery.GalleryViewModel
import com.example.opengallery.data.SortOption
import com.example.opengallery.data.sortedByOption

@Composable
fun SearchScreen(vm: GalleryViewModel, nav: NavController, scopeKey: String) {
    val media by vm.media.collectAsState()
    val albums by vm.albums.collectAsState()
    val links by vm.links.collectAsState()
    val favorites by vm.favorites.collectAsState()
    var scoped by remember { mutableStateOf(scopeKey != "all") }
    var query by remember { mutableStateOf("") }
    val scopeMedia = remember(scopeKey, media, links, favorites) {
        if (scopeKey == "all") media else mediaForKey(scopeKey, media, links, favorites)
    }
    val base = if (scoped) scopeMedia else media
    val scopeTitle = remember(scopeKey, albums, scopeMedia) { titleForKey(scopeKey, albums, scopeMedia) }
    val tokens = query.lowercase().split(" ").filter { it.isNotBlank() }
    val results = remember(base, tokens) {
        if (tokens.isEmpty()) emptyList()
        else base.filter { m ->
            val hay = (m.name + " " + m.bucketName + " " + fmtDate(m.dateTaken)).lowercase()
            tokens.all { it in hay }
        }.sortedByOption(SortOption.CREATED_DESC)
    }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
            Column {
                Text("Search results", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text("${results.size} items", color = Color(0xCCFFFFFF), fontSize = 13.sp)
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (tokens.isEmpty()) Text(
                "Search pictures and videos by name, album or date.",
                color = Color.Gray, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.Center).padding(32.dp)
            ) else MediaList(
                media = results, grouped = false, selected = emptySet(), selecting = false,
                onTap = { i -> vm.viewerList = results; nav.navigate("viewer/$i/0") },
                onLong = { }, modifier = Modifier.fillMaxSize()
            )
        }
        Row(
            Modifier.fillMaxWidth().imePadding().navigationBarsPadding().padding(12.dp)
                .clip(RoundedCornerShape(30.dp)).background(PillBg).padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (scoped) {
                Row(
                    Modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xFF3A3A3A)).padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(scopeTitle, color = Color.White, fontSize = 13.sp, maxLines = 1)
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.Filled.Close, "Remove", tint = Color.White, modifier = Modifier.size(16.dp).clickable { scoped = false })
                }
                Spacer(Modifier.width(8.dp))
            }
            BasicTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Color.White),
                modifier = Modifier.weight(1f).focusRequester(focus),
                decorationBox = { inner ->
                    Box {
                        if (query.isEmpty()) Text("Search", color = Color.Gray, fontSize = 16.sp)
                        inner()
                    }
                }
            )
            Icon(Icons.Filled.Search, null, tint = Color.White)
        }
    }
}

@Composable
fun TrashScreen(vm: GalleryViewModel, nav: NavController) {
    val trash by vm.trash.collectAsState()
    LaunchedEffect(Unit) { vm.refreshTrash() }
    val actions = rememberFileActions { vm.refresh(); vm.refreshTrash() }
    val items = remember(trash) { trash.sortedByOption(SortOption.CREATED_DESC) }
    val sel = rememberSelection<Long>()
    var confirmEmpty by remember { mutableStateOf(false) }
    BackHandler(sel.mode) { sel.clear() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize()) {
            if (sel.mode) SelectionTop(
                sel.ids.size, items.isNotEmpty() && sel.ids.size == items.size,
                onToggleAll = { sel.ids = if (sel.ids.size == items.size) emptySet() else items.map { it.id }.toSet() },
                onCancel = { sel.clear() }
            ) else Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircleButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", { nav.popBackStack() })
                Spacer(Modifier.width(12.dp))
                Text("Trash", color = Color.White, fontSize = 24.sp, modifier = Modifier.weight(1f))
                if (items.isNotEmpty()) PillActions { close ->
                    MenuItem("Select") { close(); sel.start() }
                    MenuItem("Empty trash") { close(); confirmEmpty = true }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (items.isEmpty()) Column(
                    Modifier.align(Alignment.Center).padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("No pictures or videos", color = Color.White, fontSize = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Any images or videos you delete will stay in the Trash for 30 days before they're deleted forever.",
                        color = Color.Gray, fontSize = 14.sp, textAlign = TextAlign.Center
                    )
                } else MediaList(
                    media = items, grouped = false, selected = sel.ids, selecting = sel.mode,
                    onTap = { i -> if (sel.mode) sel.toggle(items[i].id) else sel.start(items[i].id) },
                    onLong = { m -> if (sel.mode) sel.toggle(m.id) else sel.start(m.id) },
                    modifier = Modifier.fillMaxSize(), bottomPadding = 120.dp
                )
            }
        }
        if (sel.mode) ActionPill(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 16.dp)) {
            val chosen = items.filter { it.id in sel.ids }
            PillAction(Icons.Filled.Restore, "Restore", chosen.isNotEmpty()) { actions.restore(chosen) { sel.clear() } }
            PillAction(Icons.Filled.Delete, "Delete", chosen.isNotEmpty()) { actions.deleteForever(chosen) { sel.clear() } }
        }
    }
    if (confirmEmpty) ConfirmDialog(
        "Empty trash", "Permanently delete all ${items.size} item(s)?", "Delete", { confirmEmpty = false }
    ) { confirmEmpty = false; actions.deleteForever(items) }
}

@Composable
fun SettingsScreen(vm: GalleryViewModel, nav: NavController) {
    val essentialOn by vm.essentialEnabled.collectAsState()
    Column(
        Modifier.fillMaxSize().background(Color.Black).statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircleButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", { nav.popBackStack() })
            Spacer(Modifier.width(12.dp))
            Text("Settings", color = Color.White, fontSize = 26.sp)
        }
        Spacer(Modifier.height(20.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xFF1E1E1E)).padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Essential albums", color = Color.White, fontSize = 17.sp)
                Text(
                    "Show only the albums you select on the Albums tab instead of showing them all.",
                    color = Color.Gray, fontSize = 13.sp
                )
            }
            Switch(checked = essentialOn, onCheckedChange = { vm.setEssentialEnabled(it) })
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xFF1E1E1E)).padding(20.dp)) {
            Text("About Gallery", color = Color.White, fontSize = 17.sp)
            Text("OpenGallery 0.2 — an independent Gallery-style app, not affiliated with Samsung.", color = Color.Gray, fontSize = 13.sp)
        }
    }
}
