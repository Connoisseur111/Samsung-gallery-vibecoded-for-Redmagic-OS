# OpenGallery (Samsung Gallery-style)

An independent Gallery-style app (Kotlin + Jetpack Compose), modelled on how Samsung Gallery looks and behaves.
Not affiliated with or copied from Samsung. Requires Android 13+ (minSdk 33). Dark theme only.

## What's in it
- Floating bottom bar: Pictures | Albums | Menu (Videos, Favorites, Recent, Trash, Settings)
- Pictures tab: everything, grouped by date with justified thumbnails
- Albums tab: large title, "Essential albums" + "View all", 3-column rounded tiles with name and count,
  stacked tiles for Recent and groups
  - "+" -> Album or Group; menu -> Select, Select essential albums, Hide albums, Sort, Delete duplicates
  - select albums -> Group / Hide / Delete; groups hold albums (and can be edited from inside the group)
- Album screen: blurred cover header, "N images M videos", 4-column grid; menu -> Select, Add items,
  Sort (date created/modified, name A-Z/Z-A, size, plus "Group by date"), Start slideshow, Album settings
- Selection mode: "○ N" and Cancel pills; bottom bar Share | Add to album | Delete | More
  (favorites, copy/move to folder, remove from album)
- Search with album chip, trash (30 days, restore / delete forever), favorites
- Viewer: swipe, pinch/double-tap zoom, thumbnail strip, favorite / edit / share / delete,
  video controls with play-pause pill, mute and a frame scrubber
- Photo editor: undo/redo, Revert, crop (draggable frame, ratios, rotate, flip), filters, tune
  (brightness, exposure, contrast, saturation, warmth), Save copy
- Video editor: undo/redo, Revert, trim handles on a filmstrip, crop/rotate/flip, filters, tune,
  progress dialog, Save copy

## Not included
Stories / Collections, Auto albums, Shared albums, Private album / Secure Folder, AI editing tools, stickers,
audio eraser, playback speed.

## Build without Android Studio
`.github/workflows/build.yml` builds a debug APK in GitHub Actions (Actions tab -> run -> Artifacts).
