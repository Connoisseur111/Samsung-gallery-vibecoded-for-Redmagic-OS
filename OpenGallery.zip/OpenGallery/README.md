# OpenGallery

An original Gallery-style app (Kotlin + Jetpack Compose). Not affiliated with or copied from Samsung.

## Build
1. Open this folder in Android Studio (Koala or newer). Let Gradle sync.
2. Plug in the RedMagic 10 Pro (USB debugging on) and press Run.
Requires Android 13+ (minSdk 33).

## Features
- Folders tab: device folders with cover and count
- Albums tab: in-app albums that nest inside other albums
  - "+" creates an album / sub-album; long-press an album: rename, move (loop-safe), delete
  - Long-press photos/videos to select, then "Add to album"
- Sorting (top-right): newest, oldest, A-Z, Z-A, largest, smallest — folders, albums, photos, videos
- Viewer: swipe, pinch / double-tap zoom, video playback, edit and trash buttons
- Video editor: trim, 4-side crop with live preview, "Save copy" -> Movies/OpenGallery
- Photo editor: rotate, flip, crop, filters (B&W, sepia, vivid, warm, cool), brightness /
  contrast / saturation, "Save copy" -> Pictures/OpenGallery (JPEG, max 4096 px)
- Real file operations on a selection: trash (system trash, restorable), move to folder,
  copy to folder (existing folder or a new one). Android shows its own permission prompt.

## Notes
- Albums are virtual (local Room database); files stay where they are.
- Moving a video into a Pictures folder (or a photo into Movies) may be rejected by Android;
  the toast shows how many items succeeded.

## Build without Android Studio (GitHub Actions)
`.github/workflows/build.yml` builds a debug APK in the cloud.
1. Push this project to a GitHub repo (or upload only OpenGallery.zip plus build.yml).
2. Open the Actions tab -> the "Build APK" run -> Artifacts -> download OpenGallery-debug-apk.
3. Unzip it, install app-debug.apk on the phone (allow "install unknown apps").
